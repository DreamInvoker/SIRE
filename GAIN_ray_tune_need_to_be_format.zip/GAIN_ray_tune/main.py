# encoding:utf-8
# author: Shuang Zeng

import torch
from torch import nn


class Model(nn.Module):

    def __init__(self):
        self.linear = nn.Linear(2, 3)
        self.linear2 = nn.Linear(3, 1)
        self.cnn_layer = nn.Conv2d(in_channels=1, out_channels=2, kernel_size=(2, 300), stride=1)

    def forward(self, x):
        x = self.linear(x)
        x = self.linear(x)

        return x