import dgl
import dgl.nn.pytorch as dglnn
import numpy as np
import torch
import torch.nn as nn
from transformers import *
import gc
from utils import get_cuda, log
import time
import os

activation_dict = {
    'tanh': nn.Tanh(),
    'relu': nn.ReLU(),
    'gelu': nn.GELU(),
    'leaky_relu': nn.LeakyReLU(0.01)
}
# TODO 加入evidence对inter选句子的监督


class Model(nn.Module):

    def __init__(self, config):
        super(Model, self).__init__()
        self.config = config
        self.activation = activation_dict[config.activation]
        self.dropout = nn.Dropout(config.dropout)
        self.encoder_input_size = 0

        self.use_model = config.use_model
        self.aggregation_method = self.config.aggregation_method

        if self.use_model != 'bert':
            self.word_emb_size = config.word_emb_size
            self.vocabulary_size = config.vocabulary_size
            if config.pre_train_word:
                self.word_emb = nn.Embedding(config.data_word_vec.shape[0], self.word_emb_size, padding_idx=config.word_pad)
                self.word_emb.weight.data.copy_(torch.from_numpy(config.data_word_vec))
            else:
                self.word_emb = nn.Embedding(self.vocabulary_size, self.word_emb_size, padding_idx=config.word_pad)
            self.word_emb.weight.requires_grad = config.finetune_word

            self.encoder_input_size += self.word_emb_size

        # 是否在输入端加入命名实体类别的信息，TODO 可以放在分类层
        if config.use_entity_type_in_input:
            self.encoder_input_size += config.entity_type_size_in_input
            self.entity_type_emb_in_input = nn.Embedding(config.entity_type_num, config.entity_type_size_in_input,
                                                         padding_idx=config.entity_type_pad)

        if config.use_entity_id:
            self.encoder_input_size += config.entity_id_size
            self.entity_id_emb = nn.Embedding(config.max_entity_num + 1, config.entity_id_size,
                                              padding_idx=config.entity_id_pad)
        if self.use_model == 'bilstm' or self.use_model == 'lstm_bert':
            self.doc_level_encoder = BiLSTM(self.encoder_input_size, config)
        else:
            self.doc_level_encoder = BertModel.from_pretrained(config.bert_path, output_hidden_states=True)
            for p in self.doc_level_encoder.parameters():
                p.requires_grad = config.finetune_PLM

        if self.use_model == 'bilstm' or self.use_model == 'lstm_bert':
            if config.reduction_dim > 0:
                self.dim_reduction_layer = nn.Linear(2 * config.doc_lstm_hidden_size, config.reduction_dim)
                self.gcn_dim = config.reduction_dim
            else:
                self.gcn_dim = 2 * config.doc_lstm_hidden_size
        else:
            if config.reduction_dim > 0:
                in_dim = config.bert_hid_size
                if config.use_entity_type_in_input:
                    in_dim += config.entity_type_size_in_input
                if config.use_entity_id:
                    in_dim += config.entity_id_size

                self.dim_reduction_layer = nn.Linear(in_dim, config.reduction_dim)
                self.gcn_dim = config.reduction_dim
            else:
                self.gcn_dim = config.bert_hid_size
                if config.use_entity_type_in_input:
                    self.gcn_dim += config.entity_type_size_in_input
                if config.use_entity_id:
                    self.gcn_dim += config.entity_id_size

        rel_name_lists = ['intra', 'inter', 'sent_mention', 'sent_global', 'sent_sent']
        # rel_name_lists = ['intra', 'inter', 'mention_global', 'sent_mention', 'sent_global', 'sent_sent']
        # rel_name_lists = ['intra', 'inter', 'mention_global']
        self.GCN_layers = nn.ModuleList([RelGraphConvLayer(self.gcn_dim, self.gcn_dim, rel_name_lists,
                                                           num_bases=len(rel_name_lists), activation=self.activation,
                                                           self_loop=True, dropout=self.config.dropout)
                                         for _ in range(config.gcn_layers)])
        if self.aggregation_method == 'concat2' or self.aggregation_method == 'weighted2':
            self.bank_size = self.gcn_dim * (self.config.gcn_layers + 1)
        else:
            if not config.mention_mean:
                self.mention_reduction_linear = nn.Linear(self.gcn_dim * (self.config.gcn_layers + 1), self.gcn_dim)
            self.bank_size = self.gcn_dim

        if self.use_model == 'bilstm' or self.use_model == 'bert_lstm':
            self.sentence_level_encoder = SentenceLevelBiLSTM(self.encoder_input_size, config)
            if config.reduction_dim > 0:
                latter_dim = config.reduction_dim
            else:
                latter_dim = config.sent_lstm_hidden_size * 2
        else:
            self.sentence_level_encoder = BertModel.from_pretrained(config.bert_path, output_hidden_states=True)
            # self.sentence_level_encoder = self.doc_level_encoder
            for p in self.sentence_level_encoder.parameters():
                p.requires_grad = config.finetune_PLM

            if config.reduction_dim > 0:
                latter_dim = config.reduction_dim
            else:
                latter_dim = config.bert_hid_size
                if config.use_entity_type_in_input:
                    latter_dim += config.entity_type_size_in_input
                if config.use_entity_id:
                    latter_dim += config.entity_id_size

        # self.linear_sent = nn.Linear(config.sent_lstm_hidden_size * 2, config.sent_lstm_hidden_size * 2)
        if self.config.intra_ctx_method == 'concat':
            self.intra_ctx_att = nn.Sequential(
                nn.Linear(latter_dim * 3, latter_dim),
                self.activation,
                self.dropout,
                nn.Linear(latter_dim, 1),
            )
        else:
            self.linear_query = nn.Linear(latter_dim * 2, latter_dim)

        if self.config.inter_ctx_method == 'concat' or self.config.inter_ctx_method == 'concat_sigmoid':
            self.inter_ctx_att = nn.Sequential(
                nn.Linear(latter_dim * 3, latter_dim),
                self.activation,
                self.dropout,
                nn.Linear(latter_dim, 1),
            )
        else:
            self.linear_query_inter = nn.Linear(latter_dim * 2, latter_dim)

        predict_dim = 0
        if self.aggregation_method == 'weighted' or self.aggregation_method == 'weighted2':
            predict_dim += self.bank_size * 3
        elif self.aggregation_method == 'concat' or self.aggregation_method == 'concat2':
            predict_dim += self.bank_size * 3 + latter_dim * 3

        if self.config.use_distance:
            self.dis_embed = nn.Embedding(20, config.dis_size, padding_idx=10)
            predict_dim += config.dis_size

        if self.config.add_inter_linear:
            self.inter_rel_att_intra = nn.Linear(predict_dim, predict_dim)
            self.inter_rel_att_inter = nn.Linear(predict_dim, predict_dim)
            # self.inter_rel_att = nn.Linear(predict_dim, predict_dim)

        if self.config.predict_method == 'share':
            if self.aggregation_method == 'weighted' or self.aggregation_method == 'weighted2':
                self.predict = nn.Sequential(
                    nn.Linear(predict_dim, predict_dim // 3),
                    self.activation,
                    self.dropout,
                    nn.Linear(predict_dim // 3, config.relation_num),
                )
            elif self.aggregation_method == 'concat' or self.aggregation_method == 'concat2':
                self.predict = nn.Sequential(
                    nn.Linear(predict_dim, predict_dim // 3),
                    self.activation,
                    self.dropout,
                    nn.Linear(predict_dim // 3, config.relation_num),
                )
        elif self.config.predict_method == 'separate':
            if self.aggregation_method == 'weighted' or self.aggregation_method == 'weighted2':
                self.predict_intra = nn.Sequential(
                    nn.Linear(predict_dim, predict_dim // 3),
                    self.activation,
                    self.dropout,
                    nn.Linear(predict_dim // 3, config.relation_num),
                )
                self.predict_inter = nn.Sequential(
                    nn.Linear(predict_dim, predict_dim // 3),
                    self.activation,
                    self.dropout,
                    nn.Linear(predict_dim // 3, config.relation_num),
                )
            elif self.aggregation_method == 'concat' or self.aggregation_method == 'concat2':
                self.predict_intra = nn.Sequential(
                    nn.Linear(predict_dim, predict_dim // 3),
                    self.activation,
                    self.dropout,
                    nn.Linear(predict_dim // 3, config.relation_num),
                )
                self.predict_inter = nn.Sequential(
                    nn.Linear(predict_dim, predict_dim // 3),
                    self.activation,
                    self.dropout,
                    nn.Linear(predict_dim // 3, config.relation_num),
                )

    def forward(self, **params):
        MG_start_time = time.time()

        doc_words, doc_pos, doc_ner, doc_mention, doc_word_mask, doc_word_length, \
        doc_h_t_pairs, doc_relation_mask, doc_ht_pair_distance, doc_ht_pair_att_mask_only_intra = \
            params['doc_words'], params['doc_pos'], params['doc_ner'], params['doc_mention'], params['doc_word_mask'], \
            params['doc_word_length'], \
            params['doc_h_t_pairs'], params['doc_relation_mask'], params['doc_ht_pair_distance'], \
            params['doc_ht_pair_att_mask_only_intra']

        sent_words, sent_pos, sent_ner, sent_word_mask, \
        sent_word_length, sent_mask, \
        sent_h_mapping, sent_t_mapping, sent_relation_mask, doc2sent_ht_mapping, \
        mention_sent_mapping = \
            params['sent_words'], params['sent_pos'], params['sent_ner'], params['sent_word_mask'], \
            params['sent_word_length'], params['sent_mask'], \
            params['sent_h_mapping'], params['sent_t_mapping'], params['sent_relation_mask'], params[
                'doc2sent_ht_mapping'], \
            params['mention_sent_mapping']

        doc_entity_pair_num = doc_h_t_pairs.shape[1]
        sent_entity_pair_num = doc2sent_ht_mapping.shape[3]
        sent_ht_att_mask = (sent_ner == 0).long() * sent_word_mask
        doc_sent_num = torch.sum(sent_mask, dim=-1)

        is_print = params['is_print'] if 'is_print' in params else False
        if is_print:
            docs = params['docs']
            docs_rel_ins = params['docs_rel_ins']
            docs_entities = params['docs_entities']
            id2rel = params['id2rel']
            rel_info = params['rel_info']
            titles = params['titles']
            print_dir = params['print_dir']
            epoch = params['epoch']
            docs_whole_rel_ins = params['docs_whole_rel_ins']
            test_prefix = params['test_prefix']
            docstring = params['docstring']

        graphs, entity2mention_table = params['graphs'], params['entity2mention_table']

        doc_ht_pair_intra_mask = params['doc_ht_pair_intra_mask']
        doc_ht_pair_inter_mask = params['doc_ht_pair_inter_mask']

        bsz, slen = doc_words.size()
        if self.use_model == 'bilstm' or self.use_model == 'lstm_bert':
            doc_src = self.word_emb(doc_words) # [bsz, slen, word_emb_dim]
            # bsz, slen, word_emb_dim = doc_src.size()
            if self.config.use_entity_id:
                doc_src = torch.cat([doc_src, self.entity_id_emb(doc_pos)], dim=-1)

            if self.config.use_entity_type_in_input:
                doc_src = torch.cat([doc_src, self.entity_type_emb_in_input(doc_ner)], dim=-1)

            doc_encoder_outputs, (doc_output_h_t, _) = self.doc_level_encoder(doc_src, doc_word_length)

            doc_rep = doc_output_h_t
        else:
            doc_encoder_outputs, doc_cls, hs = self.doc_level_encoder(input_ids=doc_words,
                                                                       attention_mask=doc_word_mask)

            doc_encoder_outputs = torch.stack([hs[-1], hs[-2], hs[-3]])
            doc_encoder_outputs = torch.mean(doc_encoder_outputs, 0)
            doc_encoder_outputs = self.dropout(doc_encoder_outputs)

            doc_cls = torch.stack([hs[-1][:, 0, :], hs[-2][:, 0, :], hs[-3][:, 0, :]])
            doc_cls = torch.mean(doc_cls, 0)
            doc_cls = self.dropout(doc_cls)

            if self.config.use_entity_id:
                doc_encoder_outputs = torch.cat([doc_encoder_outputs, self.entity_id_emb(doc_pos)], dim=-1)
                doc_cls = torch.cat([doc_cls, get_cuda(torch.zeros(bsz, self.config.entity_id_size))], dim=-1)

            if self.config.use_entity_type_in_input:
                doc_encoder_outputs = torch.cat([doc_encoder_outputs, self.entity_type_emb_in_input(doc_ner)], dim=-1)
                doc_cls = torch.cat([doc_cls, get_cuda(torch.zeros(bsz, self.config.entity_type_size_in_input))], dim=-1)

            # doc_cls = torch.sum(doc_encoder_outputs, dim=1) / (doc_word_length.unsqueeze(-1) + 1e-16)

            doc_rep = doc_cls

        if self.config.reduction_dim > 0:
            doc_encoder_outputs = self.dropout(self.activation(self.dim_reduction_layer(doc_encoder_outputs)))
            doc_rep = self.dropout(self.activation(self.dim_reduction_layer(doc_rep)))

        doc_encoder_outputs[doc_word_mask == 0] = 0

        bsz, sent_num, word_num = sent_words.size()
        if self.use_model == 'bilstm' or self.use_model == 'bert_lstm':
            sent_src = self.word_emb(sent_words)  # [bsz, sent_num, word_num, word_emb_size]
            if self.config.use_entity_id:
                # [bsz, sent_num, word_num, word_emb_size + entity_type_size]
                sent_src = torch.cat([sent_src, self.entity_id_emb(sent_pos)], dim=-1)

            if self.config.use_entity_type_in_input:
                # [bsz, sent_num, word_num, word_emb_size + entity_type_emb_in_input + entity_id_size]
                sent_src = torch.cat([sent_src, self.entity_type_emb_in_input(sent_ner)], dim=-1)

            sent_encoder_outputs, (sent_hidden_n, cell_n) = self.sentence_level_encoder(sent_src, sent_word_length)

            sentence_rep = sent_hidden_n

        else:
            sent_src = sent_words.view(bsz * sent_num, -1)
            sent_word_mask_for_bert = sent_word_mask.view(bsz * sent_num, -1)
            sent_encoder_outputs, sent_cls, hs = self.sentence_level_encoder(input_ids=sent_src, attention_mask=sent_word_mask_for_bert.long())

            sent_encoder_outputs = torch.stack([hs[-1], hs[-2], hs[-3]])
            sent_encoder_outputs = torch.mean(sent_encoder_outputs, 0)
            sent_encoder_outputs = self.dropout(sent_encoder_outputs)

            sent_cls = torch.stack([hs[-1][:, 0, :], hs[-2][:, 0, :], hs[-3][:, 0, :]])
            sent_cls = torch.mean(sent_cls, 0)
            sent_cls = self.dropout(sent_cls)

            sent_encoder_outputs = sent_encoder_outputs.view(bsz, sent_num, word_num, -1)
            sent_cls = sent_cls.view(bsz, sent_num, -1)

            if self.config.use_entity_id:
                sent_encoder_outputs = torch.cat([sent_encoder_outputs, self.entity_id_emb(sent_pos)], dim=-1)
                sent_cls = torch.cat([sent_cls, get_cuda(torch.zeros(bsz, sent_num, self.config.entity_id_size))], dim=-1)

            if self.config.use_entity_type_in_input:
                sent_encoder_outputs = torch.cat([sent_encoder_outputs, self.entity_type_emb_in_input(sent_ner)], dim=-1)
                sent_cls = torch.cat([sent_cls, get_cuda(torch.zeros(bsz, sent_num, self.config.entity_type_size_in_input))], dim=-1)

            # sentence_rep = torch.sum(sent_encoder_outputs, dim=2) / (sent_word_length.unsqueeze(-1) + 1e-16)

            sentence_rep = sent_cls

        if self.config.reduction_dim > 0:
            sent_encoder_outputs = self.dropout(self.activation(self.dim_reduction_layer(sent_encoder_outputs)))
            sentence_rep = self.dropout(self.activation(self.dim_reduction_layer(sentence_rep)))

        sent_encoder_outputs[sent_word_mask == 0] = 0

        features = None
        for i in range(bsz):
            encoder_output = doc_encoder_outputs[i]  # [slen, 2*encoder_hid_size]
            mention_ids = doc_mention[i]
            mention_num = torch.max(mention_ids)
            mention_index = get_cuda(
                (torch.arange(mention_num) + 1).unsqueeze(1).expand(-1, slen))  # [mention_num, slen]
            mentions = mention_ids.unsqueeze(0).expand(mention_num, -1)  # [mention_num, slen]
            select_metrix = (mention_index == mentions).float()  # [mention_num, slen]
            # average word -> mention
            word_total_numbers = torch.sum(select_metrix, dim=-1).unsqueeze(-1).expand(-1, slen)  # [mention_num, slen]
            select_metrix = torch.where(word_total_numbers > 0, select_metrix / word_total_numbers, select_metrix)
            x = torch.mm(select_metrix, encoder_output)  # [mention_num, 2*encoder_hid_size]

            x = torch.cat((doc_rep[i].unsqueeze(0), x), dim=0)

            x = torch.cat((x, sentence_rep[i, :doc_sent_num[i]]), dim=0)

            if features is None:
                features = x
            else:
                features = torch.cat((features, x), dim=0)  # batch

        graph_big = dgl.batch_hetero(graphs)
        output_features = [features]

        for GCN_layer in self.GCN_layers:

            features = GCN_layer(graph_big, {"node": features})["node"]  # [total_mention_nums, gcn_dim]

            output_features.append(features)

        output_feature = torch.cat(output_features, dim=-1)

        if self.aggregation_method != 'concat2' and self.aggregation_method != 'weighted2':
            if self.config.mention_mean:
                output_feature = torch.mean(torch.stack(output_features), 0)
            else:
                output_feature = self.dropout(self.activation(self.mention_reduction_linear(output_feature)))

        graphs = dgl.unbatch_hetero(graph_big)

        # mention -> entity
        entity_num = torch.max(doc_pos)
        entity_bank = get_cuda(torch.zeros(bsz, entity_num, self.bank_size))
        sentence_rep_new = get_cuda(torch.zeros(bsz, sent_num, self.bank_size))
        # sentence_rep_new = sentence_rep
        global_info = get_cuda(torch.zeros(bsz, self.bank_size))

        cur_idx = 0

        for i in range(bsz):
            # average mention -> entity
            select_metrix = entity2mention_table[i].float()  # [local_entity_num, mention_num]
            local_entity_num = select_metrix.size(0) - 1
            select_metrix[0][0] = 1
            mention_nums = torch.sum(select_metrix, dim=-1).unsqueeze(-1).expand(-1, select_metrix.size(1))
            select_metrix = torch.where(mention_nums > 0, select_metrix / mention_nums, select_metrix)
            sent_length = doc_sent_num[i]
            node_num = graphs[i].number_of_nodes('node')
            entity_representation = torch.mm(select_metrix, output_feature[cur_idx:cur_idx + node_num - sent_length])
            # entity_representation = torch.mm(select_metrix, output_feature[cur_idx:cur_idx + node_num])
            entity_bank[i, :local_entity_num] = entity_representation[1:local_entity_num + 1]
            sentence_rep_new[i, :sent_length] = output_feature[cur_idx + node_num - sent_length:cur_idx + node_num]
            global_info[i] = output_feature[cur_idx]
            cur_idx += node_num

        doc_h_t_pairs_for_entity = doc_h_t_pairs + (doc_h_t_pairs == 0).long() - 1  # [batch_size, h_t_limit, 2]
        h_t_limit = doc_h_t_pairs.size(1)

        # [batch_size, h_t_limit, bank_size]
        h_entity_index = doc_h_t_pairs_for_entity[:, :, 0].unsqueeze(-1).expand(-1, -1, self.bank_size)
        t_entity_index = doc_h_t_pairs_for_entity[:, :, 1].unsqueeze(-1).expand(-1, -1, self.bank_size)

        # [batch_size, h_t_limit, bank_size]
        h_entity = torch.gather(input=entity_bank, dim=1, index=h_entity_index)
        t_entity = torch.gather(input=entity_bank, dim=1, index=t_entity_index)

        global_info = global_info.unsqueeze(1).expand(-1, h_t_limit, -1)

        global_ht_repr = torch.cat([
            h_entity,
            t_entity
        ], dim=-1)
        '''
        global_ht_comparing_repr = torch.cat([
            torch.abs(h_entity - t_entity),
            torch.mul(h_entity, t_entity),
        ], dim=-1)
        '''
        global_ht_context_repr = global_info

        global_intra_ht_repr = global_ht_repr * doc_ht_pair_intra_mask.unsqueeze(-1)
        # if self.training:
        #     global_drop_entity_mask = (get_cuda(torch.rand(bsz, doc_entity_pair_num)) > self.config.dropout_entity).long().unsqueeze(-1).expand_as(global_intra_ht_repr)
        #     global_intra_ht_repr = global_intra_ht_repr * global_drop_entity_mask

        # global_intra_comparing_repr = global_ht_comparing_repr * doc_ht_pair_intra_mask.unsqueeze(-1)
        global_intra_context_repr = global_ht_context_repr * doc_ht_pair_intra_mask.unsqueeze(-1)

        global_inter_ht_repr = global_ht_repr * doc_ht_pair_inter_mask.unsqueeze(-1)
        # global_inter_comparing_repr = global_ht_comparing_repr * doc_ht_pair_inter_mask.unsqueeze(-1)
        global_inter_context_repr = global_ht_context_repr * doc_ht_pair_inter_mask.unsqueeze(-1)

        if self.config.is_print:
            log("模型Mention Graph花了{:.4f}秒".format(time.time() - MG_start_time))

        new_start_time = time.time()

        # 获取句子中头尾mention的表示
        sent_h_mention = torch.matmul(sent_h_mapping,
                                      sent_encoder_outputs)  # [bsz, sent_num, sent_ht_pair_num, lstm_hidden_size]
        sent_t_mention = torch.matmul(sent_t_mapping,
                                      sent_encoder_outputs)  # [bsz, sent_num, sent_ht_pair_num, lstm_hidden_size]

        sent_ht_repr = sent_relation_mask.unsqueeze(-1) * torch.cat([
            sent_h_mention,
            sent_t_mention,
        ], dim=-1)
        '''
        sent_ht_comparing_repr = sent_relation_mask.unsqueeze(-1) * torch.cat([
            torch.abs(sent_h_mention - sent_t_mention),
            torch.mul(sent_h_mention, sent_t_mention)
        ], dim=-1)
        '''

        # sentence_rep_for_sent_ht_query = sentence_rep.unsqueeze(2).expand_as(sent_h_mention)

        sent_ht_query = torch.cat((sent_h_mention, sent_t_mention),
                                  dim=-1)  # [bsz, sent_num, sent_ht_pair_num, 2 * lstm_hidden_size]

        scale = 0
        if self.config.intra_scaling_method == 'self':
            scale = sent_ht_query.shape[-1] // 3
        elif self.config.intra_scaling_method == 'sqrt':
            scale = np.sqrt(sent_ht_query.shape[-1] // 3)
        elif self.config.intra_scaling_method == '1':
            scale = 1

        sent_ht_att_word_method = None
        if self.config.intra_ctx_method == 'sigmoid':
            sent_ht_query = self.linear_query(sent_ht_query)  # [bsz, sent_num, sent_ht_pair_num, lstm_hidden_size]
            sent_ht_att_word = self.activation(torch.matmul(sent_ht_query, sent_encoder_outputs.permute(0, 1, 3, 2)))  # [bsz, sent_num, sent_ht_pair_num, word_num]

            new_sent_word_mask = sent_ht_att_mask.unsqueeze(-2).expand_as(sent_ht_att_word)
            sent_ht_att_word = torch.sigmoid(sent_ht_att_word / scale) * new_sent_word_mask
            sent_word_total_num = torch.sum(sent_ht_att_word, dim=-1).unsqueeze(-1).expand_as(sent_ht_att_word)
            # sent_ht_att_word = torch.where((sent_word_total_num != 0).bool(), sent_ht_att_word / sent_word_total_num, sent_ht_att_word)
            sent_ht_att_word_method = sent_ht_att_word / (sent_word_total_num + 1e-16)

        elif self.config.intra_ctx_method == 'softmax':
            sent_ht_query = self.linear_query(sent_ht_query)  # [bsz, sent_num, sent_ht_pair_num, lstm_hidden_size]
            sent_ht_att_word = self.activation(torch.matmul(sent_ht_query, sent_encoder_outputs.permute(0, 1, 3, 2)))  # [bsz, sent_num, sent_ht_pair_num, word_num]
            if self.config.K == 2:
                new_sent_word_mask = sent_word_mask.unsqueeze(-2).expand_as(sent_ht_att_word)
            else:
                new_sent_word_mask = sent_word_mask.unsqueeze(-2).expand_as(sent_ht_att_word)
            y = get_cuda(torch.zeros((bsz, sent_num, sent_entity_pair_num, word_num)).fill_(-1e12))
            sent_ht_att_word = torch.where(new_sent_word_mask.bool(), sent_ht_att_word, y)
            sent_ht_att_word_method = torch.softmax(sent_ht_att_word / scale,
                                             dim=-1)  # [bsz, sent_num, sent_ht_pair_num, word_num]

        elif self.config.intra_ctx_method == 'concat':
            sent_ht_query = sent_ht_query.unsqueeze(3).expand(bsz, sent_num, sent_entity_pair_num, word_num, -1)
            sent_encoder_outputs_for_query = sent_encoder_outputs.unsqueeze(2).expand(bsz, sent_num,
                                                                                      sent_entity_pair_num, word_num,
                                                                                      -1)
            sent_ht_att_word = self.activation(self.intra_ctx_att(
                torch.cat([sent_ht_query, sent_encoder_outputs_for_query], dim=-1))).squeeze(-1)

            new_sent_word_mask = sent_ht_att_mask.unsqueeze(-2).expand_as(sent_ht_att_word)
            y = get_cuda(torch.zeros((bsz, sent_num, sent_entity_pair_num, word_num)).fill_(-1e12))
            sent_ht_att_word = torch.where(new_sent_word_mask.bool(), sent_ht_att_word, y)
            sent_ht_att_word_method = torch.softmax(sent_ht_att_word / scale,
                                             dim=-1)  # [bsz, sent_num, sent_ht_pair_num, word_num]

        # topK TODO may be used for testing using softmax
        sent_ht_att_word_top = get_cuda(torch.zeros(bsz, sent_num, sent_entity_pair_num, word_num))
        sent_ht_att_word_top_ones = get_cuda(torch.ones(bsz, sent_num, sent_entity_pair_num, word_num))
        intra_top_k_indices = sent_ht_att_word_method.topk(k=self.config.K, dim=-1).indices
        if self.config.K == 2:
            # use a span to denote the context of intra-sentential relation
            first = intra_top_k_indices[:, :, :, 0]
            second = intra_top_k_indices[:, :, :, 1]

            start_indices = torch.minimum(first, second)
            length = torch.abs(first - second) + 1
            for i in range(bsz):
                for j in range(sent_num):
                    for k in range(sent_entity_pair_num):
                        start_index = start_indices[i, j, k]
                        span_len = length[i, j, k]
                        sent_ht_att_word_top[i, j, k, start_index:start_index + span_len] = 1
            sent_ht_att_word_top /= (length.unsqueeze(-1) + 1e-16)

        else:
            sent_ht_att_word_top.scatter_(dim=-1, index=intra_top_k_indices, src=sent_ht_att_word_top_ones)
            sent_ht_att_word_top = sent_ht_att_word_top / self.config.K

        # sent_ht_context_repr = torch.matmul(sent_ht_att_word, sent_encoder_outputs) * sent_relation_mask.unsqueeze(-1)  # [bsz, sent_num, sent_ht_pair_num, lstm_hidden_size]
        sent_ht_context_repr_top = torch.matmul(sent_ht_att_word_top,
                                                sent_encoder_outputs) * sent_relation_mask.unsqueeze(
            -1)  # [bsz, sent_num, sent_ht_pair_num, lstm_hidden_size]
        sent_ht_context_repr_method = torch.matmul(sent_ht_att_word_method,
                                                   sent_encoder_outputs) * sent_relation_mask.unsqueeze(
            -1)  # [bsz, sent_num, sent_ht_pair_num, lstm_hidden_size]

        sent_ht_context_repr = 0.9 * sent_ht_context_repr_top + 0.1 * sent_ht_context_repr_method

        # sent_ht_context_repr = sentence_rep_for_sent_ht_query

        total_intra_instance_num = torch.sum(torch.sum(doc2sent_ht_mapping, dim=-1), dim=1)

        total_intra_instance_num = total_intra_instance_num.unsqueeze(1).expand(
            bsz, sent_num, doc_entity_pair_num).unsqueeze(-1).expand(bsz, sent_num, doc_entity_pair_num,
                                                                     sent_entity_pair_num)
        doc2sent_ht_mapping = doc2sent_ht_mapping / (
                total_intra_instance_num + 1e-16)  # [bsz, sent_num, entity_pair_num, sent_ht_pair_num]

        local_intra_ht_repr = torch.sum(torch.matmul(doc2sent_ht_mapping, sent_ht_repr),
                                        dim=1)  # [bsz, entity_pair_num, memory_size]
        '''
        local_intra_ht_comparing = torch.sum(torch.matmul(doc2sent_ht_mapping, sent_ht_comparing_repr),
                                             dim=1)  # [bsz, entity_pair_num, memory_size]
        '''

        local_intra_ht_context = torch.sum(torch.matmul(doc2sent_ht_mapping, sent_ht_context_repr),
                                           dim=1)  # [bsz, entity_pair_num, memory_size]

        '''
        # 使用local来表示inter的实体
        
        # 得到每个实体的表示（mention的平均，mention的表示是内含词的平均）
        mention_sent_mapping = mention_sent_mapping.permute(0, 2, 1, 3)
        mention_representation = torch.matmul(mention_sent_mapping,
                                              sent_encoder_outputs)  # [bsz, sent_num, entity_num, lstm_hidden_size]
        mention_representation = torch.sum(mention_representation, dim=1)  # [bsz, entity_num, lstm_hidden_size]

        local_entity_dim = mention_representation.shape[2]
        h_entity_index = doc_h_t_pairs_for_entity[:, :, 0].unsqueeze(-1).expand(-1, -1, local_entity_dim)
        t_entity_index = doc_h_t_pairs_for_entity[:, :, 1].unsqueeze(-1).expand(-1, -1, local_entity_dim)
        inter_head_entity = torch.gather(input=mention_representation, dim=1,
                                         index=h_entity_index) * doc_ht_pair_inter_mask.unsqueeze(-1)
        inter_tail_entity = torch.gather(input=mention_representation, dim=1,
                                         index=t_entity_index) * doc_ht_pair_inter_mask.unsqueeze(-1)
        '''

        # 使用global来表示inter的实体
        inter_head_entity = h_entity * doc_ht_pair_inter_mask.unsqueeze(-1)
        inter_tail_entity = t_entity * doc_ht_pair_inter_mask.unsqueeze(-1)

        entity_pair_mask = doc_ht_pair_att_mask_only_intra

        local_inter_ht_repr = torch.cat([
            inter_head_entity,
            inter_tail_entity,
        ], dim=-1) * doc_ht_pair_inter_mask.unsqueeze(-1)

        '''
        local_inter_ht_comparing = torch.cat([
            torch.abs(inter_head_entity - inter_tail_entity),
            torch.mul(inter_head_entity, inter_tail_entity)
        ], dim=-1) * doc_ht_pair_inter_mask.unsqueeze(-1)
        '''

        query = torch.cat([inter_head_entity, inter_tail_entity], dim=-1)  # [bsz, entity_pair_num, memory_size]
        scale = 0
        if self.config.inter_scaling_method == 'self':
            scale = query.shape[-1] // 2
        elif self.config.inter_scaling_method == 'sqrt':
            scale = np.sqrt(query.shape[-1] // 2)
        elif self.config.inter_scaling_method == '1':
            scale = 1
        local_inter_ht_context = None
        if self.config.inter_ctx_method == 'sigmoid':
            # Bilinear
            query = self.linear_query_inter(query)
            inter_ht_att_something = self.activation(torch.matmul(query, doc_encoder_outputs.permute(0, 2, 1)))

            new_doc_word_mask = doc_word_mask.unsqueeze(1).expand_as(inter_ht_att_something)
            inter_ht_att_something = torch.sigmoid(inter_ht_att_something / scale) * new_doc_word_mask
            doc_word_total_num = torch.sum(inter_ht_att_something, dim=-1).unsqueeze(-1).expand_as(inter_ht_att_something)

            inter_ht_att_something_method = inter_ht_att_something / (doc_word_total_num + 1e-16)
            local_inter_ht_context = torch.matmul(inter_ht_att_something_method,
                                                  doc_encoder_outputs) * doc_ht_pair_inter_mask.unsqueeze(
                -1)  # [bsz, sent_num, sent_ht_pair_num, lstm_hidden_size]
        elif self.config.inter_ctx_method == 'softmax':
            # Bilinear
            query = self.linear_query_inter(query)
            inter_ht_att_something = self.activation(torch.matmul(query, doc_encoder_outputs.permute(0, 2, 1)))
            new_doc_word_mask = doc_word_mask.unsqueeze(1).expand_as(inter_ht_att_something)
            yy = get_cuda(torch.zeros((bsz, doc_entity_pair_num, slen)).fill_(-1e12))
            inter_ht_att_something = torch.where(new_doc_word_mask.bool(), inter_ht_att_something, yy)
            inter_ht_att_something_method = torch.softmax(inter_ht_att_something / scale, dim=-1)
            local_inter_ht_context_softmax = torch.matmul(inter_ht_att_something_method,
                                                          doc_encoder_outputs) * doc_ht_pair_inter_mask.unsqueeze(
                -1)  # [bsz, sent_num, sent_ht_pair_num, lstm_hidden_size]
            # topK
            inter_ht_att_something_top = get_cuda(torch.zeros(bsz, doc_entity_pair_num, slen))
            inter_ht_att_something_top_ones = get_cuda(torch.ones(bsz, doc_entity_pair_num, slen))
            inter_top_k_indices = inter_ht_att_something_method.topk(k=self.config.K_inter, dim=-1).indices
            inter_ht_att_something_top.scatter_(dim=-1, index=inter_top_k_indices, src=inter_ht_att_something_top_ones)

            inter_ht_att_something_top = inter_ht_att_something_top / self.config.K_inter
            local_inter_ht_context_top = torch.matmul(inter_ht_att_something_top,
                                                      doc_encoder_outputs) * doc_ht_pair_inter_mask.unsqueeze(-1)
            local_inter_ht_context = 0.9 * local_inter_ht_context_top + 0.1 * local_inter_ht_context_softmax
        elif self.config.inter_ctx_method == 'concat':
            query = query.unsqueeze(2).expand(bsz, doc_entity_pair_num, sent_num, -1)
            sentence_rep_for_query = sentence_rep_new.unsqueeze(1).expand(bsz, doc_entity_pair_num, sent_num, -1)
            inter_ht_att_something = self.inter_ctx_att(torch.cat([query, sentence_rep_for_query], dim=-1)).squeeze(-1)
            yy = get_cuda(torch.zeros((bsz, doc_entity_pair_num, sent_num)).fill_(-1e12))
            inter_ht_att_something = torch.where(sent_mask.unsqueeze(1).expand_as(inter_ht_att_something), inter_ht_att_something, yy)
            inter_ht_att_something_method = torch.softmax(inter_ht_att_something / scale, dim=-1)
            local_inter_ht_context = torch.matmul(inter_ht_att_something_method, sentence_rep_new) * doc_ht_pair_inter_mask.unsqueeze(
                -1)
        elif self.config.inter_ctx_method == 'concat_sigmoid':
            query = query.unsqueeze(2).expand(bsz, doc_entity_pair_num, sent_num, -1)
            sentence_rep_for_query = sentence_rep_new.unsqueeze(1).expand(bsz, doc_entity_pair_num, sent_num, -1)
            inter_ht_att_something = self.inter_ctx_att(torch.cat([query, sentence_rep_for_query], dim=-1)).squeeze(-1)
            # yy = get_cuda(torch.zeros((bsz, doc_entity_pair_num, sent_num)).fill_(-1e12))
            # inter_ht_att_something = torch.where(sent_mask.unsqueeze(1).expand_as(inter_ht_att_something), inter_ht_att_something, yy)
            inter_ht_att_something = torch.sigmoid(inter_ht_att_something / scale) * sent_mask.unsqueeze(1).expand_as(inter_ht_att_something)
            sent_length = torch.sum(inter_ht_att_something, dim=-1).unsqueeze(-1).expand_as(inter_ht_att_something)
            inter_ht_att_something_method = inter_ht_att_something / (sent_length + 1e-16)
            local_inter_ht_context = torch.matmul(inter_ht_att_something_method, sentence_rep_new) * doc_ht_pair_inter_mask.unsqueeze(
                -1)

        global_intra_repr = torch.cat([
            global_intra_ht_repr,
            global_intra_context_repr,
            # global_intra_comparing_repr
        ], dim=-1)

        global_inter_repr = torch.cat([
            global_inter_ht_repr,
            global_inter_context_repr,
            # global_inter_comparing_repr
        ], dim=-1)
        local_intra_repr = torch.cat([
            local_intra_ht_repr,
            local_intra_ht_context,
            # local_intra_ht_comparing
        ], dim=-1)
        local_inter_repr = torch.cat([
            local_inter_ht_repr,
            local_inter_ht_context,
            # local_inter_ht_comparing
        ], dim=-1)

        alpha_intra = self.config.alpha_intra
        alpha_inter = self.config.alpha_inter
        # alpha_inter_intra = self.config.alpha_inter_intra

        if self.aggregation_method == 'weighted' or self.aggregation_method == 'weighted2':
            predict_repr_intra = alpha_intra * global_intra_repr + (1 - alpha_intra) * local_intra_repr
            predict_repr_inter = alpha_inter * global_inter_repr + (1 - alpha_inter) * local_inter_repr
            predict_repr = predict_repr_intra + predict_repr_inter
        else:
            global_repr = global_intra_repr + global_inter_repr
            local_repr = local_intra_repr + local_inter_repr
            predict_repr = torch.cat([
                global_repr,
                local_repr
            ], dim=-1)

        if self.config.use_distance:
            ht_distance = self.dis_embed(doc_ht_pair_distance)
            predict_repr = torch.cat([
                predict_repr,
                ht_distance
            ], dim=-1)

        if self.config.add_inter_linear:
            new_predict_repr_intra = self.activation(self.inter_rel_att_intra(predict_repr))
            new_predict_repr_inter = self.activation(self.inter_rel_att_inter(predict_repr))
        else:
            new_predict_repr_intra = predict_repr
            new_predict_repr_inter = predict_repr

        scale = 0
        if self.config.rel_scaling_method == 'self':
            scale = new_predict_repr_intra.shape[-1]
        elif self.config.rel_scaling_method == 'sqrt':
            scale = np.sqrt(new_predict_repr_intra.shape[-1])
        elif self.config.rel_scaling_method == '1':
            scale = 1

        # dot product
        att_intra = self.activation(torch.matmul(new_predict_repr_intra,
                                  predict_repr.permute(0, 2, 1)) / scale) * doc_ht_pair_intra_mask.unsqueeze(
            1).expand_as(entity_pair_mask)
        att_inter = self.activation(torch.matmul(new_predict_repr_inter,
                                  predict_repr.permute(0, 2, 1)) / scale) * doc_ht_pair_inter_mask.unsqueeze(
            1).expand_as(entity_pair_mask)
        att = att_intra + att_inter
        yyy = get_cuda(torch.zeros((bsz, doc_entity_pair_num, doc_entity_pair_num)).fill_(-1e12))
        att = torch.where(entity_pair_mask, att, yyy)
        if self.config.rel_att_method == 'sigmoid':
            att_norm = torch.sigmoid(att) * entity_pair_mask
            att_norm_sum = torch.sum(att_norm, dim=-1).unsqueeze(-1).expand_as(entity_pair_mask)
            att_norm = att_norm / (att_norm_sum + 1e-16)
        elif self.config.rel_att_method == 'softmax':
            att_norm = torch.softmax(att, dim=-1) * entity_pair_mask

        predict_repr = torch.matmul(att_norm, predict_repr)
        predict_repr_intra = predict_repr * doc_ht_pair_intra_mask.unsqueeze(-1)
        predict_repr_inter = predict_repr * doc_ht_pair_inter_mask.unsqueeze(-1)
        predictions = None
        if self.config.predict_method == 'share':
            predictions = self.predict(predict_repr_intra + predict_repr_inter)
        elif self.config.predict_method == 'separate':
            predictions = self.predict_intra(predict_repr_intra) * doc_ht_pair_intra_mask.unsqueeze(-1) + \
                          self.predict_inter(predict_repr_inter) * doc_ht_pair_inter_mask.unsqueeze(-1)
        if self.config.is_print:
            log("模型其余部分花了{:.4f}秒".format(time.time() - new_start_time))

        if is_print and (epoch == 0 or epoch >= 100):
            if not os.path.exists(print_dir):
                os.mkdir(print_dir)
            dest_dir = os.path.join(print_dir, test_prefix)
            if not os.path.exists(dest_dir):
                os.mkdir(dest_dir)
            for i in range(bsz):
                document = docs[i]
                entities = docs_entities[i]
                rel_instances = docs_rel_ins[i]
                whole_rel_instances = docs_whole_rel_ins[i]
                title = titles[i]
                title = str(title).replace('/', '_')
                title = str(title).replace(',', '_')
                title = str(title).replace("'", '_')
                title = str(title).replace("?", '_')
                title = str(title).replace(":", '_')
                write_file_name = os.path.join(dest_dir, title + '.txt')
                if os.path.exists(write_file_name):
                    os.remove(write_file_name)
                fw = open(write_file_name, 'a')
                sentence_num = len(document)
                doc_word_num = sum([len(s) for s in document])
                docstr = docstring[i]

                fw.write('*'*40 + '\t' + title + '\t' + '*'*40 + '\n')
                document_str = '\n'.join(['[{}]\t'.format(sentence_idx) + ' '.join(sentence) for sentence_idx, sentence in enumerate(document, start=1)])

                fw.write(document_str + '\n')
                '''
                    intra-sentence context attention
                '''
                fw.write('\n\n')
                fw.write('-' * 30 + '\t' + 'intra sentence ht pair attention' + '\t' + '-' * 30 + '\n')
                for j in range(sentence_num):
                    sent_rel_instances = rel_instances[j]
                    sentence_word_num = int(sent_word_length[i, j].item())
                    sentence = document[j]
                    fw.write('\n\nsentence {}:\n'.format(j + 1))
                    count = 0
                    for k, ins in enumerate(sent_rel_instances):
                        head_ent_idx, tail_ent_idx, rel_idx = ins
                        if rel_idx == [0]:
                            continue
                        count += 1
                        fw.write('=' * 100 + '\n')
                        att_top = list(intra_top_k_indices[i, j, k].data.cpu().numpy())
                        att_softmax = list(sent_ht_att_word_method[i, j, k].data.cpu().numpy())[:sentence_word_num]
                        fw.write('head:')
                        for mention in entities[head_ent_idx]:
                            sent_idx, pos, ner, name = mention['sent_id'], mention['pos'], mention['type'], mention['name']
                            if sent_idx == j:
                                fw.write('\t{}\t\t{}\t\t[{}]'.format(name, '{}->{}'.format(pos[0] + 1, pos[1]), ner))
                        fw.write('\n')
                        fw.write('tail:')
                        for mention in entities[tail_ent_idx]:
                            sent_idx, pos, ner, name = mention['sent_id'], mention['pos'], mention['type'], mention['name']
                            if sent_idx == j:
                                fw.write('\t{}\t\t{}\t\t[{}]'.format(name, '{}->{}'.format(pos[0] + 1, pos[1]), ner))
                        fw.write('\n')
                        fw.write('relations:')
                        for r in rel_idx:
                            fw.write('\t{}'.format(rel_info.get(id2rel.get(r, 0), 'no relation')))

                        fw.write('\n\n')
                        fw.write('[{}]\t'.format(j + 1) + ' '.join(sentence))
                        fw.write('\n\n')
                        fw.write('top {} att words:\n'.format(self.config.K))
                        att_word = ['{:.3f}\t\t「{}」\t\t{}'.format(att_softmax[index], index + 1, sentence[index]) for index in att_top]
                        fw.write('{}\n'.format('\n'.join(att_word)))
                        fw.write('\n')
                        full_att_word = ['{:.3f}\t\t「{}」\t\t{}'.format(att_softmax[index], index + 1, sentence[index]) + (' ' * (18 - len(sentence[index])) + '*'* (8 * (self.config.K - att_top.index(index))) if index in att_top else '') for index in range(sentence_word_num)]
                        fw.write('full att words:\n{}\n'.format('\n'.join(full_att_word)))
                    if count == 0:
                        fw.write('no intra-sentential relation instances in this sentence.')

                '''
                    inter-sentence context attention
                '''
                fw.write('\n\n')
                fw.write('-' * 30 + '\t' + 'inter-sentence context attention' + '\t' + '-' * 30 + '\n')
                for k, ins in enumerate(whole_rel_instances):
                    if doc_ht_pair_inter_mask[i, k] == 0:
                        continue
                    head_ent_idx, tail_ent_idx, rel_idx, evidences, key_pos_list = ins
                    if rel_idx == [0]:
                        continue
                    fw.write('=' * 100 + '\n')
                    fw.write('head:')
                    for mention in entities[head_ent_idx]:
                        sent_idx, pos, global_pos, ner, name = mention['sent_id'], mention['pos'], mention['global_pos'], mention['type'], mention['name']
                        fw.write('\t[{}]{}{}[{}]\t\t{}'.format(sent_idx + 1, name, ' ' * (20 - len(name)), ner, '{}->{}'.format(global_pos[0] + 1, global_pos[1])))
                    fw.write('\n')
                    fw.write('tail:')
                    for mention in entities[tail_ent_idx]:
                        sent_idx, pos, global_pos, ner, name = mention['sent_id'], mention['pos'], mention['global_pos'], mention['type'], mention['name']
                        fw.write('\t[{}]{}{}[{}]\t\t{}'.format(sent_idx + 1, name, ' ' * (20 - len(name)), ner, '{}->{}'.format(global_pos[0] + 1, global_pos[1])))
                    fw.write('\n')
                    fw.write('relations:')
                    for r in rel_idx:
                        fw.write('\t{}'.format(rel_info.get(id2rel.get(r, 0), 'no relation')))
                    fw.write('\n')
                    fw.write('evidences:')
                    for evi in evidences:
                        fw.write('\t{}'.format([item + 1 for item in evi]))
                    fw.write('\n\n')
                    if str(self.config.inter_ctx_method).startswith('concat'):
                        att = list(inter_ht_att_something_method[i, k, :].data.cpu().numpy())[:sentence_num]
                        fw.write(''.join(['[{}] {:.3f}:\t{}\n'.format(index + 1, att[index], ' '.join(document[index]))for index in range(sentence_num)]))
                    else:
                        att = list(inter_ht_att_something_method[i, k, :].data.cpu().numpy())[:doc_word_num]

                        att_top = list(inter_top_k_indices[i, k, :].data.cpu().numpy())

                        fw.write('\n\n')
                        fw.write(document_str + '\n')
                        fw.write('\n\n')
                        fw.write('top {} att words:\n'.format(self.config.K_inter))
                        att_word = ['{:.3f}\t\t「{}」\t\t{}'.format(att[index], index + 1, docstr[index]) for
                                    index in att_top]
                        fw.write('{}\n'.format('\n'.join(att_word)))
                        fw.write('\n')
                        full_att_word = [
                            '{:.3f}\t\t「{}」\t\t{}'.format(att[index], index + 1, docstr[index]) + (
                                ' ' * (18 - len(docstr[index])) + '*' * (
                                            4 * (self.config.K_inter - att_top.index(index))) if index in att_top else '') for
                            index in range(len(docstr))]
                        fw.write('full att words:\n{}\n'.format('\n'.join(full_att_word)))

                    fw.write('\nlogical reasoning:\n\n')
                    for pos in key_pos_list:
                        att_score = att_norm[i, k, pos].item()
                        pos_h, pos_t = tuple(doc_h_t_pairs_for_entity[i, pos].data.cpu().numpy())
                        fw.write('head:')
                        for mention in entities[pos_h]:
                            sent_idx, pos, ner, name = mention['sent_id'], mention['pos'], mention['type'], mention[
                                'name']
                            fw.write('\t[{}]{}{}[{}]'.format(sent_idx + 1, name, ' ' * (20 - len(name)), ner))
                        fw.write('\n')
                        fw.write('tail:')
                        for mention in entities[pos_t]:
                            sent_idx, pos, ner, name = mention['sent_id'], mention['pos'], mention['type'], mention[
                                'name']
                            fw.write('\t[{}]{}{}[{}]'.format(sent_idx + 1, name, ' ' * (20 - len(name)), ner))

                        fw.write('\nscore:{:.3f}\n\n'.format(att_score))

                fw.close()
        if self.config.evidence_loss:
            return predictions, inter_ht_att_something
        else:
            return predictions


class BiLSTM(nn.Module):
    def __init__(self, input_size, config):
        super().__init__()
        self.config = config
        self.lstm = nn.LSTM(input_size=input_size, hidden_size=config.doc_lstm_hidden_size,
                            num_layers=config.nlayers, batch_first=True,
                            bidirectional=True)
        self.in_dropout = nn.Dropout(config.lstm_dropout)
        self.out_dropout = nn.Dropout(config.lstm_dropout)

    def forward(self, src, src_lengths):
        '''
        src: [batch_size, slen, input_size]
        src_lengths: [batch_size]
        '''

        self.lstm.flatten_parameters()
        bsz, slen, input_size = src.size()

        src = self.in_dropout(src)

        new_src_lengths, sort_index = torch.sort(src_lengths, dim=-1, descending=True)
        new_src = torch.index_select(src, dim=0, index=sort_index)
        new_src_lengths = new_src_lengths.cpu()
        packed_src = nn.utils.rnn.pack_padded_sequence(new_src, new_src_lengths, batch_first=True, enforce_sorted=True)
        packed_outputs, (src_h_t, src_c_t) = self.lstm(packed_src)

        outputs, _ = nn.utils.rnn.pad_packed_sequence(packed_outputs, batch_first=True,
                                                      padding_value=self.config.word_pad)

        unsort_index = torch.argsort(sort_index)
        outputs = torch.index_select(outputs, dim=0, index=unsort_index)

        src_h_t = src_h_t.view(self.config.nlayers, 2, bsz, -1)
        src_c_t = src_c_t.view(self.config.nlayers, 2, bsz, -1)
        output_h_t = torch.cat((src_h_t[-1, 0], src_h_t[-1, 1]), dim=-1)
        output_c_t = torch.cat((src_c_t[-1, 0], src_c_t[-1, 1]), dim=-1)
        output_h_t = torch.index_select(output_h_t, dim=0, index=unsort_index)
        output_c_t = torch.index_select(output_c_t, dim=0, index=unsort_index)

        outputs = self.out_dropout(outputs)
        output_h_t = self.out_dropout(output_h_t)
        output_c_t = self.out_dropout(output_c_t)

        return outputs, (output_h_t, output_c_t)


class SentenceLevelBiLSTM(nn.Module):
    def __init__(self, input_size, config):
        super().__init__()
        self.config = config
        #  dropout=config.lstm_dropout
        self.lstm = nn.LSTM(input_size=input_size, hidden_size=config.sent_lstm_hidden_size,
                            num_layers=config.nlayers, batch_first=True,
                            bidirectional=True)
        self.in_dropout = nn.Dropout(config.lstm_dropout)
        self.out_dropout = nn.Dropout(config.lstm_dropout)

    def forward(self, src, src_lengths):
        '''
        src: [batch_size, sent_num, slen, input_size]
        src_lengths: [batch_size, sent_num]
        '''
        # TODO 可以装下cuDNN
        # Resets parameter data pointer so that they can use faster code paths.
        # Right now, this works only if the module is on the GPU and cuDNN is enabled. Otherwise, it’s a no-op.
        self.lstm.flatten_parameters()

        bsz, sent_num, slen, input_size = src.size()

        src = self.in_dropout(src)
        # 将每个句子视为一个new batch
        src = src.view(-1, slen, input_size)
        src_lengths = src_lengths.view(-1)

        # 按每个句子的长度降序排列
        new_src_lengths, sort_index = torch.sort(src_lengths, dim=-1, descending=True)
        new_src = torch.index_select(src, dim=0, index=sort_index)

        # !!!这是一个危险的做法!!!!
        # 因为有的句子length为0 先帮他们补成1
        # length 0的句子等下一定会被mask掉的 所以不影响
        new_src_lengths[new_src_lengths == 0] = 1
        new_src_lengths = new_src_lengths.cpu()
        # `enforce_sorted = True` is only necessary for ONNX export
        packed_src = nn.utils.rnn.pack_padded_sequence(new_src, new_src_lengths, batch_first=True, enforce_sorted=True)
        packed_outputs, (src_h_t, src_c_t) = self.lstm(
            packed_src)  # src_h_t/src_c_t: [2, bsz * sent_num, lstm_hidden_size]

        outputs, _ = nn.utils.rnn.pad_packed_sequence(packed_outputs, batch_first=True,
                                                      padding_value=self.config.word_pad)  # [bsz * sent_num, slen, lstm_hidden_size * 2]

        # 恢复正常顺序
        unsort_index = torch.argsort(sort_index)
        outputs = torch.index_select(outputs, dim=0, index=unsort_index)  # [bsz * sent_num, slen, lstm_hidden_size * 2]
        src_h_t = torch.index_select(src_h_t, dim=1, index=unsort_index)  # [2, bsz * sent_num, lstm_hidden_size]
        src_c_t = torch.index_select(src_c_t, dim=1, index=unsort_index)  # [2, bsz * sent_num, lstm_hidden_size]

        src_h_t = src_h_t.view(self.config.nlayers, 2, bsz * sent_num,
                               -1)  # [nlayers, 2, bsz * sent_num, lstm_hidden_size]
        src_c_t = src_c_t.view(self.config.nlayers, 2, bsz * sent_num, -1)
        output_h_t = torch.cat((src_h_t[-1, 0], src_h_t[-1, 1]),
                               dim=-1)  # [self.config.nlayers * bsz * sent_num, lstm_hidden_size * 2]
        output_c_t = torch.cat((src_c_t[-1, 0], src_c_t[-1, 1]), dim=-1)

        # 恢复原来batch
        outputs = outputs.view(bsz, sent_num, slen, self.config.sent_lstm_hidden_size * 2)  # 每个词的hidden state
        output_h_t = output_h_t.view(bsz, sent_num,
                                     self.config.sent_lstm_hidden_size * 2)  # 正向最后一个词的hidden state和反向最后一个词的hidden state的拼接
        output_c_t = output_c_t.view(bsz, sent_num, self.config.sent_lstm_hidden_size * 2)

        outputs = self.out_dropout(outputs)
        output_h_t = self.out_dropout(output_h_t)
        output_c_t = self.out_dropout(output_c_t)

        return outputs, (output_h_t, output_c_t)


class RelGraphConvLayer(nn.Module):
    r"""Relational graph convolution layer.
    Parameters
    ----------
    in_feat : int
        Input feature size.
    out_feat : int
        Output feature size.
    rel_names : list[str]
        Relation names.
    num_bases : int, optional
        Number of bases. If is none, use number of relations. Default: None.
    weight : bool, optional
        True if a linear layer is applied after message passing. Default: True
    bias : bool, optional
        True if bias is added. Default: True
    activation : callable, optional
        Activation function. Default: None
    self_loop : bool, optional
        True to include self loop message. Default: False
    dropout : float, optional
        Dropout rate. Default: 0.0
    """

    def __init__(self,
                 in_feat,
                 out_feat,
                 rel_names,
                 num_bases,
                 *,
                 weight=True,
                 bias=True,
                 activation=None,
                 self_loop=False,
                 dropout=0.0):
        super(RelGraphConvLayer, self).__init__()
        self.in_feat = in_feat
        self.out_feat = out_feat
        self.rel_names = rel_names
        self.num_bases = num_bases
        self.bias = bias
        self.activation = activation
        self.self_loop = self_loop

        self.conv = dglnn.HeteroGraphConv({
            rel: dglnn.GraphConv(in_feat, out_feat, norm='right', weight=False, bias=False)
            for rel in rel_names
        })

        self.use_weight = weight
        self.use_basis = num_bases < len(self.rel_names) and weight
        if self.use_weight:
            if self.use_basis:
                self.basis = dglnn.WeightBasis((in_feat, out_feat), num_bases, len(self.rel_names))
            else:
                self.weight = nn.Parameter(torch.Tensor(len(self.rel_names), in_feat, out_feat))
                nn.init.xavier_uniform_(self.weight, gain=nn.init.calculate_gain('relu'))

        # bias
        if bias:
            self.h_bias = nn.Parameter(torch.Tensor(out_feat))
            nn.init.zeros_(self.h_bias)

        # weight for self loop
        if self.self_loop:
            self.loop_weight = nn.Parameter(torch.Tensor(in_feat, out_feat))
            nn.init.xavier_uniform_(self.loop_weight,
                                    gain=nn.init.calculate_gain('relu'))

        self.dropout = nn.Dropout(dropout)

    def forward(self, g, inputs):
        """Forward computation
        Parameters
        ----------
        g : DGLHeteroGraph
            Input graph.
        inputs : dict[str, torch.Tensor]
            Node feature for each node type.
        Returns
        -------
        dict[str, torch.Tensor]
            New node features for each node type.
        """
        g = g.local_var()
        if self.use_weight:
            weight = self.basis() if self.use_basis else self.weight
            wdict = {self.rel_names[i]: {'weight': w.squeeze(0)}
                     for i, w in enumerate(torch.split(weight, 1, dim=0))}
        else:
            wdict = {}
        hs = self.conv(g, inputs, mod_kwargs=wdict)

        def _apply(ntype, h):
            if self.self_loop:
                h = h + torch.matmul(inputs[ntype], self.loop_weight)
            if self.bias:
                h = h + self.h_bias
            if self.activation:
                h = self.activation(h)
            return self.dropout(h)

        return {ntype: _apply(ntype, h) for ntype, h in hs.items()}


class Bert:
    MASK = '[MASK]'
    CLS = "[CLS]"
    SEP = "[SEP]"

    def __init__(self, model_class, model_name, model_path=None, len=512):
        super().__init__()
        self.model_name = model_name
        # log(model_path)
        self.tokenizer = BertTokenizer.from_pretrained(model_path)
        self.max_len = len

    def tokenize(self, text, masked_idxs=None):
        tokenized_text = self.tokenizer.tokenize(text)
        if masked_idxs is not None:
            for idx in masked_idxs:
                tokenized_text[idx] = self.MASK
        # prepend [CLS] and append [SEP]
        # see https://github.com/huggingface/pytorch-pretrained-BERT/blob/master/examples/run_classifier.py#L195  # NOQA
        tokenized = [self.CLS] + tokenized_text + [self.SEP]
        return tokenized

    def tokenize_to_ids(self, text, masked_idxs=None, pad=True):
        tokens = self.tokenize(text, masked_idxs)
        return tokens, self.convert_tokens_to_ids(tokens, pad=pad)

    def convert_tokens_to_ids(self, tokens, pad=True):
        token_ids = self.tokenizer.convert_tokens_to_ids(tokens)
        ids = torch.tensor([token_ids])
        # assert ids.size(1) < self.max_len
        ids = ids[:, :self.max_len]  # https://github.com/DreamInvoker/GAIN/issues/4
        if pad:
            padded_ids = torch.zeros(1, self.max_len).to(ids)
            padded_ids[0, :ids.size(1)] = ids
            mask = torch.zeros(1, self.max_len).to(ids)
            mask[0, :ids.size(1)] = 1
            return padded_ids, mask
        else:
            return ids

    def flatten(self, list_of_lists):
        for list in list_of_lists:
            for item in list:
                yield item

    def subword_tokenize(self, tokens):
        """Segment each token into subwords while keeping track of
        token boundaries.
        Parameters
        ----------
        tokens: A sequence of strings, representing input tokens.
        Returns
        -------
        A tuple consisting of:
            - A list of subwords, flanked by the special symbols required
                by Bert (CLS and SEP).
            - An array of indices into the list of subwords, indicating
                that the corresponding subword is the start of a new
                token. For example, [1, 3, 4, 7] means that the subwords
                1, 3, 4, 7 are token starts, while all other subwords
                (0, 2, 5, 6, 8...) are in or at the end of tokens.
                This list allows selecting Bert hidden states that
                represent tokens, which is necessary in sequence
                labeling.
        """
        subwords = list(map(self.tokenizer.tokenize, tokens))
        subword_lengths = list(map(len, subwords))
        subwords = [self.CLS] + list(self.flatten(subwords))[:self.max_len-2] + [self.SEP]
        token_start_idxs = 1 + np.cumsum([0] + subword_lengths[:-1])
        token_start_idxs[token_start_idxs > self.max_len-2] = self.max_len
        return subwords, token_start_idxs

    def subword_tokenize_to_ids(self, tokens):
        """Segment each token into subwords while keeping track of
        token boundaries and convert subwords into IDs.
        Parameters
        ----------
        tokens: A sequence of strings, representing input tokens.
        Returns
        -------
        A tuple consisting of:
            - A list of subword IDs, including IDs of the special
                symbols (CLS and SEP) required by Bert.
            - A mask indicating padding tokens.
            - An array of indices into the list of subwords. See
                doc of subword_tokenize.
        """
        subwords, token_start_idxs = self.subword_tokenize(tokens)
        subword_ids, mask = self.convert_tokens_to_ids(subwords)
        return subword_ids.numpy(), token_start_idxs, subwords

    def segment_ids(self, segment1_len, segment2_len):
        ids = [0] * segment1_len + [1] * segment2_len
        return torch.tensor([ids])
