import sklearn.metrics
import torch

from config import *
from data import DGLREDataset, DGLREDataloader
from models.model import Model
from utils import get_cuda, log, print_params
from tqdm import tqdm
import numpy as np


# for ablation
# from models.GCNRE_nomention import GAIN_GloVe, GAIN_BERT

def test(opt, model, dataloader, modelname, id2rel, input_intra_theta=-1, input_inter_theta=-1, output=False,
         is_test=False, test_prefix='dev',
         relation_num=97, whether_print=True, is_print_att=False, epoch=-1, is_model_list=False, model_list=[]):
    total_recall_ignore = 0
    total_intra_ignore = 0  # intra的例子总和
    total_inter_ignore = 0  # intra的例子总和

    test_result = []
    total_recall = 0
    count = 0
    tmp_varibales = []
    for cur_i, d in enumerate(dataloader):

        with torch.no_grad():
            labels = d['labels']
            L_vertex = d['L_vertex']
            indexes = d['indexes']
            overlaps = d['overlaps']
            recall_intra_label_list = d['recall_intra_label_list']

            docs = d['docs']
            docs_rel_ins = d['docs_rel_ins']
            docs_entities = d['docs_entities']
            titles = d['titles']
            doc_relation_mask = d['doc_relation_mask']
            doc_ht_pair_intra_mask = d['doc_ht_pair_intra_mask']
            if is_model_list:
                predictions_list = []
                for model in model_list:
                    model.eval()
                    predictions = model(doc_words=d['doc_words'],
                                        doc_pos=d['doc_pos'],
                                        doc_ner=d['doc_ner'],
                                        doc_mention=d['doc_mention'],
                                        doc_word_mask=d['doc_word_mask'],
                                        doc_word_length=d['doc_word_length'],

                                        doc_h_t_pairs=d['doc_h_t_pairs'],
                                        doc_relation_mask=doc_relation_mask,
                                        doc_ht_pair_distance=d['doc_ht_pair_distance'],

                                        sent_words=d['sent_words'],
                                        sent_pos=d['sent_pos'],
                                        sent_ner=d['sent_ner'],
                                        sent_word_mask=d['sent_word_mask'],
                                        # sent_word_ht_att_mask=d['sent_word_ht_att_mask'],
                                        sent_word_length=d['sent_word_length'],
                                        sent_mask=d['sent_mask'],

                                        sent_h_mapping=d['sent_h_mapping'],
                                        sent_t_mapping=d['sent_t_mapping'],
                                        sent_relation_mask=d['sent_relation_mask'],

                                        doc2sent_ht_mapping=d['doc2sent_ht_mapping'],
                                        doc_ht_pair_att_mask_only_intra=d['doc_ht_pair_att_mask_only_intra'],
                                        mention_sent_mapping=d['mention_sent_mapping'],
                                        # dis_h_2_t=doc_ht_pair_distance + 10, TODO
                                        # dis_t_2_h=-doc_ht_pair_distance + 10,
                                        is_print=is_print_att,
                                        docs=docs,
                                        docs_rel_ins=docs_rel_ins,
                                        docs_whole_rel_ins=d['docs_whole_rel_ins'],
                                        docs_entities=docs_entities,
                                        docstring=d['docstring'],
                                        id2rel=id2rel,
                                        rel_info=rel_info,
                                        titles=titles,
                                        print_dir='att_outputs/{}-ep{}'.format(modelname, epoch),
                                        epoch=0,
                                        global_step=-1,

                                        graphs=d['graphs'],
                                        entity2mention_table=d['entity2mention_table'],

                                        doc_ht_pair_intra_mask=d['doc_ht_pair_intra_mask'],
                                        doc_ht_pair_inter_mask=d['doc_ht_pair_inter_mask'],
                                        test_prefix=test_prefix,
                                        )
                    if opt.evidence_loss:
                        predictions_list.append(torch.sigmoid(predictions[0]))
                    else:
                        predictions_list.append(torch.sigmoid(predictions))
                predict_re = torch.mean(torch.stack(predictions_list), 0)
            else:
                model.eval()
                predictions = model(doc_words=d['doc_words'],
                                    doc_pos=d['doc_pos'],
                                    doc_ner=d['doc_ner'],
                                    doc_mention=d['doc_mention'],
                                    doc_word_mask=d['doc_word_mask'],
                                    doc_word_length=d['doc_word_length'],

                                    doc_h_t_pairs=d['doc_h_t_pairs'],
                                    doc_relation_mask=doc_relation_mask,
                                    doc_ht_pair_distance=d['doc_ht_pair_distance'],

                                    sent_words=d['sent_words'],
                                    sent_pos=d['sent_pos'],
                                    sent_ner=d['sent_ner'],
                                    sent_word_mask=d['sent_word_mask'],
                                    # sent_word_ht_att_mask=d['sent_word_ht_att_mask'],
                                    sent_word_length=d['sent_word_length'],
                                    sent_mask=d['sent_mask'],

                                    sent_h_mapping=d['sent_h_mapping'],
                                    sent_t_mapping=d['sent_t_mapping'],
                                    sent_relation_mask=d['sent_relation_mask'],

                                    doc2sent_ht_mapping=d['doc2sent_ht_mapping'],
                                    doc_ht_pair_att_mask_only_intra=d['doc_ht_pair_att_mask_only_intra'],
                                    mention_sent_mapping=d['mention_sent_mapping'],
                                    # dis_h_2_t=doc_ht_pair_distance + 10, TODO
                                    # dis_t_2_h=-doc_ht_pair_distance + 10,
                                    is_print=is_print_att,
                                    docs=docs,
                                    docs_rel_ins=docs_rel_ins,
                                    docs_whole_rel_ins=d['docs_whole_rel_ins'],
                                    docs_entities=docs_entities,
                                    docstring=d['docstring'],
                                    id2rel=id2rel,
                                    rel_info=rel_info,
                                    titles=titles,
                                    print_dir='att_outputs/{}-ep{}'.format(modelname, epoch),
                                    epoch=0,
                                    global_step=-1,

                                    graphs=d['graphs'],
                                    entity2mention_table=d['entity2mention_table'],

                                    doc_ht_pair_intra_mask=d['doc_ht_pair_intra_mask'],
                                    doc_ht_pair_inter_mask=d['doc_ht_pair_inter_mask'],
                                    test_prefix=test_prefix,
                                    )
                if opt.evidence_loss:
                    predict_re = torch.sigmoid(predictions[0])
                else:
                    predict_re = torch.sigmoid(predictions)

        predict_re = predict_re.data.cpu().numpy()

        tmp_varibales.append({
            'predict_re': predict_re,
            'labels': labels,
            'recall_intra_label_list': recall_intra_label_list,
            'L_vertex': L_vertex,
            'titles': titles,
            'indexes': indexes,
            'doc_ht_pair_intra_mask': doc_ht_pair_intra_mask,
            'docs_entities': docs_entities
        })
        count += 1
        if whether_print and (count % 30 == 0 or count == len(dataloader)):
            log('testing: {}/{}'.format(count, len(dataloader)))

    log('processing predictions ...')
    for item in tmp_varibales:
        predict_re, labels, recall_intra_label_list, L_vertex, titles, indexes, doc_ht_pair_intra_mask, docs_entities = \
            item['predict_re'], item['labels'], item['recall_intra_label_list'], item['L_vertex'], item['titles'], \
            item['indexes'], item['doc_ht_pair_intra_mask'], item['docs_entities']
        bsz = len(labels)

        for i in range(bsz):
            label = labels[i]
            recall_intra_label = recall_intra_label_list[i]
            L = L_vertex[i]
            title = titles[i]
            index = indexes[i]
            entities = docs_entities[i]
            total_recall += len(label)

            for l in label.values():
                if not l:
                    total_recall_ignore += 1
            for l in recall_intra_label.values():
                if l:
                    total_intra_ignore += 1
                else:
                    total_inter_ignore += 1

            j = 0

            for h_idx in range(L):
                for t_idx in range(L):
                    if h_idx != t_idx:

                        for r in range(1, relation_num):
                            rel_ins = (h_idx, t_idx, r)
                            intrain = label.get(rel_ins, False)
                            intra = int(doc_ht_pair_intra_mask[i, j]) == 1

                            test_result.append((rel_ins in label, float(predict_re[i, j, r]), intrain, intra,
                                                title, id2rel[r], index, h_idx, t_idx, r))

                        j += 1

    test_result.sort(key=lambda x: x[1], reverse=True)

    """
        计算intra-F1
    """
    pr_x = []
    pr_y = []
    correct = correct_inter = wrong_inter = 0  # 记录正例中正确的数量

    if total_intra_ignore == 0:
        total_intra_ignore = 1  # for test， 由于测试集没有label

    for i, item in enumerate(test_result):
        correct += item[0]
        if item[0] and not item[3]:
            correct_inter += 1
        if not item[0] and not item[3]:
            wrong_inter += 1

        pr_y.append(float(correct - correct_inter) / (i + 1 - correct_inter - wrong_inter + 1e-20))  # Precision
        pr_x.append(float(correct - correct_inter) / (total_intra_ignore + 1e-20))  # Recall

    pr_x = np.asarray(pr_x, dtype='float32')
    pr_y = np.asarray(pr_y, dtype='float32')
    f1_arr = (2 * pr_x * pr_y / (pr_x + pr_y + 1e-20))  # F1值
    f1 = f1_arr.max()
    f1_pos = f1_arr.argmax()
    intra_theta = test_result[f1_pos][1]

    if input_intra_theta != -1:
        intra_theta = input_intra_theta

    if not is_test:
        if whether_print:
            log(
                '| Intra-Theta {:3.4f} | Intra-P {:3.4f} | Intra-R {:3.4f} | Intra-F1 {:3.4f} |'.format(
                    intra_theta, pr_y[f1_pos], pr_x[f1_pos], f1_arr[f1_pos]))
    else:
        log(
            '| max Intra-f1 {:3.4f} | max_theta {:3.4f} | input_intra_theta {:3.4f} | test_result Intra-P {:3.4f} | test_result Intra-R {:3.4f} | test_result Intra-F1 {:3.4f} |' \
                .format(f1, intra_theta, input_intra_theta, pr_y[f1_pos], pr_x[f1_pos], f1_arr[f1_pos]))

    """
        计算inter-F1
    """
    pr_x = []
    pr_y = []
    correct = correct_intra = wrong_intra = 0

    if total_inter_ignore == 0:
        total_inter_ignore = 1  # for test， 由于测试集没有label

    for i, item in enumerate(test_result):
        correct += item[0]
        if item[0] and item[3]:
            correct_intra += 1
        if not item[0] and item[3]:
            wrong_intra += 1

        pr_y.append(float(correct - correct_intra) / (i + 1 - correct_intra - wrong_intra + 1e-20))  # Precision
        pr_x.append(float(correct - correct_intra) / (total_inter_ignore + + 1e-20))  # Recall

    pr_x = np.asarray(pr_x, dtype='float32')
    pr_y = np.asarray(pr_y, dtype='float32')
    f1_arr = (2 * pr_x * pr_y / (pr_x + pr_y + 1e-20))  # F1值
    f1 = f1_arr.max()
    f1_pos = f1_arr.argmax()
    inter_theta = test_result[f1_pos][1]

    if input_inter_theta != -1:
        inter_theta = input_inter_theta

    if not is_test:
        if whether_print:
            log(
                '| Inter-Theta {:3.4f} | Inter-P {:3.4f} | Inter-R {:3.4f} | Inter-F1 {:3.4f} |'.format(
                    inter_theta, pr_y[f1_pos], pr_x[f1_pos], f1_arr[f1_pos]))
    else:
        log(
            '| max Inter-f1 {:3.4f} | max_theta {:3.4f} | input_inter_theta {:3.4f} | test_result Inter-P {:3.4f} | test_result Inter-R {:3.4f} | test_result Inter-F1 {:3.4f} |' \
                .format(f1, inter_theta, input_inter_theta, pr_y[f1_pos], pr_x[f1_pos], f1_arr[f1_pos]))

    """
        计算F1
    """

    if total_recall == 0:
        total_recall = 1  # for test， 由于测试集没有label
    TP = 0
    pred_result = []
    for i, item in enumerate(test_result):
        if (item[3] and item[1] >= intra_theta) or (not item[3] and item[1] >= inter_theta):
            TP += item[0]
            pred_result.append(item)
        else:
            break

    precision = TP / (len(pred_result) + 1e-20)
    recall = TP / (total_recall + 1e-20)
    f1 = (2 * precision * recall) / (precision + recall + 1e-20)
    if whether_print:
        log('| P {:3.4f} | R {:3.4f} | F1 {:3.4f}'.format(precision, recall, f1))

    """
        计算Ignore-F1
    """
    pred_result_tmp = []
    TP = 0
    TP_intrain = 0
    for i, item in enumerate(test_result):
        if (item[3] and item[1] >= intra_theta) or (not item[3] and item[1] >= inter_theta):
            TP += item[0]
            if item[0] & item[2]:
                TP_intrain += 1
            pred_result_tmp.append(item)
        else:
            break

    precision = (TP - TP_intrain) / (len(pred_result_tmp) - TP_intrain + 1e-20)
    recall = TP / (total_recall + 1e-20)
    f1 = (2 * precision * recall) / (precision + recall + 1e-20)
    if whether_print:
        log('| Ignore-P {:3.4f} | Ignore-R {:3.4f} | Ignore-F1 {:3.4f}'.format(precision, recall, f1))

    if output:
        output = [{'index': x[-4], 'h_idx': x[-3], 't_idx': x[-2], 'r_idx': x[-1],
                   'score': x[1], 'intrain': x[2], 'intra': x[3],
                   'r': x[-5], 'title': x[-6]} for x in pred_result]
        save_path = modelname + '_' + test_prefix + "_index.json"
        json.dump(output, open(save_path, "w"))
        if whether_print:
            log('save predicted file in {}, please submit it to codalab website '
                '(https://competitions.codalab.org/competitions/20717#participate).'.format(save_path))
    return f1, intra_theta, inter_theta


if __name__ == '__main__':
    print('processId:', os.getpid())
    print('prarent processId:', os.getppid())
    opt = get_opt()
    word_emb_size = opt.word_emb_size
    glove_version = opt.glove_version
    word2vec = np.load(os.path.join(dataset_dir, 'vec_{}{}d.npy'.format(glove_version, word_emb_size)))
    opt.data_word_vec = word2vec
    use_model = opt.use_model
    train_set = DGLREDataset(os.path.join(dataset_dir, opt.train_set), os.path.join(dataset_dir, opt.train_set_save),
                             word2id, ner2id, rel2id, dataset_type='train',
                             opt=opt, model_name=use_model)
    test_set = DGLREDataset(os.path.join(dataset_dir, opt.test_set), os.path.join(dataset_dir, opt.test_set_save),
                            word2id, ner2id, rel2id, dataset_type='test',
                            instance_in_train=train_set.instance_in_train, opt=opt, model_name=use_model, max_word_in_sent_for_bert=180)

    test_loader = DGLREDataloader(opt, test_set, batch_size=opt.test_batch_size, dataset_type='test',
                                  max_word_in_sent=142 if use_model == 'bilstm' else 180,
                                  max_length=508 if use_model == 'bilstm' else 512,
                                  max_sent_in_doc=21,
                                  max_sent_ht_limit=1122,
                                  h_t_limit=1722,
                                  )

    model = Model(opt)

    pretrain_model = opt.pretrain_model
    model_name = opt.model_name

    if pretrain_model != '':
        chkpt = torch.load(pretrain_model, map_location=torch.device('cpu'))
        model.load_state_dict(chkpt['checkpoint'])
        log('load checkpoint from {}'.format(pretrain_model))
    else:
        assert 1 == 2, 'please provide checkpoint to evaluate.'

    log('start testing ...')
    model = get_cuda(model)
    model.eval()

    test(
        opt,
        model,
        test_loader,
        model_name,
        id2rel=id2rel,
        input_intra_theta=float(opt.input_intra_theta),
        input_inter_theta=float(opt.input_inter_theta),
        output=True,
        test_prefix='test',
        is_test=True,
        is_print_att=opt.is_print_att
    )
    log('finished')
