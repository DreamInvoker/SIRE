import json
import math
import os
import pickle
import random
import time
from collections import defaultdict

import dgl
import numpy as np
import torch
from torch.utils.data import IterableDataset, DataLoader
from transformers import *
from preprocess import preprocess

from models.model import Bert
from utils import get_cuda, log

IGNORE_INDEX = -100


def create_graph(sentence_num, mention_num, sent2mention, entity2mention):

    # add intra-entity edges
    intra_start = []
    intra_end = []
    inter_start = []
    inter_end = []
    m2g_start = []
    m2g_end = []
    s2m_start = []
    s2m_end = []
    s2g_start = []
    s2g_end = []
    s2s_start = []
    s2s_end = []
    for ent_idx, mentions in entity2mention.items():
        entity_mention_num = len(mentions)
        for i in range(entity_mention_num):
            for j in range(i + 1, entity_mention_num):
                intra_start.append(mentions[i])
                intra_end.append(mentions[j])

    for sent_node_idx, idx in enumerate(range(sentence_num), mention_num + 1):
        sent_mentions = sent2mention[idx]
        sent_mention_num = len(sent_mentions)

        # mention to sent
        for mention in sent_mentions:
            mention_idx, entity_idx = mention
            # to global node
            m2g_start.append(mention_idx)
            m2g_end.append(0)

            s2m_start.append(sent_node_idx)
            s2m_end.append(mention_idx)

        # add inter edges
        for i in range(sent_mention_num):
            for j in range(i + 1, sent_mention_num):
                (mention_i, entity_i), (mention_j, entity_j) = sent_mentions[i], sent_mentions[j]
                if entity_i != entity_j:

                    inter_start.append(mention_i)
                    inter_end.append(mention_j)

        s2g_start.append(sent_node_idx)
        s2g_end.append(0)

    for i in range(mention_num + 1, mention_num + 1 + sentence_num):
        for j in range(i + 1, mention_num + 1 + sentence_num):
            s2s_start.append(i)
            s2s_end.append(j)

    graph = dgl.heterograph({
        ('node', 'intra', 'node'): (intra_start + intra_end, intra_end + intra_start),
        ('node', 'inter', 'node'): (inter_start + inter_end, inter_end + inter_start),
        # ('node', 'mention_global', 'node'): (m2g_start + m2g_end, m2g_end + m2g_start),
        ('node', 'sent_mention', 'node'): (s2m_start + s2m_end, s2m_end + s2m_start),
        ('node', 'sent_global', 'node'): (s2g_start + s2g_end, s2g_end + s2g_start),
        ('node', 'sent_sent', 'node'): (s2s_start + s2s_end, s2s_end + s2s_start),
    })

    return graph


class DGLREDataset(IterableDataset):

    def __init__(self, src_file, save_file, word2id, ner2id, rel2id,
                 dataset_type='train', instance_in_train=None, opt=None, model_name='bilstm', whether_print=True, max_word_in_sent_for_bert=512):

        super(DGLREDataset, self).__init__()

        # record training set mention triples
        self.instance_in_train = set([]) if instance_in_train is None else instance_in_train
        self.data = None
        self.document_max_length = 512
        self.count = 0
        if whether_print:
            log('Reading data from {}.'.format(src_file))
        if os.path.exists(save_file):
            with open(file=save_file, mode='rb') as fr:
                info = pickle.load(fr)
                self.data = info['data']
                self.instance_in_train = info['intrain_set']
            if whether_print:
                log('load preprocessed data from {}.'.format(save_file))

        else:
            bert = None
            if model_name == 'bert':
                bert = Bert(BertModel, 'bert-base-uncased', opt.bert_path, 512)
                bert_sent = Bert(BertModel, 'bert-base-uncased', opt.bert_path, max_word_in_sent_for_bert)

            if model_name == 'bert_lstm':
                bert = Bert(BertModel, 'bert-base-uncased', opt.bert_path, 512)

            if model_name == 'lstm_bert':
                bert_sent = Bert(BertModel, 'bert-base-uncased', opt.bert_path, max_word_in_sent_for_bert)

            with open(file=src_file, mode='r', encoding='utf-8') as fr:
                ori_data = json.load(fr)
                ori_data = [preprocess(item)[0] for item in ori_data]
            if whether_print:
                log('loading..')
            self.data = []

            for i, doc in enumerate(ori_data):

                title, entity_list, labels, sentences, sent2ent, sent2label = \
                    doc['title'], doc['vertexSet'], doc.get('labels', []), doc['sents'], doc['sent2ent'], doc[
                        'sent2label']

                entity_num = len(entity_list)
                sentence_num = len(sentences)

                Ls = [0]
                L = 0
                for x in sentences:
                    L += len(x)
                    Ls.append(L)

                for j in range(entity_num):
                    for k in range(len(entity_list[j])):

                        sent_id, sent_pos = int(entity_list[j][k]['sent_id']), entity_list[j][k]['pos']
                        entity_list[j][k]['sent_id'] = sent_id

                        dl = Ls[sent_id]

                        global_pos = (sent_pos[0] + dl, sent_pos[1] + dl)
                        entity_list[j][k]['global_pos'] = global_pos

                        for mention_idx, mention in enumerate(sent2ent[sent_id]):
                            if mention['pos'] == sent_pos and mention['ent_id'] == j:
                                sent2ent[sent_id][mention_idx]['global_pos'] = global_pos
                                break

                # generate positive examples
                train_triple = []
                sentence_train_triple = [[] for _ in range(len(sentences))]

                new_labels = []

                for label in labels:
                    head, tail, relation, evidence = label['h'], label['t'], label['r'], label['evidence']
                    assert (relation in rel2id), 'no such relation {} in rel2id'.format(relation)
                    label['r'] = rel2id[relation]

                    label['in_train'] = False

                    label['intra'] = False

                    # record training set mention triples and mark it for dev and test set
                    for n1 in entity_list[head]:
                        for n2 in entity_list[tail]:
                            mention_triple = (n1['name'], n2['name'], relation)

                            if dataset_type == 'train':
                                self.instance_in_train.add(mention_triple)
                            else:
                                if mention_triple in self.instance_in_train:
                                    label['in_train'] = True

                            if n1['sent_id'] == n2['sent_id']:
                                label['intra'] = True

                                sent_id = n1['sent_id']
                                sent_labels = sent2label[sent_id]
                                sent_mentions = sent2ent[sent_id]

                                for item_idx, item in enumerate(sent_labels):
                                    h, r, t = item['h'], item['r'], item['t']
                                    h_mention, t_mention = sent_mentions[h], sent_mentions[t]
                                    if h_mention['ent_id'] == head and t_mention['ent_id'] == tail and r == relation:
                                        item['r'] = rel2id[relation]
                                        item.update({'in_train': label['in_train']})
                                        sent2label[sent_id][item_idx] = item

                    train_triple.append((head, tail))
                    new_labels.append(label)

                for sent_idx, sentence_label in enumerate(sent2label):
                    sentence_triple = sentence_train_triple[sent_idx]
                    for label in sentence_label:
                        head, tail, relation, evidence = label['h'], label['t'], label['r'], label['evidence']
                        sentence_triple.append((head, tail))

                    sentence_train_triple[sent_idx] = sentence_triple

                # generate negative examples
                na_triple = []
                for j in range(entity_num):
                    for k in range(entity_num):
                        if j != k and (j, k) not in train_triple:
                            intra = False
                            for n1 in entity_list[j]:
                                for n2 in entity_list[k]:
                                    if n1['sent_id'] == n2['sent_id']:
                                        intra = True

                            na_triple.append((j, k, intra))

                sentence_na_triple = [[] for _ in range(len(sentences))]
                for sent_idx in range(sentence_num):
                    sentence_triple = sentence_na_triple[sent_idx]
                    sent_mentions = sent2ent[sent_idx]
                    total_mention_num = len(sent_mentions)
                    for j in range(total_mention_num):
                        for k in range(total_mention_num):
                            j_mention, k_mention = sent_mentions[j], sent_mentions[k]
                            if j != k and j_mention['ent_id'] != k_mention['ent_id'] and (j, k) not in \
                                    sentence_train_triple[sent_idx]:
                                sentence_triple.append((j, k))
                    sentence_na_triple[sent_idx] = sentence_triple

                # generate document ids
                words = []
                for sentence in sentences:
                    for word in sentence:
                        words.append(word)
                docs_others = words
                doc_bert_subwords = []
                if model_name == 'bert' or model_name == 'bert_lstm':
                    bert_token, bert_starts, doc_bert_subwords = bert.subword_tokenize_to_ids(words)
                else:
                    if len(words) > self.document_max_length:
                        words = words[:self.document_max_length]

                doc_word_id = np.zeros((self.document_max_length,), dtype=np.int32)
                doc_pos_id = np.zeros((self.document_max_length,), dtype=np.int32)
                doc_ner_id = np.zeros((self.document_max_length,), dtype=np.int32)
                doc_mention_id = np.zeros((self.document_max_length,), dtype=np.int32)

                # sentence-level data
                # max_word_per_sent = max([len(sent) for sent in sentences])

                max_word_per_sent = max([len(sent) for sent in sentences]) if model_name == 'bilstm' or model_name == 'bert_lstm' else max_word_in_sent_for_bert
                sent_level_word_id = np.zeros((sentence_num, max_word_per_sent), dtype=np.int32)
                sent_level_pos_id = np.zeros((sentence_num, max_word_per_sent), dtype=np.int32)
                sent_level_ner_id = np.zeros((sentence_num, max_word_per_sent), dtype=np.int32)

                if model_name == 'bert' or model_name == 'bert_lstm':
                    doc_word_id[:] = bert_token[0]
                else:
                    for iii, w in enumerate(words):
                        word = word2id.get(w.lower(), word2id['UNK'])
                        doc_word_id[iii] = word

                sent_bert_starts_list = []
                sent_bert_subwords = []
                for sent_idx, sentence in enumerate(sentences):
                    if model_name == 'bert' or model_name == 'lstm_bert':
                        bert_token, sent_bert_starts, bert_subwords = bert_sent.subword_tokenize_to_ids(sentence)
                        sent_bert_starts_list.append(sent_bert_starts)
                        sent_bert_subwords.append(bert_subwords)
                        sent_level_word_id[sent_idx, :] = bert_token[0]
                    else:
                        word = [word2id.get(w.lower(), word2id['UNK']) for w in sentence]
                        sent_level_word_id[sent_idx, :len(sentence)] = word

                entity2mention = defaultdict(list)
                sent2mention = defaultdict(list)
                mention_idx = 1
                already_exist = set()  # dealing with NER overlapping problem
                for idx, vertex in enumerate(entity_list, 1):
                    for m_idx, v in enumerate(vertex):
                        sent_id, (pos0, pos1), ner_id = v['sent_id'], v['global_pos'], ner2id[v['type']]
                        if model_name == 'bert' or model_name == 'bert_lstm':
                            pos0 = bert_starts[pos0]
                            pos1 = bert_starts[pos1] if pos1 < len(bert_starts) else 1024
                            entity_list[idx - 1][m_idx]['global_pos'] = [pos0, pos1]

                        if (pos0, pos1) in already_exist:
                            continue
                        if model_name == 'bert' or model_name == 'bert_lstm':
                            if pos0 >= len(doc_pos_id):
                                continue
                        doc_pos_id[pos0:pos1] = idx
                        doc_ner_id[pos0:pos1] = ner_id
                        doc_mention_id[pos0:pos1] = mention_idx

                        entity2mention[idx].append(mention_idx)
                        sent2mention[sent_id].append((mention_idx, idx))
                        mention_idx += 1
                        already_exist.add((pos0, pos1))
                if model_name == 'bert' or model_name == 'bert_lstm':
                    replace_i = 1
                else:
                    replace_i = 0
                existing_max_entity_id = doc_pos_id.max()
                for idx in range(existing_max_entity_id + 1, len(entity_list) + 1):
                    e = entity_list[idx - 1]
                    for m_idx, m in enumerate(e):
                        entity2mention[idx].append(mention_idx)
                        while doc_mention_id[replace_i] != 0:
                            replace_i += 1
                        doc_mention_id[replace_i] = mention_idx
                        doc_pos_id[replace_i] = idx
                        doc_ner_id[replace_i] = ner2id[m['type']]
                        sent2mention[m['sent_id']].append((mention_idx, idx))
                        mention_idx += 1
                mention_num = mention_idx - 1

                # construct graph
                graph = create_graph(sentence_num, mention_num, sent2mention, entity2mention)

                overlap = doc.get('overlap_entity_pair', [])
                new_overlap = [tuple(item) for item in overlap]

                # co-reference feature and ner feature
                for idx, mention_list in enumerate(entity_list, 1):
                    for mention_idx, mention in enumerate(mention_list):
                        sent_id, (pos0, pos1), ner_id = \
                            mention['sent_id'], mention['pos'], ner2id[mention['type']]

                        if model_name == 'bert' or model_name == 'lstm_bert':
                            bert_starts = sent_bert_starts_list[sent_id]
                            for sent_mention_idx, sent_mention in enumerate(sent2ent[sent_id]):
                                if sent_mention['pos'] == mention['pos'] and sent_mention['ent_id'] == idx - 1:
                                    sent2ent[sent_id][sent_mention_idx]['pos'] = [bert_starts[pos0], bert_starts[pos1] if pos1 < len(bert_starts) else 1024]
                                    break
                            pos0 = bert_starts[pos0]
                            pos1 = bert_starts[pos1] if pos1 < len(bert_starts) else 1024
                            entity_list[idx - 1][mention_idx]['pos'] = [pos0, pos1]

                        sent_level_pos_id[sent_id, pos0:pos1] = idx
                        sent_level_ner_id[sent_id, pos0:pos1] = ner_id
                # assert doc_mention_id.max() == mention_num
                entity2mention_t = torch.zeros((doc_pos_id.max() + 1, doc_mention_id.max() + 1))
                for e, ms in entity2mention.items():
                    for m in ms:
                        # if m >= doc_mention_id.max() + 1:
                        #     break
                        entity2mention_t[e, m] = 1

                self.data.append({
                    'title': title,
                    'sentences': sentences,
                    'entities': entity_list,
                    'labels': new_labels,
                    'doc_na_triple': na_triple,
                    'doc_word_id': doc_word_id,
                    'doc_pos_id': doc_pos_id,
                    'doc_ner_id': doc_ner_id,
                    'doc_mention_id': doc_mention_id,
                    'entity2mention_t': entity2mention_t,
                    'graph': graph,
                    'overlap': new_overlap,
                    'sent_na_triple': sentence_na_triple,
                    'sent_word_id': sent_level_word_id,
                    'sent_pos_id': sent_level_pos_id,
                    'sent_ner_id': sent_level_ner_id,
                    'sent2ent': sent2ent,
                    'sent2label': sent2label,
                    'sent_bert_subwords': sent_bert_subwords,
                    'docs_bert': doc_bert_subwords,
                    'docs_others': docs_others
                })

            # save data
            with open(file=save_file, mode='wb') as fw:
                pickle.dump({'data': self.data, 'intrain_set': self.instance_in_train}, fw)
            if whether_print:
                log('finish reading {} and save preprocessed data to {}.'.format(src_file, save_file))

        if opt.k_fold != "none":
            k_fold = opt.k_fold.split(',')
            k, total = float(k_fold[0]), float(k_fold[1])
            a = (k - 1) / total * len(self.data)
            b = k / total * len(self.data)
            self.data = self.data[:a] + self.data[b:]

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]

    def __iter__(self):
        return iter(self.data)


class DGLREDataset4CDR(IterableDataset):

    def __init__(self, src_file, save_file, word2id, ner2id, rel2id,
                 dataset_type='train', instance_in_train=None, opt=None, model_name='bilstm', whether_print=True, max_word_in_sent_for_bert=512):

        super(DGLREDataset4CDR, self).__init__()

        # record training set mention triples
        self.instance_in_train = set([]) if instance_in_train is None else instance_in_train
        self.data = None
        self.document_max_length = 512
        self.count = 0
        if whether_print:
            log('Reading data from {}.'.format(src_file))
        if os.path.exists(save_file):
            with open(file=save_file, mode='rb') as fr:
                info = pickle.load(fr)
                self.data = info['data']
                self.instance_in_train = info['intrain_set']
            if whether_print:
                log('load preprocessed data from {}.'.format(save_file))

        else:
            bert = None
            if model_name == 'bert':
                bert = Bert(BertModel, 'bert-base-uncased', opt.bert_path, 512)
                bert_sent = Bert(BertModel, 'bert-base-uncased', opt.bert_path, max_word_in_sent_for_bert)

            if model_name == 'bert_lstm':
                bert = Bert(BertModel, 'bert-base-uncased', opt.bert_path, 512)

            if model_name == 'lstm_bert':
                bert_sent = Bert(BertModel, 'bert-base-uncased', opt.bert_path, max_word_in_sent_for_bert)

            with open(file=src_file, mode='r', encoding='utf-8') as fr:
                ori_data = json.load(fr)
                ori_data = [preprocess(item)[0] for item in ori_data]
            if whether_print:
                log('loading..')
            self.data = []

            for i, doc in enumerate(ori_data):

                title, entity_list, labels, sentences, sent2ent, sent2label = \
                    doc['title'], doc['vertexSet'], doc.get('labels', []), doc['sents'], doc['sent2ent'], doc[
                        'sent2label']

                entity_num = len(entity_list)
                sentence_num = len(sentences)

                Ls = [0]
                L = 0
                for x in sentences:
                    L += len(x)
                    Ls.append(L)

                for j in range(entity_num):
                    for k in range(len(entity_list[j])):

                        sent_id, sent_pos = int(entity_list[j][k]['sent_id']), entity_list[j][k]['pos']
                        entity_list[j][k]['sent_id'] = sent_id

                        dl = Ls[sent_id]

                        global_pos = (sent_pos[0] + dl, sent_pos[1] + dl)
                        entity_list[j][k]['global_pos'] = global_pos

                        for mention_idx, mention in enumerate(sent2ent[sent_id]):
                            if mention['pos'] == sent_pos and mention['ent_id'] == j:
                                sent2ent[sent_id][mention_idx]['global_pos'] = global_pos
                                break

                # generate positive examples
                train_triple = []
                na_triple = []
                sentence_train_triple = [[] for _ in range(len(sentences))]
                sentence_na_triple = [[] for _ in range(len(sentences))]

                new_labels = []

                for label in labels:
                    head, tail, relation, evidence = label['h'], label['t'], label['r'], label['evidence']

                    if relation == '1:CID:2':
                        train_triple.append((head, tail))
                    else:
                        na_triple.append((head, tail))
                    assert (relation in rel2id), 'no such relation {} in rel2id'.format(relation)
                    label['r'] = rel2id[relation]

                    label['in_train'] = False

                    label['intra'] = False

                    # record training set mention triples and mark it for dev and test set
                    for n1 in entity_list[head]:
                        for n2 in entity_list[tail]:

                            if n1['sent_id'] == n2['sent_id']:
                                label['intra'] = True
                    if relation == '1:CID:2':
                        new_labels.append(label)

                for sent_idx, sentence_label in enumerate(sent2label):
                    sentence_triple = sentence_train_triple[sent_idx]
                    sentence_na = sentence_na_triple[sent_idx]
                    for label in sentence_label:
                        head, tail, relation, evidence = label['h'], label['t'], label['r'], label['evidence']
                        if relation == '1:CID:2':
                            sentence_triple.append((head, tail))
                        else:
                            sentence_na.append((head, tail))

                    sentence_train_triple[sent_idx] = sentence_triple
                    sentence_na_triple[sent_idx] = sentence_na

                # generate document ids
                words = []
                for sentence in sentences:
                    for word in sentence:
                        words.append(word)
                docs_others = words
                doc_bert_subwords = []
                if model_name == 'bert' or model_name == 'bert_lstm':
                    bert_token, bert_starts, doc_bert_subwords = bert.subword_tokenize_to_ids(words)
                else:
                    if len(words) > self.document_max_length:
                        words = words[:self.document_max_length]

                doc_word_id = np.zeros((self.document_max_length,), dtype=np.int32)
                doc_pos_id = np.zeros((self.document_max_length,), dtype=np.int32)
                doc_ner_id = np.zeros((self.document_max_length,), dtype=np.int32)
                doc_mention_id = np.zeros((self.document_max_length,), dtype=np.int32)

                # sentence-level data
                # max_word_per_sent = max([len(sent) for sent in sentences])

                max_word_per_sent = max([len(sent) for sent in sentences]) if model_name == 'bilstm' or model_name == 'bert_lstm' else max_word_in_sent_for_bert
                sent_level_word_id = np.zeros((sentence_num, max_word_per_sent), dtype=np.int32)
                sent_level_pos_id = np.zeros((sentence_num, max_word_per_sent), dtype=np.int32)
                sent_level_ner_id = np.zeros((sentence_num, max_word_per_sent), dtype=np.int32)

                if model_name == 'bert' or model_name == 'bert_lstm':
                    doc_word_id[:] = bert_token[0]
                else:
                    for iii, w in enumerate(words):
                        word = word2id.get(w.lower(), word2id['UNK'])
                        doc_word_id[iii] = word

                sent_bert_starts_list = []
                sent_bert_subwords = []
                for sent_idx, sentence in enumerate(sentences):
                    if model_name == 'bert' or model_name == 'lstm_bert':
                        bert_token, sent_bert_starts, bert_subwords = bert_sent.subword_tokenize_to_ids(sentence)
                        sent_bert_starts_list.append(sent_bert_starts)
                        sent_bert_subwords.append(bert_subwords)
                        sent_level_word_id[sent_idx, :] = bert_token[0]
                    else:
                        word = [word2id.get(w.lower(), word2id['UNK']) for w in sentence]
                        sent_level_word_id[sent_idx, :len(sentence)] = word

                entity2mention = defaultdict(list)
                sent2mention = defaultdict(list)
                mention_idx = 1
                already_exist = set()  # dealing with NER overlapping problem
                for idx, vertex in enumerate(entity_list, 1):
                    for m_idx, v in enumerate(vertex):
                        sent_id, (pos0, pos1), ner_id = v['sent_id'], v['global_pos'], ner2id[v['type']]
                        if model_name == 'bert' or model_name == 'bert_lstm':
                            pos0 = bert_starts[pos0]
                            pos1 = bert_starts[pos1] if pos1 < len(bert_starts) else 1024
                            entity_list[idx - 1][m_idx]['global_pos'] = [pos0, pos1]

                        if (pos0, pos1) in already_exist:
                            continue
                        if model_name == 'bert' or model_name == 'bert_lstm':
                            if pos0 >= len(doc_pos_id):
                                continue
                        doc_pos_id[pos0:pos1] = idx
                        doc_ner_id[pos0:pos1] = ner_id
                        doc_mention_id[pos0:pos1] = mention_idx

                        entity2mention[idx].append(mention_idx)
                        sent2mention[sent_id].append((mention_idx, idx))
                        mention_idx += 1
                        already_exist.add((pos0, pos1))
                if model_name == 'bert' or model_name == 'bert_lstm':
                    replace_i = 1
                else:
                    replace_i = 0
                existing_max_entity_id = doc_pos_id.max()
                for idx in range(existing_max_entity_id + 1, len(entity_list) + 1):
                    e = entity_list[idx - 1]
                    for m_idx, m in enumerate(e):
                        entity2mention[idx].append(mention_idx)
                        while doc_mention_id[replace_i] != 0:
                            replace_i += 1
                        doc_mention_id[replace_i] = mention_idx
                        doc_pos_id[replace_i] = idx
                        doc_ner_id[replace_i] = ner2id[m['type']]
                        sent2mention[m['sent_id']].append((mention_idx, idx))
                        mention_idx += 1
                mention_num = mention_idx - 1

                # construct graph
                graph = create_graph(sentence_num, mention_num, sent2mention, entity2mention)

                overlap = doc.get('overlap_entity_pair', [])
                new_overlap = [tuple(item) for item in overlap]

                # co-reference feature and ner feature
                for idx, mention_list in enumerate(entity_list, 1):
                    for mention_idx, mention in enumerate(mention_list):
                        sent_id, (pos0, pos1), ner_id = \
                            mention['sent_id'], mention['pos'], ner2id[mention['type']]

                        if model_name == 'bert' or model_name == 'lstm_bert':
                            bert_starts = sent_bert_starts_list[sent_id]
                            for sent_mention_idx, sent_mention in enumerate(sent2ent[sent_id]):
                                if sent_mention['pos'] == mention['pos'] and sent_mention['ent_id'] == idx - 1:
                                    sent2ent[sent_id][sent_mention_idx]['pos'] = [bert_starts[pos0], bert_starts[pos1] if pos1 < len(bert_starts) else 1024]
                                    break
                            pos0 = bert_starts[pos0]
                            pos1 = bert_starts[pos1] if pos1 < len(bert_starts) else 1024
                            entity_list[idx - 1][mention_idx]['pos'] = [pos0, pos1]

                        sent_level_pos_id[sent_id, pos0:pos1] = idx
                        sent_level_ner_id[sent_id, pos0:pos1] = ner_id
                # assert doc_mention_id.max() == mention_num
                entity2mention_t = torch.zeros((doc_pos_id.max() + 1, doc_mention_id.max() + 1))
                for e, ms in entity2mention.items():
                    for m in ms:
                        # if m >= doc_mention_id.max() + 1:
                        #     break
                        entity2mention_t[e, m] = 1

                self.data.append({
                    'title': title,
                    'sentences': sentences,
                    'entities': entity_list,
                    'labels': new_labels,
                    'doc_na_triple': na_triple,
                    'doc_word_id': doc_word_id,
                    'doc_pos_id': doc_pos_id,
                    'doc_ner_id': doc_ner_id,
                    'doc_mention_id': doc_mention_id,
                    'entity2mention_t': entity2mention_t,
                    'graph': graph,
                    'overlap': new_overlap,
                    'sent_na_triple': sentence_na_triple,
                    'sent_word_id': sent_level_word_id,
                    'sent_pos_id': sent_level_pos_id,
                    'sent_ner_id': sent_level_ner_id,
                    'sent2ent': sent2ent,
                    'sent2label': sent2label,
                    'sent_bert_subwords': sent_bert_subwords,
                    'docs_bert': doc_bert_subwords,
                    'docs_others': docs_others
                })

            # save data
            with open(file=save_file, mode='wb') as fw:
                pickle.dump({'data': self.data, 'intrain_set': self.instance_in_train}, fw)
            if whether_print:
                log('finish reading {} and save preprocessed data to {}.'.format(src_file, save_file))

        if opt.k_fold != "none":
            k_fold = opt.k_fold.split(',')
            k, total = float(k_fold[0]), float(k_fold[1])
            a = (k - 1) / total * len(self.data)
            b = k / total * len(self.data)
            self.data = self.data[:a] + self.data[b:]

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        return self.data[idx]

    def __iter__(self):
        return iter(self.data)


class DGLREDataloader(DataLoader):

    def __init__(self, config, dataset, batch_size, shuffle=False, h_t_limit=1722, relation_num=97, max_word_in_sent=256,
                 max_length=512, negativa_alpha=0.0, sent_negativa_alpha=0.0, dataset_type='train',
                 max_sent_in_doc=25, max_sent_ht_limit=1122, max_entity_in_doc=42, is_print=False, whether_print=True):
        # 2450 for other datatsets
        # max_word_in_sent for other datatsets
        super(DGLREDataloader, self).__init__(dataset, batch_size=batch_size)
        self.shuffle = shuffle
        self.length = len(self.dataset)

        self.max_word_in_sent = max_word_in_sent
        self.max_sent_in_doc = max_sent_in_doc
        self.max_entity_in_doc = max_entity_in_doc
        self.max_sent_ht_limit = max_sent_ht_limit
        self.negativa_alpha = negativa_alpha
        self.sent_negativa_alpha = sent_negativa_alpha
        self.dataset_type = dataset_type
        self.h_t_limit = h_t_limit
        self.relation_num = relation_num
        self.dis2idx = np.zeros((2048), dtype='int64')
        self.init_dis()
        self.is_print = is_print
        self.whether_print = whether_print

        self.max_length = max_length

        self.order = list(range(self.length))

        self.cache_dict = {}

        self.config = config

    def __iter__(self):
        # shuffle
        if self.shuffle:
            random.shuffle(self.order)
            self.data = [self.dataset[idx] for idx in self.order]
        else:
            self.data = self.dataset

        batch_num = math.ceil(self.length / self.batch_size)
        self.batches = [self.data[idx * self.batch_size: min(self.length, (idx + 1) * self.batch_size)]
                        for idx in range(0, batch_num)]
        self.batches_order = [self.order[idx * self.batch_size: min(self.length, (idx + 1) * self.batch_size)]
                              for idx in range(0, batch_num)]

        # begin
        doc_word_ids = torch.LongTensor(self.batch_size, self.max_length).cpu()
        doc_pos_ids = torch.LongTensor(self.batch_size, self.max_length).cpu()
        doc_ner_ids = torch.LongTensor(self.batch_size, self.max_length).cpu()

        doc_mention_ids = torch.LongTensor(self.batch_size, self.max_length).cpu()

        doc_ht_pairs = torch.LongTensor(self.batch_size, self.h_t_limit, 2).cpu()
        doc_ht_pair_distance = torch.LongTensor(self.batch_size, self.h_t_limit).cpu()

        doc_relation_multi_label = torch.Tensor(self.batch_size, self.h_t_limit, self.relation_num).cpu()
        doc_evidence_multi_label = torch.Tensor(self.batch_size, self.h_t_limit, self.max_sent_in_doc).cpu()
        doc_relation_label = torch.LongTensor(self.batch_size, self.h_t_limit).cpu()

        doc_relation_mask = torch.LongTensor(self.batch_size, self.h_t_limit).cpu()
        doc_evidence_mask = torch.LongTensor(self.batch_size, self.h_t_limit).cpu()
        doc_ht_pair_intra_mask = torch.LongTensor(self.batch_size, self.h_t_limit).cpu()

        sent_word_ids = torch.LongTensor(self.batch_size, self.max_sent_in_doc, self.max_word_in_sent).cpu()
        sent_pos_ids = torch.LongTensor(self.batch_size, self.max_sent_in_doc, self.max_word_in_sent).cpu()
        sent_ner_ids = torch.LongTensor(self.batch_size, self.max_sent_in_doc, self.max_word_in_sent).cpu()

        sent_h_mapping = torch.Tensor(self.batch_size, self.max_sent_in_doc, self.max_sent_ht_limit,
                                      self.max_word_in_sent).cpu()
        sent_t_mapping = torch.Tensor(self.batch_size, self.max_sent_in_doc, self.max_sent_ht_limit,
                                      self.max_word_in_sent).cpu()
        # 1.46 - 1.3596
        sent_relation_mask = torch.LongTensor(self.batch_size, self.max_sent_in_doc, self.max_sent_ht_limit).cpu()

        entity_sent_mapping = torch.Tensor(self.batch_size, self.max_entity_in_doc, self.max_sent_in_doc,
                                           self.max_word_in_sent).cpu()
        # [bsz, sent_num, entity_pair_num, sent_ht_pair_num]
        doc2sent_ht_mapping = torch.FloatTensor(self.batch_size, self.max_sent_in_doc, self.h_t_limit, self.max_sent_ht_limit).cpu()

        doc_ht_pair_att_mask_only_intra = torch.BoolTensor(self.batch_size, self.h_t_limit, self.h_t_limit).cpu()

        for idx, minibatch in enumerate(self.batches):

            start_time = time.time()
            cur_bsz = len(minibatch)
            batch_order = self.batches_order[idx]
            for mapping in [

                doc_word_ids, doc_pos_ids, doc_ner_ids, doc_mention_ids,
                doc_ht_pairs, doc_ht_pair_distance, doc_relation_multi_label, doc_evidence_multi_label,
                doc_relation_mask, doc_evidence_mask, doc_ht_pair_intra_mask,

                sent_word_ids, sent_pos_ids, sent_ner_ids,
                sent_h_mapping, sent_t_mapping,
                sent_relation_mask,
                entity_sent_mapping,
                doc2sent_ht_mapping, doc_ht_pair_att_mask_only_intra,

            ]:
                if mapping is not None:
                    mapping.zero_()

            doc_relation_label.fill_(IGNORE_INDEX)
            if self.is_print and self.whether_print:
                log("生成一个document的pre pre花了{:.4f}秒".format(time.time() - start_time))

            max_doc_h_t_cnt = 0
            max_sent_h_t_cnt = 0
            max_sent_num = 0
            max_entity_num = 0

            indexes = []
            titles = []
            docs = []
            docstring = []
            docs_entities = []
            L_vertex = []
            docs_rel_ins = []
            docs_whole_rel_ins = []

            label_list = []
            recall_intra_label_list = []

            graph_list = []
            entity2mention_table = []
            overlaps = []

            for i, example in enumerate(minibatch):
                example_start_time = time.time()
                pre_start_time = time.time()
                title, sentences, entities, labels, \
                doc_na_triple, doc_word_id, doc_pos_id, doc_ner_id, doc_mention_id, \
                sent_na_triple, sent_word_id, sent_pos_id, sent_ner_id, \
                entity2mention_t, graph, \
                sent2ent, sent2label, sent_bert_subwords, doc_bert, docs_others = \
                    example['title'], example['sentences'], example['entities'], example['labels'], \
                    example['doc_na_triple'], example['doc_word_id'], example['doc_pos_id'], example['doc_ner_id'], \
                    example['doc_mention_id'], \
                    example['sent_na_triple'], example['sent_word_id'], example['sent_pos_id'], example[
                        'sent_ner_id'], \
                    example['entity2mention_t'], example['graph'], \
                    example['sent2ent'], example['sent2label'], example['sent_bert_subwords'], example['docs_bert'], example['docs_others']
                indexes.append(batch_order[i])
                titles.append(title)
                if self.config.use_model == 'bert':
                    docs.append(sent_bert_subwords)
                    docstring.append(doc_bert)
                elif self.config.use_model == 'bert_lstm':
                    docs.append(sentences)
                    docstring.append(doc_bert)
                elif self.config.use_model == 'bilstm':
                    docs.append(sentences)
                    docstring.append(docs_others)
                elif self.config.use_model == 'lstm_bert':
                    docs.append(sent_bert_subwords)
                    docstring.append(docs_others)

                docs_entities.append(entities)
                L = len(entities)
                L_vertex.append(L)

                graph_list.append(graph)
                overlaps.append(example['overlap'])  # TODO ?

                entity2mention_table.append(get_cuda(entity2mention_t))

                doc_word_num = doc_word_id.shape[0]

                doc_word_ids[i, :doc_word_num].copy_(torch.from_numpy(doc_word_id))
                doc_pos_ids[i, :doc_word_num].copy_(torch.from_numpy(doc_pos_id))
                doc_ner_ids[i, :doc_word_num].copy_(torch.from_numpy(doc_ner_id))
                doc_mention_ids[i, :doc_word_num].copy_(torch.from_numpy(doc_mention_id))

                max_entity_num = max(L, max_entity_num)
                sent_num, word_num_per_sent = sent_word_id.shape
                max_sent_num = max(max_sent_num, sent_num)
                sent_word_ids[i, :sent_num, :word_num_per_sent].copy_(torch.from_numpy(sent_word_id))
                sent_pos_ids[i, :sent_num, :word_num_per_sent].copy_(torch.from_numpy(sent_pos_id))
                sent_ner_ids[i, :sent_num, :word_num_per_sent].copy_(torch.from_numpy(sent_ner_id))

                doc_idx2label = defaultdict(list)
                doc_label_set = {}
                doc_label_set_evi = {}
                doc_intra_label_set = {}
                for label in labels:
                    head, tail, relation, intrain, evidence, intra = \
                        label['h'], label['t'], label['r'], label['in_train'], label['evidence'], label['intra']
                    rel_list = doc_idx2label[(head, tail)]
                    if relation not in rel_list:
                        rel_list.append(relation)
                    doc_idx2label[(head, tail)] = rel_list
                    doc_label_set[(head, tail, relation)] = intrain
                    doc_label_set_evi[(head, tail, relation)] = evidence
                    doc_intra_label_set[(head, tail, relation)] = intra
                label_list.append(doc_label_set)  # 用于测试的时候计算Ign F1
                recall_intra_label_list.append(doc_intra_label_set)
                doc_pairs = list(doc_idx2label.keys())

                for l, ent in enumerate(entities):
                    exist_mentions = set()
                    for mention in ent:
                        sent_id, pos = int(mention['sent_id']), mention['pos']
                        exist_mentions.add((sent_id, tuple(pos)))
                        entity_sent_mapping[i, l, sent_id, pos[0]:pos[1]] = 1.0 / (pos[1] - pos[0] + 1e-16)
                    entity_sent_mapping[i, l, :, :] = entity_sent_mapping[i, l, :, :] / len(exist_mentions)

                if self.is_print and self.whether_print:
                    log("生成一个document的pre花了{:.4f}秒".format(time.time() - pre_start_time))

                doc_rel_ins = []
                doc_whole_rel_ins = []
                ht_dict = {}

                if self.dataset_type == 'train':
                    doc_start_time = time.time()
                    train_triple = doc_pairs

                    for j, (h_idx, t_idx) in enumerate(train_triple):
                        hlist, tlist = entities[h_idx], entities[t_idx]

                        delta_dis = hlist[0]['global_pos'][0] - tlist[0]['global_pos'][0]
                        if delta_dis < 0:
                            doc_ht_pair_distance[i, j] = -int(self.dis2idx[-delta_dis]) + self.dis_size // 2
                        else:
                            doc_ht_pair_distance[i, j] = int(self.dis2idx[delta_dis]) + self.dis_size // 2

                        label = doc_idx2label[(h_idx, t_idx)]
                        evi_list = []
                        for r in label:
                            doc_relation_multi_label[i, j, r] = 1

                            evidence = doc_label_set_evi[(h_idx, t_idx, r)]
                            evi_list += evidence
                        evi_list = list(set(evi_list))

                        intra = doc_intra_label_set[(h_idx, t_idx, label[0])]
                        if intra:
                            doc_ht_pair_intra_mask[i, j] = 1
                        else:
                            for sentence_index in evi_list:
                                doc_evidence_multi_label[i, j, sentence_index] = 1

                            doc_evidence_mask[i, j] = 1

                        doc_relation_mask[i, j] = 1
                        rt = np.random.randint(len(label))
                        doc_relation_label[i, j] = label[rt]
                        doc_ht_pairs[i, j, :] = torch.Tensor([h_idx + 1, t_idx + 1])
                        ht_dict[(h_idx + 1, t_idx + 1)] = j
                        doc_whole_rel_ins.append((h_idx, t_idx, label, [doc_label_set_evi.get((h_idx, t_idx, r), []) for r in label]))

                    lower_bound = len(doc_na_triple)
                    if self.negativa_alpha > 0.0:
                        random.shuffle(doc_na_triple)
                        lower_bound = int(max(20, len(train_triple) * self.negativa_alpha))

                    for j, (h_idx, t_idx, intra) in enumerate(doc_na_triple[:lower_bound], len(train_triple)):
                        hlist, tlist = entities[h_idx], entities[t_idx]

                        delta_dis = hlist[0]['global_pos'][0] - tlist[0]['global_pos'][0]
                        if delta_dis < 0:
                            doc_ht_pair_distance[i, j] = -int(self.dis2idx[-delta_dis]) + self.dis_size // 2
                        else:
                            doc_ht_pair_distance[i, j] = int(self.dis2idx[delta_dis]) + self.dis_size // 2

                        doc_relation_multi_label[i, j, 0] = 1
                        doc_relation_label[i, j] = 0
                        doc_relation_mask[i, j] = 1

                        if intra:
                            doc_ht_pair_intra_mask[i, j] = 1
                        else:
                            doc_evidence_mask[i, j] = 1

                        doc_ht_pairs[i, j, :] = torch.Tensor([h_idx + 1, t_idx + 1])
                        ht_dict[(h_idx + 1, t_idx + 1)] = j

                        doc_whole_rel_ins.append((h_idx, t_idx, [0], [[]]))

                    max_doc_h_t_cnt = max(max_doc_h_t_cnt, len(train_triple) + lower_bound)

                    if self.is_print and self.whether_print:
                        log("生成一个document的doc花了{:.4f}秒".format(time.time() - doc_start_time))

                    sentence_start_time = time.time()

                    for sent_idx, sentence_labels in enumerate(sent2label):
                        sentence_rel_ins = []

                        sent_idx2label = defaultdict(list)
                        label_set = {}
                        for label in sentence_labels:
                            head, tail, relation, intrain, evidence = \
                                label['h'], label['t'], label['r'], label['in_train'], label['evidence']
                            rel_list = sent_idx2label[(head, tail)]
                            if relation not in rel_list:
                                rel_list.append(relation)
                            sent_idx2label[(head, tail)] = rel_list
                            label_set[(head, tail, relation)] = intrain

                        pairs = list(sent_idx2label.keys())
                        train_triple = pairs
                        na_triple = sent_na_triple[sent_idx]
                        sent_mentions = sent2ent[sent_idx]
                        for j, (h_idx, t_idx) in enumerate(train_triple):
                            # TODO 暂时是一个mention level的表示
                            head, tail = sent_mentions[h_idx], sent_mentions[t_idx]

                            (head_start, head_end), (tail_start, tail_end) = head['pos'], tail['pos']

                            sent_h_mapping[i, sent_idx, j, head_start:head_end] = 1.0 / (head_end - head_start)
                            sent_t_mapping[i, sent_idx, j, tail_start:tail_end] = 1.0 / (tail_end - tail_start)

                            query = (head['ent_id'] + 1, tail['ent_id'] + 1)
                            if query in ht_dict:
                                doc2sent_ht_mapping[i, sent_idx, ht_dict[query], j] = 1

                            label = sent_idx2label[(h_idx, t_idx)]

                            sent_relation_mask[i, sent_idx, j] = 1

                            sentence_rel_ins.append((head['ent_id'], tail['ent_id'], label))

                        lower_bound = len(na_triple)
                        j = len(train_triple)
                        for (h_idx, t_idx) in na_triple[:lower_bound]:
                            head, tail = sent_mentions[h_idx], sent_mentions[t_idx]
                            (head_start, head_end), (tail_start, tail_end) = head['pos'], tail['pos']
                            query = (head['ent_id'] + 1, tail['ent_id'] + 1)
                            if query in ht_dict:
                                doc2sent_ht_mapping[i, sent_idx, ht_dict[query], j] = 1
                            else:
                                continue

                            sent_h_mapping[i, sent_idx, j, head_start:head_end] = 1.0 / (head_end - head_start)
                            sent_t_mapping[i, sent_idx, j, tail_start:tail_end] = 1.0 / (tail_end - tail_start)

                            sent_relation_mask[i, sent_idx, j] = 1

                            sentence_rel_ins.append((head['ent_id'], tail['ent_id'], [0]))

                            j += 1

                        doc_rel_ins.append(sentence_rel_ins)

                        max_sent_h_t_cnt = max(max_sent_h_t_cnt, len(train_triple) + lower_bound)

                    if self.is_print and self.whether_print:
                        log("生成一个document的sentence花了{:.4f}秒".format(time.time() - sentence_start_time))
                else:

                    j = 0
                    for h_idx in range(L):
                        for t_idx in range(L):
                            if h_idx != t_idx:
                                hlist, tlist = entities[h_idx], entities[t_idx]

                                doc_relation_mask[i, j] = 1

                                delta_dis = hlist[0]['global_pos'][0] - tlist[0]['global_pos'][0]
                                if delta_dis < 0:
                                    doc_ht_pair_distance[i, j] = -int(self.dis2idx[-delta_dis]) + self.dis_size // 2
                                else:
                                    doc_ht_pair_distance[i, j] = int(self.dis2idx[delta_dis]) + self.dis_size // 2

                                label = doc_idx2label.get((h_idx, t_idx), [0])
                                if len(label) == 0:
                                    doc_relation_multi_label[i, j, 0] = 1
                                else:
                                    for r in label:
                                        doc_relation_multi_label[i, j, r] = 1

                                intra = False
                                for n1 in hlist:
                                    for n2 in tlist:
                                        if n1['sent_id'] == n2['sent_id']:
                                            intra = True
                                            break
                                    if intra:
                                        break

                                if intra:
                                    doc_ht_pair_intra_mask[i, j] = 1

                                doc_ht_pairs[i, j, :] = torch.Tensor([h_idx + 1, t_idx + 1])

                                ht_dict[(h_idx + 1, t_idx + 1)] = j
                                doc_whole_rel_ins.append((h_idx, t_idx, label, [doc_label_set_evi.get((h_idx, t_idx, r), []) if r != 0 else [] for r in label]))
                                j += 1

                    max_doc_h_t_cnt = max(max_doc_h_t_cnt, j)

                    for sent_idx, sentence_labels in enumerate(sent2label):
                        sentence_rel_ins = []

                        j = 0

                        sent_idx2label = defaultdict(list)
                        label_set = {}

                        for label in sentence_labels:
                            head, tail, relation, intrain, evidence = \
                                label['h'], label['t'], label['r'], label['in_train'], label['evidence']
                            rel_list = sent_idx2label[(head, tail)]
                            if relation not in rel_list:
                                rel_list.append(relation)
                            sent_idx2label[(head, tail)] = rel_list
                            label_set[(head, tail, relation)] = intrain

                        sent_mentions = sent2ent[sent_idx]
                        L_mention = len(sent_mentions)
                        for h_idx in range(L_mention):
                            for t_idx in range(L_mention):
                                h_mention, t_mention = sent_mentions[h_idx], sent_mentions[t_idx]
                                if h_idx != t_idx and h_mention['ent_id'] != t_mention['ent_id']:
                                    head, tail = sent_mentions[h_idx], sent_mentions[t_idx]

                                    (head_start, head_end), (tail_start, tail_end) = head['pos'], tail['pos']

                                    sent_h_mapping[i, sent_idx, j, head_start:head_end] = 1.0 / (head_end - head_start + 1e-16)
                                    sent_t_mapping[i, sent_idx, j, tail_start:tail_end] = 1.0 / (tail_end - tail_start + 1e-16)

                                    query = (head['ent_id'] + 1, tail['ent_id'] + 1)
                                    if query in ht_dict:
                                        doc2sent_ht_mapping[i, sent_idx, ht_dict[query], j] = 1

                                    label = sent_idx2label.get((h_idx, t_idx), [])
                                    if len(label) == 0:
                                        sentence_rel_ins.append((head['ent_id'], tail['ent_id'], [0]))
                                    else:
                                        sentence_rel_ins.append((head['ent_id'], tail['ent_id'], label))

                                    sent_relation_mask[i, sent_idx, j] = 1

                                    j += 1

                        doc_rel_ins.append(sentence_rel_ins)

                        max_sent_h_t_cnt = max(max_sent_h_t_cnt, j)

                att_mask_start_time = time.time()
                for item in ht_dict.items():
                    key_pos_list = []
                    (query_h, query_t), query_pos = item
                    item = list(doc_whole_rel_ins[query_pos])
                    doc_ht_pair_att_mask_only_intra[i, query_pos, query_pos] = 1
                    key_pos_list.append(query_pos)
                    intra = int(doc_ht_pair_intra_mask[i, query_pos].item())
                    if intra == 1:
                        continue
                    for intermidiate_node_idx in range(1, len(entities) + 1):
                        if intermidiate_node_idx == query_h or intermidiate_node_idx == query_t:
                            continue
                        first = (query_h, intermidiate_node_idx)
                        second = (intermidiate_node_idx, query_t)
                        if first in ht_dict and second in ht_dict:
                            first_pos = ht_dict[first]
                            second_pos = ht_dict[second]
                            if intra == 1:
                                # first_intra = int(doc_ht_pair_intra_mask[i, first_pos].item())
                                # second_intra = int(doc_ht_pair_intra_mask[i, second_pos].item())
                                # if first_intra + second_intra == 2:
                                #     doc_ht_pair_att_mask_only_intra[i, query_pos, first_pos] = 1
                                #     doc_ht_pair_att_mask_only_intra[i, query_pos, second_pos] = 1
                                pass
                            else:

                                first_intra = int(doc_ht_pair_intra_mask[i, first_pos].item())
                                second_intra = int(doc_ht_pair_intra_mask[i, second_pos].item())
                                if first_intra == 1 and second_intra == 1:
                                    key_pos_list.append(first_pos)
                                    key_pos_list.append(second_pos)
                                    doc_ht_pair_att_mask_only_intra[i, query_pos, first_pos] = 1
                                    doc_ht_pair_att_mask_only_intra[i, query_pos, second_pos] = 1

                    item.append(key_pos_list)
                    doc_whole_rel_ins[query_pos] = tuple(item)
                docs_rel_ins.append(doc_rel_ins)
                docs_whole_rel_ins.append(doc_whole_rel_ins)
                if self.is_print and self.whether_print:
                    log("生成一个document的att mask花了{:.4f}秒".format(time.time() - att_mask_start_time))
                    log("生成一个document花了{:.4f}秒".format(time.time() - example_start_time))

            post_start_time = time.time()
            doc_word_mask = doc_word_ids > 0
            doc_word_length = doc_word_mask.sum(1)
            doc_max_length = doc_word_length.max()

            sent_word_mask = sent_word_ids > 0
            sent_word_length = torch.sum(sent_word_mask, dim=2)
            max_word_num = torch.max(sent_word_length)
            sent_mask = sent_word_length > 0
            doc_ht_pair_inter_mask = (doc_ht_pair_intra_mask == 0).long() * doc_relation_mask
            if self.is_print and self.whether_print:
                log("生成一个document的post花了{:.4f}秒".format(time.time() - post_start_time))
                log("生成一个batch（包含{}个document）花了{:.4f}秒".format(self.batch_size, time.time() - start_time))
            yield {'doc_words': get_cuda(doc_word_ids[:cur_bsz, :doc_max_length].contiguous()),
                   'doc_pos': get_cuda(doc_pos_ids[:cur_bsz, :doc_max_length].contiguous()),
                   'doc_ner': get_cuda(doc_ner_ids[:cur_bsz, :doc_max_length].contiguous()),

                   'doc_mention': get_cuda(doc_mention_ids[:cur_bsz, :doc_max_length].contiguous()),
                   'doc_word_mask': get_cuda(doc_word_mask[:cur_bsz, :doc_max_length].contiguous()),
                   'doc_word_length': get_cuda(doc_word_length[:cur_bsz].contiguous()),

                   'doc_h_t_pairs': get_cuda(doc_ht_pairs[:cur_bsz, :max_doc_h_t_cnt, :2]),
                   'doc_relation_label': get_cuda(doc_relation_label[:cur_bsz, :max_doc_h_t_cnt]).contiguous(),
                   'doc_relation_multi_label': get_cuda(doc_relation_multi_label[:cur_bsz, :max_doc_h_t_cnt]),
                   'doc_evidence_multi_label': get_cuda(doc_evidence_multi_label[:cur_bsz, :max_doc_h_t_cnt, :max_sent_num]),
                   'doc_relation_mask': get_cuda(doc_relation_mask[:cur_bsz, :max_doc_h_t_cnt]),
                   'doc_evidence_mask': get_cuda(doc_evidence_mask[:cur_bsz, :max_doc_h_t_cnt]),
                   'doc_ht_pair_distance': get_cuda(doc_ht_pair_distance[:cur_bsz, :max_doc_h_t_cnt]),
                   'doc_ht_pair_intra_mask': get_cuda(doc_ht_pair_intra_mask[:cur_bsz, :max_doc_h_t_cnt].contiguous()),
                   'doc_ht_pair_inter_mask': get_cuda(doc_ht_pair_inter_mask[:cur_bsz, :max_doc_h_t_cnt].contiguous()),

                   'sent_words': get_cuda(sent_word_ids[:cur_bsz, :max_sent_num, :max_word_num].contiguous()),
                   'sent_pos': get_cuda(sent_pos_ids[:cur_bsz, :max_sent_num, :max_word_num].contiguous()),
                   'sent_ner': get_cuda(sent_ner_ids[:cur_bsz, :max_sent_num, :max_word_num].contiguous()),

                   'sent_word_mask': get_cuda(
                       sent_word_mask[:cur_bsz, :max_sent_num, :max_word_num].contiguous()),
                   'sent_word_length': get_cuda(sent_word_length[:cur_bsz, :max_sent_num].contiguous()),
                   'sent_mask': get_cuda(sent_mask[:cur_bsz, :max_sent_num].contiguous()),

                   'sent_h_mapping': get_cuda(
                       sent_h_mapping[:cur_bsz, :max_sent_num, :max_sent_h_t_cnt, :max_word_num].contiguous()),
                   'sent_t_mapping': get_cuda(
                       sent_t_mapping[:cur_bsz, :max_sent_num, :max_sent_h_t_cnt, :max_word_num].contiguous()),
                   'sent_relation_mask': get_cuda(sent_relation_mask[:cur_bsz, :max_sent_num, :max_sent_h_t_cnt]),

                   'doc2sent_ht_mapping': get_cuda(
                       doc2sent_ht_mapping[:cur_bsz, :max_sent_num, :max_doc_h_t_cnt, :max_sent_h_t_cnt].contiguous()),
                   'doc_ht_pair_att_mask_only_intra': get_cuda(
                       doc_ht_pair_att_mask_only_intra[:cur_bsz, :max_doc_h_t_cnt, :max_doc_h_t_cnt].contiguous()),
                   'mention_sent_mapping': get_cuda(
                       entity_sent_mapping[:cur_bsz, :max_entity_num, :max_sent_num, :max_word_num].contiguous()),
                   'indexes': indexes,
                   'titles': titles,
                   'docs': docs,
                   'docs_entities': docs_entities,
                   'L_vertex': L_vertex,
                   'docs_rel_ins': docs_rel_ins,
                   'docs_whole_rel_ins': docs_whole_rel_ins,
                   'docstring': docstring,

                   'labels': label_list,
                   'recall_intra_label_list': recall_intra_label_list,

                   'graphs': graph_list,
                   'entity2mention_table': entity2mention_table,
                   'overlaps': overlaps,
                   }

    def init_dis(self):
        self.dis2idx[1] = 1
        self.dis2idx[2:] = 2
        self.dis2idx[4:] = 3
        self.dis2idx[8:] = 4
        self.dis2idx[16:] = 5
        self.dis2idx[32:] = 6
        self.dis2idx[64:] = 7
        self.dis2idx[128:] = 8
        self.dis2idx[256:] = 9
        self.dis2idx[512:] = 10
        self.dis2idx[1024:] = 11
        self.dis_size = 20


class DGLREDataloader4CDR(DataLoader):

    def __init__(self, config, dataset, batch_size, shuffle=False, h_t_limit=1722, relation_num=2, max_word_in_sent=256,
                 max_length=512, negativa_alpha=0.0, sent_negativa_alpha=0.0, dataset_type='train',
                 max_sent_in_doc=25, max_sent_ht_limit=1122, max_entity_in_doc=42, is_print=False, whether_print=True):
        # 2450 for other datatsets
        # max_word_in_sent for other datatsets
        super(DGLREDataloader4CDR, self).__init__(dataset, batch_size=batch_size)
        self.shuffle = shuffle
        self.length = len(self.dataset)

        self.max_word_in_sent = max_word_in_sent
        self.max_sent_in_doc = max_sent_in_doc
        self.max_entity_in_doc = max_entity_in_doc
        self.max_sent_ht_limit = max_sent_ht_limit
        self.negativa_alpha = negativa_alpha
        self.sent_negativa_alpha = sent_negativa_alpha
        self.dataset_type = dataset_type
        self.h_t_limit = h_t_limit
        self.relation_num = relation_num
        self.dis2idx = np.zeros((2048), dtype='int64')
        self.init_dis()
        self.is_print = is_print
        self.whether_print = whether_print

        self.max_length = max_length

        self.order = list(range(self.length))

        self.cache_dict = {}

        self.config = config

    def __iter__(self):
        # shuffle
        if self.shuffle:
            random.shuffle(self.order)
            self.data = [self.dataset[idx] for idx in self.order]
        else:
            self.data = self.dataset

        batch_num = math.ceil(self.length / self.batch_size)
        self.batches = [self.data[idx * self.batch_size: min(self.length, (idx + 1) * self.batch_size)]
                        for idx in range(0, batch_num)]
        self.batches_order = [self.order[idx * self.batch_size: min(self.length, (idx + 1) * self.batch_size)]
                              for idx in range(0, batch_num)]

        # begin
        doc_word_ids = torch.LongTensor(self.batch_size, self.max_length).cpu()
        doc_pos_ids = torch.LongTensor(self.batch_size, self.max_length).cpu()
        doc_ner_ids = torch.LongTensor(self.batch_size, self.max_length).cpu()

        doc_mention_ids = torch.LongTensor(self.batch_size, self.max_length).cpu()

        doc_ht_pairs = torch.LongTensor(self.batch_size, self.h_t_limit, 2).cpu()
        doc_ht_pair_distance = torch.LongTensor(self.batch_size, self.h_t_limit).cpu()

        doc_relation_multi_label = torch.Tensor(self.batch_size, self.h_t_limit, self.relation_num).cpu()
        doc_relation_label = torch.LongTensor(self.batch_size, self.h_t_limit).cpu()

        doc_relation_mask = torch.LongTensor(self.batch_size, self.h_t_limit).cpu()
        doc_ht_pair_intra_mask = torch.LongTensor(self.batch_size, self.h_t_limit).cpu()

        sent_word_ids = torch.LongTensor(self.batch_size, self.max_sent_in_doc, self.max_word_in_sent).cpu()
        sent_pos_ids = torch.LongTensor(self.batch_size, self.max_sent_in_doc, self.max_word_in_sent).cpu()
        sent_ner_ids = torch.LongTensor(self.batch_size, self.max_sent_in_doc, self.max_word_in_sent).cpu()

        sent_h_mapping = torch.Tensor(self.batch_size, self.max_sent_in_doc, self.max_sent_ht_limit,
                                      self.max_word_in_sent).cpu()
        sent_t_mapping = torch.Tensor(self.batch_size, self.max_sent_in_doc, self.max_sent_ht_limit,
                                      self.max_word_in_sent).cpu()
        # 1.46 - 1.3596
        sent_relation_mask = torch.LongTensor(self.batch_size, self.max_sent_in_doc, self.max_sent_ht_limit).cpu()

        entity_sent_mapping = torch.Tensor(self.batch_size, self.max_entity_in_doc, self.max_sent_in_doc,
                                           self.max_word_in_sent).cpu()
        # [bsz, sent_num, entity_pair_num, sent_ht_pair_num]
        doc2sent_ht_mapping = torch.FloatTensor(self.batch_size, self.max_sent_in_doc, self.h_t_limit, self.max_sent_ht_limit).cpu()

        doc_ht_pair_att_mask_only_intra = torch.BoolTensor(self.batch_size, self.h_t_limit, self.h_t_limit).cpu()

        for idx, minibatch in enumerate(self.batches):

            start_time = time.time()
            cur_bsz = len(minibatch)
            batch_order = self.batches_order[idx]
            for mapping in [

                doc_word_ids, doc_pos_ids, doc_ner_ids, doc_mention_ids,
                doc_ht_pairs, doc_ht_pair_distance, doc_relation_multi_label,
                doc_relation_mask, doc_ht_pair_intra_mask,

                sent_word_ids, sent_pos_ids, sent_ner_ids,
                sent_h_mapping, sent_t_mapping,
                sent_relation_mask,
                entity_sent_mapping,
                doc2sent_ht_mapping, doc_ht_pair_att_mask_only_intra,

            ]:
                if mapping is not None:
                    mapping.zero_()

            doc_relation_label.fill_(IGNORE_INDEX)
            if self.is_print and self.whether_print:
                log("生成一个document的pre pre花了{:.4f}秒".format(time.time() - start_time))

            max_doc_h_t_cnt = 0
            max_sent_h_t_cnt = 0
            max_sent_num = 0
            max_entity_num = 0

            indexes = []
            titles = []
            docs = []
            docstring = []
            docs_entities = []
            L_vertex = []
            docs_rel_ins = []
            docs_whole_rel_ins = []

            label_list = []
            recall_intra_label_list = []

            graph_list = []
            entity2mention_table = []
            overlaps = []

            for i, example in enumerate(minibatch):
                example_start_time = time.time()
                pre_start_time = time.time()
                title, sentences, entities, labels, \
                doc_na_triple, doc_word_id, doc_pos_id, doc_ner_id, doc_mention_id, \
                sent_na_triple, sent_word_id, sent_pos_id, sent_ner_id, \
                entity2mention_t, graph, \
                sent2ent, sent2label, sent_bert_subwords, doc_bert, docs_others = \
                    example['title'], example['sentences'], example['entities'], example['labels'], \
                    example['doc_na_triple'], example['doc_word_id'], example['doc_pos_id'], example['doc_ner_id'], \
                    example['doc_mention_id'], \
                    example['sent_na_triple'], example['sent_word_id'], example['sent_pos_id'], example[
                        'sent_ner_id'], \
                    example['entity2mention_t'], example['graph'], \
                    example['sent2ent'], example['sent2label'], example['sent_bert_subwords'], example['docs_bert'], example['docs_others']
                indexes.append(batch_order[i])
                titles.append(title)
                if self.config.use_model == 'bert':
                    docs.append(sent_bert_subwords)
                    docstring.append(doc_bert)
                elif self.config.use_model == 'bert_lstm':
                    docs.append(sentences)
                    docstring.append(doc_bert)
                elif self.config.use_model == 'bilstm':
                    docs.append(sentences)
                    docstring.append(docs_others)
                elif self.config.use_model == 'lstm_bert':
                    docs.append(sent_bert_subwords)
                    docstring.append(docs_others)

                docs_entities.append(entities)
                L = len(entities)
                L_vertex.append(L)

                graph_list.append(graph)
                overlaps.append(example['overlap'])  # TODO ?

                entity2mention_table.append(get_cuda(entity2mention_t))

                doc_word_num = doc_word_id.shape[0]

                doc_word_ids[i, :doc_word_num].copy_(torch.from_numpy(doc_word_id))
                doc_pos_ids[i, :doc_word_num].copy_(torch.from_numpy(doc_pos_id))
                doc_ner_ids[i, :doc_word_num].copy_(torch.from_numpy(doc_ner_id))
                doc_mention_ids[i, :doc_word_num].copy_(torch.from_numpy(doc_mention_id))

                max_entity_num = max(L, max_entity_num)
                sent_num, word_num_per_sent = sent_word_id.shape
                max_sent_num = max(max_sent_num, sent_num)
                sent_word_ids[i, :sent_num, :word_num_per_sent].copy_(torch.from_numpy(sent_word_id))
                sent_pos_ids[i, :sent_num, :word_num_per_sent].copy_(torch.from_numpy(sent_pos_id))
                sent_ner_ids[i, :sent_num, :word_num_per_sent].copy_(torch.from_numpy(sent_ner_id))

                doc_idx2label = defaultdict(list)
                doc_label_set = {}
                doc_label_set_evi = {}
                doc_intra_label_set = {}
                for label in labels:
                    head, tail, relation, intrain, evidence, intra = \
                        label['h'], label['t'], label['r'], label['in_train'], label['evidence'], label['intra']
                    rel_list = doc_idx2label[(head, tail)]
                    if relation not in rel_list:
                        rel_list.append(relation)
                    doc_idx2label[(head, tail)] = rel_list
                    doc_label_set[(head, tail, relation)] = intrain
                    doc_label_set_evi[(head, tail, relation)] = evidence
                    doc_intra_label_set[(head, tail, relation)] = intra
                label_list.append(doc_label_set)  # 用于测试的时候计算Ign F1
                recall_intra_label_list.append(doc_intra_label_set)
                doc_pairs = list(doc_idx2label.keys())

                for l, ent in enumerate(entities):
                    exist_mentions = set()
                    for mention in ent:
                        sent_id, pos = int(mention['sent_id']), mention['pos']
                        exist_mentions.add((sent_id, tuple(pos)))
                        entity_sent_mapping[i, l, sent_id, pos[0]:pos[1]] = 1.0 / (pos[1] - pos[0] + 1e-16)
                    entity_sent_mapping[i, l, :, :] = entity_sent_mapping[i, l, :, :] / len(exist_mentions)

                if self.is_print and self.whether_print:
                    log("生成一个document的pre花了{:.4f}秒".format(time.time() - pre_start_time))

                doc_rel_ins = []
                doc_whole_rel_ins = []
                ht_dict = {}

                if self.dataset_type == 'train':
                    doc_start_time = time.time()
                    train_triple = doc_pairs

                    for j, (h_idx, t_idx) in enumerate(train_triple):
                        hlist, tlist = entities[h_idx], entities[t_idx]

                        delta_dis = hlist[0]['global_pos'][0] - tlist[0]['global_pos'][0]
                        if delta_dis < 0:
                            doc_ht_pair_distance[i, j] = -int(self.dis2idx[-delta_dis]) + self.dis_size // 2
                        else:
                            doc_ht_pair_distance[i, j] = int(self.dis2idx[delta_dis]) + self.dis_size // 2

                        label = doc_idx2label[(h_idx, t_idx)]
                        for r in label:
                            doc_relation_multi_label[i, j, r] = 1

                        intra = doc_intra_label_set[(h_idx, t_idx, label[0])]
                        if intra:
                            doc_ht_pair_intra_mask[i, j] = 1

                        doc_relation_mask[i, j] = 1
                        rt = np.random.randint(len(label))
                        doc_relation_label[i, j] = label[rt]
                        doc_ht_pairs[i, j, :] = torch.Tensor([h_idx + 1, t_idx + 1])
                        ht_dict[(h_idx + 1, t_idx + 1)] = j
                        doc_whole_rel_ins.append((h_idx, t_idx, label, [doc_label_set_evi.get((h_idx, t_idx, r), []) for r in label]))

                    lower_bound = len(doc_na_triple)
                    # if self.negativa_alpha > 0.0:
                    #     random.shuffle(doc_na_triple)
                    #     lower_bound = int(max(20, len(train_triple) * self.negativa_alpha))

                    for j, (h_idx, t_idx, intra) in enumerate(doc_na_triple[:lower_bound], len(train_triple)):
                        hlist, tlist = entities[h_idx], entities[t_idx]

                        delta_dis = hlist[0]['global_pos'][0] - tlist[0]['global_pos'][0]
                        if delta_dis < 0:
                            doc_ht_pair_distance[i, j] = -int(self.dis2idx[-delta_dis]) + self.dis_size // 2
                        else:
                            doc_ht_pair_distance[i, j] = int(self.dis2idx[delta_dis]) + self.dis_size // 2

                        doc_relation_multi_label[i, j, 0] = 1
                        doc_relation_label[i, j] = 0
                        doc_relation_mask[i, j] = 1

                        if intra:
                            doc_ht_pair_intra_mask[i, j] = 1

                        doc_ht_pairs[i, j, :] = torch.Tensor([h_idx + 1, t_idx + 1])
                        ht_dict[(h_idx + 1, t_idx + 1)] = j

                        doc_whole_rel_ins.append((h_idx, t_idx, [0], [[]]))

                    max_doc_h_t_cnt = max(max_doc_h_t_cnt, len(train_triple) + lower_bound)

                    if self.is_print and self.whether_print:
                        log("生成一个document的doc花了{:.4f}秒".format(time.time() - doc_start_time))

                    sentence_start_time = time.time()

                    for sent_idx, sentence_labels in enumerate(sent2label):
                        sentence_rel_ins = []

                        sent_idx2label = defaultdict(list)
                        label_set = {}
                        for label in sentence_labels:
                            head, tail, relation, intrain, evidence = \
                                label['h'], label['t'], label['r'], label.get('in_train', []), label['evidence']
                            rel_list = sent_idx2label[(head, tail)]
                            if relation not in rel_list:
                                rel_list.append(relation)
                            sent_idx2label[(head, tail)] = rel_list
                            label_set[(head, tail, relation)] = intrain

                        pairs = list(sent_idx2label.keys())
                        train_triple = pairs
                        na_triple = sent_na_triple[sent_idx]
                        sent_mentions = sent2ent[sent_idx]
                        for j, (h_idx, t_idx) in enumerate(train_triple):
                            # TODO 暂时是一个mention level的表示
                            head, tail = sent_mentions[h_idx], sent_mentions[t_idx]

                            (head_start, head_end), (tail_start, tail_end) = head['pos'], tail['pos']

                            sent_h_mapping[i, sent_idx, j, head_start:head_end] = 1.0 / (head_end - head_start)
                            sent_t_mapping[i, sent_idx, j, tail_start:tail_end] = 1.0 / (tail_end - tail_start)

                            query = (head['ent_id'] + 1, tail['ent_id'] + 1)
                            if query in ht_dict:
                                doc2sent_ht_mapping[i, sent_idx, ht_dict[query], j] = 1

                            label = sent_idx2label[(h_idx, t_idx)]

                            sent_relation_mask[i, sent_idx, j] = 1

                            sentence_rel_ins.append((head['ent_id'], tail['ent_id'], label))

                        lower_bound = len(na_triple)
                        j = len(train_triple)
                        for (h_idx, t_idx) in na_triple[:lower_bound]:
                            head, tail = sent_mentions[h_idx], sent_mentions[t_idx]
                            (head_start, head_end), (tail_start, tail_end) = head['pos'], tail['pos']
                            query = (head['ent_id'] + 1, tail['ent_id'] + 1)
                            if query in ht_dict:
                                doc2sent_ht_mapping[i, sent_idx, ht_dict[query], j] = 1
                            else:
                                continue

                            sent_h_mapping[i, sent_idx, j, head_start:head_end] = 1.0 / (head_end - head_start)
                            sent_t_mapping[i, sent_idx, j, tail_start:tail_end] = 1.0 / (tail_end - tail_start)

                            sent_relation_mask[i, sent_idx, j] = 1

                            sentence_rel_ins.append((head['ent_id'], tail['ent_id'], [0]))

                            j += 1

                        doc_rel_ins.append(sentence_rel_ins)

                        max_sent_h_t_cnt = max(max_sent_h_t_cnt, len(train_triple) + lower_bound)

                    if self.is_print and self.whether_print:
                        log("生成一个document的sentence花了{:.4f}秒".format(time.time() - sentence_start_time))
                else:

                    j = 0
                    for h_idx in range(L):
                        for t_idx in range(L):
                            if h_idx != t_idx:
                                hlist, tlist = entities[h_idx], entities[t_idx]

                                if hlist[0]['type'] != 'Chemical' or tlist[0]['type'] != 'Disease':
                                    continue

                                doc_relation_mask[i, j] = 1

                                delta_dis = hlist[0]['global_pos'][0] - tlist[0]['global_pos'][0]
                                if delta_dis < 0:
                                    doc_ht_pair_distance[i, j] = -int(self.dis2idx[-delta_dis]) + self.dis_size // 2
                                else:
                                    doc_ht_pair_distance[i, j] = int(self.dis2idx[delta_dis]) + self.dis_size // 2

                                label = doc_idx2label.get((h_idx, t_idx), [0])
                                if len(label) == 0:
                                    doc_relation_multi_label[i, j, 0] = 1
                                else:
                                    for r in label:
                                        doc_relation_multi_label[i, j, r] = 1

                                intra = False
                                for n1 in hlist:
                                    for n2 in tlist:
                                        if n1['sent_id'] == n2['sent_id']:
                                            intra = True
                                            break
                                    if intra:
                                        break

                                if intra:
                                    doc_ht_pair_intra_mask[i, j] = 1

                                doc_ht_pairs[i, j, :] = torch.Tensor([h_idx + 1, t_idx + 1])

                                ht_dict[(h_idx + 1, t_idx + 1)] = j
                                doc_whole_rel_ins.append((h_idx, t_idx, label, [doc_label_set_evi.get((h_idx, t_idx, r), []) if r != 0 else [] for r in label]))
                                j += 1

                    max_doc_h_t_cnt = max(max_doc_h_t_cnt, j)

                    for sent_idx, sentence_labels in enumerate(sent2label):
                        sentence_rel_ins = []

                        j = 0

                        sent_idx2label = defaultdict(list)
                        label_set = {}

                        for label in sentence_labels:
                            head, tail, relation, intrain, evidence = \
                                label['h'], label['t'], label['r'], label.get('in_train', []), label['evidence']
                            rel_list = sent_idx2label[(head, tail)]
                            if relation not in rel_list:
                                rel_list.append(relation)
                            sent_idx2label[(head, tail)] = rel_list
                            label_set[(head, tail, relation)] = intrain

                        sent_mentions = sent2ent[sent_idx]
                        L_mention = len(sent_mentions)
                        for h_idx in range(L_mention):
                            for t_idx in range(L_mention):
                                h_mention, t_mention = sent_mentions[h_idx], sent_mentions[t_idx]
                                if h_idx != t_idx and h_mention['ent_id'] != t_mention['ent_id']:
                                    head, tail = sent_mentions[h_idx], sent_mentions[t_idx]

                                    (head_start, head_end), (tail_start, tail_end) = head['pos'], tail['pos']

                                    sent_h_mapping[i, sent_idx, j, head_start:head_end] = 1.0 / (head_end - head_start + 1e-16)
                                    sent_t_mapping[i, sent_idx, j, tail_start:tail_end] = 1.0 / (tail_end - tail_start + 1e-16)

                                    query = (head['ent_id'] + 1, tail['ent_id'] + 1)
                                    if query in ht_dict:
                                        doc2sent_ht_mapping[i, sent_idx, ht_dict[query], j] = 1

                                    label = sent_idx2label.get((h_idx, t_idx), [])
                                    if len(label) == 0:
                                        sentence_rel_ins.append((head['ent_id'], tail['ent_id'], [0]))
                                    else:
                                        sentence_rel_ins.append((head['ent_id'], tail['ent_id'], label))

                                    sent_relation_mask[i, sent_idx, j] = 1

                                    j += 1

                        doc_rel_ins.append(sentence_rel_ins)

                        max_sent_h_t_cnt = max(max_sent_h_t_cnt, j)

                att_mask_start_time = time.time()
                for item in ht_dict.items():
                    key_pos_list = []
                    (query_h, query_t), query_pos = item
                    item = list(doc_whole_rel_ins[query_pos])
                    doc_ht_pair_att_mask_only_intra[i, query_pos, query_pos] = 1
                    key_pos_list.append(query_pos)
                    intra = int(doc_ht_pair_intra_mask[i, query_pos].item())
                    if intra == 1:
                        continue
                    for intermidiate_node_idx in range(1, len(entities) + 1):
                        if intermidiate_node_idx == query_h or intermidiate_node_idx == query_t:
                            continue
                        first = (query_h, intermidiate_node_idx)
                        second = (intermidiate_node_idx, query_t)
                        if first in ht_dict and second in ht_dict:
                            first_pos = ht_dict[first]
                            second_pos = ht_dict[second]
                            if intra == 1:
                                # first_intra = int(doc_ht_pair_intra_mask[i, first_pos].item())
                                # second_intra = int(doc_ht_pair_intra_mask[i, second_pos].item())
                                # if first_intra + second_intra == 2:
                                #     doc_ht_pair_att_mask_only_intra[i, query_pos, first_pos] = 1
                                #     doc_ht_pair_att_mask_only_intra[i, query_pos, second_pos] = 1
                                pass
                            else:

                                first_intra = int(doc_ht_pair_intra_mask[i, first_pos].item())
                                second_intra = int(doc_ht_pair_intra_mask[i, second_pos].item())
                                if first_intra == 1 and second_intra == 1:
                                    key_pos_list.append(first_pos)
                                    key_pos_list.append(second_pos)
                                    doc_ht_pair_att_mask_only_intra[i, query_pos, first_pos] = 1
                                    doc_ht_pair_att_mask_only_intra[i, query_pos, second_pos] = 1

                    item.append(key_pos_list)
                    doc_whole_rel_ins[query_pos] = tuple(item)
                docs_rel_ins.append(doc_rel_ins)
                docs_whole_rel_ins.append(doc_whole_rel_ins)
                if self.is_print and self.whether_print:
                    log("生成一个document的att mask花了{:.4f}秒".format(time.time() - att_mask_start_time))
                    log("生成一个document花了{:.4f}秒".format(time.time() - example_start_time))

            post_start_time = time.time()
            doc_word_mask = doc_word_ids > 0
            doc_word_length = doc_word_mask.sum(1)
            doc_max_length = doc_word_length.max()

            sent_word_mask = sent_word_ids > 0
            sent_word_length = torch.sum(sent_word_mask, dim=2)
            max_word_num = torch.max(sent_word_length)
            sent_mask = sent_word_length > 0
            doc_ht_pair_inter_mask = (doc_ht_pair_intra_mask == 0).long() * doc_relation_mask
            if self.is_print and self.whether_print:
                log("生成一个document的post花了{:.4f}秒".format(time.time() - post_start_time))
                log("生成一个batch（包含{}个document）花了{:.4f}秒".format(self.batch_size, time.time() - start_time))
            yield {'doc_words': get_cuda(doc_word_ids[:cur_bsz, :doc_max_length].contiguous()),
                   'doc_pos': get_cuda(doc_pos_ids[:cur_bsz, :doc_max_length].contiguous()),
                   'doc_ner': get_cuda(doc_ner_ids[:cur_bsz, :doc_max_length].contiguous()),

                   'doc_mention': get_cuda(doc_mention_ids[:cur_bsz, :doc_max_length].contiguous()),
                   'doc_word_mask': get_cuda(doc_word_mask[:cur_bsz, :doc_max_length].contiguous()),
                   'doc_word_length': get_cuda(doc_word_length[:cur_bsz].contiguous()),

                   'doc_h_t_pairs': get_cuda(doc_ht_pairs[:cur_bsz, :max_doc_h_t_cnt, :2]),
                   'doc_relation_label': get_cuda(doc_relation_label[:cur_bsz, :max_doc_h_t_cnt]).contiguous(),
                   'doc_relation_multi_label': get_cuda(doc_relation_multi_label[:cur_bsz, :max_doc_h_t_cnt]),
                   'doc_relation_mask': get_cuda(doc_relation_mask[:cur_bsz, :max_doc_h_t_cnt]),
                   'doc_ht_pair_distance': get_cuda(doc_ht_pair_distance[:cur_bsz, :max_doc_h_t_cnt]),
                   'doc_ht_pair_intra_mask': get_cuda(doc_ht_pair_intra_mask[:cur_bsz, :max_doc_h_t_cnt].contiguous()),
                   'doc_ht_pair_inter_mask': get_cuda(doc_ht_pair_inter_mask[:cur_bsz, :max_doc_h_t_cnt].contiguous()),

                   'sent_words': get_cuda(sent_word_ids[:cur_bsz, :max_sent_num, :max_word_num].contiguous()),
                   'sent_pos': get_cuda(sent_pos_ids[:cur_bsz, :max_sent_num, :max_word_num].contiguous()),
                   'sent_ner': get_cuda(sent_ner_ids[:cur_bsz, :max_sent_num, :max_word_num].contiguous()),

                   'sent_word_mask': get_cuda(
                       sent_word_mask[:cur_bsz, :max_sent_num, :max_word_num].contiguous()),
                   'sent_word_length': get_cuda(sent_word_length[:cur_bsz, :max_sent_num].contiguous()),
                   'sent_mask': get_cuda(sent_mask[:cur_bsz, :max_sent_num].contiguous()),

                   'sent_h_mapping': get_cuda(
                       sent_h_mapping[:cur_bsz, :max_sent_num, :max_sent_h_t_cnt, :max_word_num].contiguous()),
                   'sent_t_mapping': get_cuda(
                       sent_t_mapping[:cur_bsz, :max_sent_num, :max_sent_h_t_cnt, :max_word_num].contiguous()),
                   'sent_relation_mask': get_cuda(sent_relation_mask[:cur_bsz, :max_sent_num, :max_sent_h_t_cnt]),

                   'doc2sent_ht_mapping': get_cuda(
                       doc2sent_ht_mapping[:cur_bsz, :max_sent_num, :max_doc_h_t_cnt, :max_sent_h_t_cnt].contiguous()),
                   'doc_ht_pair_att_mask_only_intra': get_cuda(
                       doc_ht_pair_att_mask_only_intra[:cur_bsz, :max_doc_h_t_cnt, :max_doc_h_t_cnt].contiguous()),
                   'mention_sent_mapping': get_cuda(
                       entity_sent_mapping[:cur_bsz, :max_entity_num, :max_sent_num, :max_word_num].contiguous()),
                   'indexes': indexes,
                   'titles': titles,
                   'docs': docs,
                   'docs_entities': docs_entities,
                   'L_vertex': L_vertex,
                   'docs_rel_ins': docs_rel_ins,
                   'docs_whole_rel_ins': docs_whole_rel_ins,
                   'docstring': docstring,

                   'labels': label_list,
                   'recall_intra_label_list': recall_intra_label_list,

                   'graphs': graph_list,
                   'entity2mention_table': entity2mention_table,
                   'overlaps': overlaps,
                   }

    def init_dis(self):
        self.dis2idx[1] = 1
        self.dis2idx[2:] = 2
        self.dis2idx[4:] = 3
        self.dis2idx[8:] = 4
        self.dis2idx[16:] = 5
        self.dis2idx[32:] = 6
        self.dis2idx[64:] = 7
        self.dis2idx[128:] = 8
        self.dis2idx[256:] = 9
        self.dis2idx[512:] = 10
        self.dis2idx[1024:] = 11
        self.dis_size = 20
