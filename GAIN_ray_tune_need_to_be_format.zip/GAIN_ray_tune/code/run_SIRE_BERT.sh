#! /bin/bash
export CUDA_VISIBLE_DEVICES=${1--1}

# -------------------BERT_base Training Shell Script--------------------

load_model=${2--1}
PLM=bert-base
# bert_lstm/bert/lstm_bert
use_model=bert
settings=${use_model}

PLM_hidden_size=768
# 50/100/200/300
word_emb_size=200
doc_lstm_hidden_size=404
sent_lstm_hidden_size=404
reduction_dim=300
lstm_dropout=0.3
dropout=0.5
dropout_entity=0.0

optimizer=adamW
lr=0.001
weight_decay=0.0001
batch_size=2
grad_period=4
test_batch_size=2
epoch=360
test_epoch=10
log_step=20
save_model_freq=3

negativa_alpha=4.0
# weighted/weighted2/concat/concat2
aggregation_method=weighted
# sigmoid/softmax/concat
intra_ctx_method=softmax
inter_ctx_method=concat_sigmoid
rel_att_method=softmax
# sqrt/self/1
intra_scaling_method=sqrt
inter_scaling_method=sqrt
rel_scaling_method=sqrt
# share/separate
predict_method=share
# relu/leaky_relu/gelu/tanh
activation=relu

intra_K=4
num_warmup_steps=500
gcn_layers=4
alpha_intra=0.1
alpha_inter=0.0
seed=2021
dis_size=128
entity_type_size_in_input=128
entity_id_size=128

model_name=${settings}

nohup python3 -u train.py \
--train_set ../data/train_annotated.json \
--train_set_save ../data/prepro_data/train_${use_model}.pkl \
--dev_set ../data/dev.json \
--dev_set_save ../data/prepro_data/dev_${use_model}.pkl \
--test_set ../data/test.json \
--test_set_save ../data/prepro_data/test_${use_model}.pkl \
--use_model ${use_model} \
--bert_path ../PLM/${PLM}-uncased \
--model_name ${model_name} \
--lr ${lr} \
--optimizer ${optimizer} \
--weight_decay ${weight_decay} \
--activation ${activation} \
--batch_size ${batch_size} \
--grad_period ${grad_period} \
--test_batch_size ${test_batch_size} \
--epoch ${epoch} \
--test_epoch ${test_epoch} \
--log_step ${log_step} \
--save_model_freq ${save_model_freq} \
--negativa_alpha ${negativa_alpha} \
--bert_hid_size ${PLM_hidden_size} \
--dis_size ${dis_size} \
--entity_type_size_in_input ${entity_type_size_in_input} \
--entity_id_size ${entity_id_size} \
--word_emb_size ${word_emb_size} \
--doc_lstm_hidden_size ${doc_lstm_hidden_size} \
--sent_lstm_hidden_size ${sent_lstm_hidden_size} \
--reduction_dim ${reduction_dim} \
--lstm_dropout ${lstm_dropout} \
--gcn_layers ${gcn_layers} \
--dropout_entity ${dropout_entity} \
--dropout ${dropout} \
--alpha_intra ${alpha_intra} \
--alpha_inter ${alpha_inter} \
--use_entity_type_in_input \
--use_entity_id \
--use_distance \
--finetune_PLM \
--warmup \
--num_warmup_steps ${num_warmup_steps} \
--add_inter_linear \
--K ${intra_K} \
--aggregation_method ${aggregation_method} \
--intra_ctx_method ${intra_ctx_method} \
--inter_ctx_method ${inter_ctx_method} \
--rel_att_method ${rel_att_method} \
--intra_scaling_method ${intra_scaling_method} \
--inter_scaling_method ${inter_scaling_method} \
--rel_scaling_method ${rel_scaling_method} \
--predict_method ${predict_method} \
--pretrain_model ${load_model} \
--seed ${seed} \
--is_print_att \
--multi_avg \
--evidence_loss \
>>logs/train_${model_name}.log 2>&1 &

# -------------------additional options--------------------

# option below is used to resume training, it should be add into the shell scripts above
# --pretrain_model checkpoint/BERT_base_10.pt \
# --warmup \
# --num_warmup_steps ${num_warmup_steps} \
# --evidence_loss \
