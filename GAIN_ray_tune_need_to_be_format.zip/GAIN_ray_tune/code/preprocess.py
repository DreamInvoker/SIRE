from collections import defaultdict


def preprocess(raw_doc, evi_count=0, total=0, null=0, other_evi=0, is_print=False, rel_info=None):
    title, sents, entities, labels = raw_doc['title'], raw_doc['sents'], raw_doc['vertexSet'], raw_doc.get('labels', [])
    sent2ent_dict = defaultdict(list)
    sent2label_dict = defaultdict(list)
    for idx, entity in enumerate(entities):
        for mention in entity:
            sent_id = int(mention['sent_id'])
            sent2ent_list = sent2ent_dict.get(sent_id, [])
            mention.update({'ent_id': idx})
            if mention not in sent2ent_list:
                sent2ent_list.append(mention)
                sent2ent_dict[sent_id] = sent2ent_list
    sent_num = len(sents)
    sent2ent = []
    for i in range(sent_num):
        sent2ent_list = list(sent2ent_dict.get(i, []))
        sent2ent_list.sort(key=lambda x: x['ent_id'])
        sent2ent.append(sent2ent_list)

    for label in labels:
        head_entity, tail_entity, relation, evidence = int(label['h']), int(label['t']), label['r'], label['evidence']
        head_mentions, tail_mentions = entities[head_entity], entities[tail_entity]
        for head_mention in head_mentions:
            for tail_mention in tail_mentions:
                head_sent_id, tail_sent_id = int(head_mention['sent_id']), int(tail_mention['sent_id'])
                if head_sent_id == tail_sent_id:
                    sent2label_list = sent2label_dict.get(head_sent_id, [])
                    for mention_i_idx, mention_i in enumerate(sent2ent[head_sent_id]):
                        for mention_j_idx, mention_j in enumerate(sent2ent[head_sent_id]):
                            if mention_i_idx != mention_j_idx and mention_i['ent_id'] == head_entity \
                                    and mention_j['ent_id'] == tail_entity:
                                rel_ins = {
                                    'h': mention_i_idx,
                                    't': mention_j_idx,
                                    'r': relation,
                                    'evidence': evidence
                                }

                                if rel_ins not in sent2label_list:
                                    sent2label_list.append(rel_ins)
                                    flag = False
                                    if head_sent_id in evidence:
                                        evi_count += 1
                                        if len(evidence) > 1:
                                            other_evi += 1
                                    elif len(evidence) == 0:
                                        null += 1
                                        flag = True
                                    else:
                                        flag = True
                                    if is_print and flag:
                                        print('-' * 20 + "第" + str(
                                            total - evi_count + 1) + "个例子" + '-' * 20 + '\n' + "title:{}\n{}\n第{}句中\n头实体：{}[{}]\n尾实体：{}[{}]\n关系：{}\nevidence：{}\n\n".format(
                                            title, '\n'.join(['[{}]'.format(idx + 1) + ' '.join(s) for idx, s in
                                                              enumerate(sents)]),
                                            head_sent_id + 1, mention_i['name'], mention_i['type'],
                                            mention_j['name'], mention_j['type'], rel_info[relation],
                                            [e + 1 for e in evidence]))
                                    total += 1
                    sent2label_dict[head_sent_id] = sent2label_list
    sent2label = []
    for i in range(sent_num):
        sent2label.append(sent2label_dict.get(i, []))

    raw_doc.update({
        'sent2ent': sent2ent,
        'sent2label': sent2label
    })

    return raw_doc, evi_count, total, null, other_evi


if __name__ == '__main__':
    import json

    fr = open('../data/dev.json', 'r', encoding='utf-8')
    data = json.load(fr)
    evi_count, total, null, other_evi = 0, 0, 0, 0
    rel_info = json.load(open('../data/rel_info.json', 'r', encoding='utf-8'))
    for i in range(len(data)):
        _, evi_count, total, null, other_evi = preprocess(data[i], evi_count, total, null, other_evi, is_print=True,
                                                          rel_info=rel_info)
    print('evi:{}/{}={:.4f}%'.format(evi_count, total, 100 * evi_count / total))
    print('other_evi:{}/{}={:.4f}%'.format(other_evi, total, 100 * other_evi / total))
    print('null:{}/{}={:.4f}%'.format(null, total, 100 * null / total))
    # print(json.dumps(preprocess(data[0]), indent=4))
    fr.close()
