import argparse
import json
import os

from ray import tune
import numpy as np

dataset_dir = os.path.abspath('../data/')
prepro_dir = os.path.abspath(os.path.join(dataset_dir, 'prepro_data/'))
if not os.path.exists(prepro_dir):
    os.mkdir(prepro_dir)

rel2id = json.load(open(os.path.join(dataset_dir, 'rel2id.json'), "r"))
rel_info = json.load(open(os.path.join(dataset_dir, 'rel_info.json'), "r"))
id2rel = {v: k for k, v in rel2id.items()}
word2id = json.load(open(os.path.join(dataset_dir, 'word2id.json'), "r"))
ner2id = json.load(open(os.path.join(dataset_dir, 'ner2id.json'), "r"))


def get_opt():
    parser = argparse.ArgumentParser()

    # datasets path
    parser.add_argument('--train_set', type=str, default=os.path.join(dataset_dir, 'train_annotated.json'))
    parser.add_argument('--dev_set', type=str, default=os.path.join(dataset_dir, 'dev.json'))
    parser.add_argument('--test_set', type=str, default=os.path.join(dataset_dir, 'test.json'))

    # save path of preprocessed datasets
    parser.add_argument('--train_set_save', type=str, default=os.path.join(prepro_dir, 'train.pkl'))
    parser.add_argument('--dev_set_save', type=str, default=os.path.join(prepro_dir, 'dev.pkl'))
    parser.add_argument('--test_set_save', type=str, default=os.path.join(prepro_dir, 'test.pkl'))

    # checkpoints
    parser.add_argument('--checkpoint_dir', type=str, default='checkpoint')
    parser.add_argument('--model_name', type=str, default='train_model')
    parser.add_argument('--pretrain_model', type=str, default='-1')

    # task/Dataset-related
    parser.add_argument('--vocabulary_size', type=int, default=200000)
    parser.add_argument('--relation_num', type=int, default=97)
    parser.add_argument('--entity_type_num', type=int, default=7)
    parser.add_argument('--max_entity_num', type=int, default=80)

    # padding
    parser.add_argument('--word_pad', type=int, default=0)
    parser.add_argument('--entity_type_pad', type=int, default=0)
    parser.add_argument('--entity_id_pad', type=int, default=0)

    # word embedding
    parser.add_argument('--word_emb_size', type=int, default=50)
    parser.add_argument('--glove_version', type=str, default='glove.6B.')
    parser.add_argument('--pre_train_word', action='store_true')
    parser.add_argument('--data_word_vec', type=str)
    parser.add_argument('--finetune_word', action='store_true')

    # entity_type_in_input_emb
    parser.add_argument('--use_entity_type_in_input', action='store_true')
    parser.add_argument('--entity_type_size_in_input', type=int, default=20)

    # entity_type_in_output_emb
    parser.add_argument('--explicit_ner_type', action='store_true', default=True)
    parser.add_argument('--explicit_ner_type_size', type=int, default=128)

    # entity id embedding, i.e., coreference embedding in DocRED original paper
    parser.add_argument('--use_entity_id', action='store_true')
    parser.add_argument('--entity_id_size', type=int, default=20)

    # distance embedding, i.e., coreference embedding in DocRED original paper
    parser.add_argument('--use_distance', action='store_true')
    parser.add_argument('--dis_size', type=int, default=128)

    # BiLSTM
    parser.add_argument('--nlayers', type=int, default=1)
    parser.add_argument('--doc_lstm_hidden_size', type=int, default=4)
    parser.add_argument('--sent_lstm_hidden_size', type=int, default=4)
    parser.add_argument('--lstm_dropout', type=float, default=0.1)

    # training settings
    parser.add_argument('--lr', type=float, default=0.001)
    parser.add_argument('--batch_size', type=int, default=1)
    parser.add_argument('--grad_period', type=int, default=1)
    parser.add_argument('--test_batch_size', type=int, default=1)
    parser.add_argument('--epoch', type=int, default=10)
    parser.add_argument('--test_epoch', type=int, default=1)
    parser.add_argument('--weight_decay', type=float, default=0.0001)
    parser.add_argument('--negativa_alpha', type=float, default=0.0)  # negative example nums v.s positive example num
    parser.add_argument('--log_step', type=int, default=10)
    parser.add_argument('--save_model_freq', type=int, default=1)

    # gcn
    parser.add_argument('--reduction_dim', type=int, default=256)

    parser.add_argument('--mention_drop', action='store_true')
    parser.add_argument('--mention_mean', action='store_true')
    parser.add_argument('--gcn_layers', type=int, default=2)
    parser.add_argument('--gcn_dim', type=int, default=8)
    parser.add_argument('--dropout', type=float, default=0.2)
    parser.add_argument('--dropout_entity', type=float, default=0.0)

    parser.add_argument('--activation', type=str, default="relu")

    # BERT
    parser.add_argument('--bert_hid_size', type=int, default=768)
    parser.add_argument('--bert_path', type=str, default="")
    parser.add_argument('--finetune_PLM', action='store_true')
    parser.add_argument('--coslr', action='store_true')
    parser.add_argument('--warmup', action='store_true')
    parser.add_argument('--num_warmup_steps', type=int, default=200)
    parser.add_argument('--clip', type=float, default=-1)

    parser.add_argument('--k_fold', type=str, default="none")

    # use BiLSTM / BERT encoder, default: BiLSTM encoder
    parser.add_argument('--use_model', type=str, default="bilstm", choices=['bilstm', 'bert', 'bert_lstm', 'lstm_bert'],
                        help='you should choose between bert and bilstm')

    parser.add_argument('--optimizer', type=str, default="adamW", choices=[
        'adadelta',
        'adagrad',
        'adam',
        'adamW',
        'sparse_adam',
        'adamax',
        'asgd',
        'rmsprop',
        'rprop',
        'sgd',
    ],
                        help='choose an optimizer')

    # binary classification threshold, automatically find optimal threshold when -1
    parser.add_argument('--input_intra_theta', type=float, default=-1)
    parser.add_argument('--input_inter_theta', type=float, default=-1)

    parser.add_argument('--is_print', action='store_true')
    parser.add_argument('--is_print_att', action='store_true')

    parser.add_argument('--alpha_intra', type=float, default=0.1)
    parser.add_argument('--alpha_inter', type=float, default=0.5)
    # parser.add_argument('--alpha_inter_intra', type=float, default=0.2)
    parser.add_argument('--K', type=int, default=3)
    parser.add_argument('--K_inter', type=int, default=12)
    parser.add_argument('--intra_scaling_method', type=str, choices=['sqrt', '1', 'self'], default='sqrt')
    parser.add_argument('--inter_scaling_method', type=str, choices=['sqrt', '1', 'self'], default='1')
    parser.add_argument('--rel_scaling_method', type=str, choices=['sqrt', '1', 'self'], default='self')
    parser.add_argument('--predict_method', type=str, choices=['share', 'separate'], default='share')

    parser.add_argument('--add_inter_linear', action='store_true')
    parser.add_argument('--aggregation_method', type=str, choices=['weighted', 'weighted2', 'concat', 'concat2'],
                        default='weighted')
    parser.add_argument('--intra_ctx_method', type=str, choices=['sigmoid', 'softmax', 'concat'], default='softmax')
    parser.add_argument('--inter_ctx_method', type=str, choices=['sigmoid', 'softmax', 'concat', 'concat_sigmoid'], default='concat')
    parser.add_argument('--rel_att_method', type=str, choices=['sigmoid', 'softmax'], default='softmax')

    parser.add_argument('--att_loss', action='store_true')
    parser.add_argument('--evidence_loss', action='store_true')
    parser.add_argument('--add_sent_inner_mask', action='store_true')
    parser.add_argument('--use_suffix', action='store_true')

    parser.add_argument('--ray_tune', action='store_true')
    parser.add_argument('--parallel', action='store_true')
    parser.add_argument('--multi_avg', action='store_true')
    parser.add_argument('--seed', type=int, default=2021)

    return parser.parse_args()


class GloVeConfig:
    # GloVe
    def __init__(self):
        # self.word_emb_size = tune.choice([200])
        # self.finetune_word = tune.choice([True, False])
        # self.use_entity_type_in_input = tune.choice([True, False])
        # self.entity_type_size_in_input = tune.choice([20, 50])
        # self.use_entity_id = tune.choice([True, False])
        # self.entity_id_size = tune.choice([20, 50])
        # self.use_distance = tune.choice([True, False])
        # self.dis_size = tune.choice([20, 50])
        # self.lstm_hidden_size = tune.choice([(256, 256), (512, 512)])
        # self.lstm_dropout = tune.choice([0.2, 0.4, 0.6])
        # self.lr = tune.loguniform(1e-4, 1e-2)
        # self.bsz = tune.choice([(32, 1), (16, 1)])
        # self.negativa_alpha = tune.choice([3.0, 4.0])
        # self.gcn_layers = tune.choice([2, 3])
        # self.dropout = tune.choice([0.4, 0.6])
        # self.activation = tune.choice(['relu', 'gelu'])
        # self.coslr = tune.choice([True, False])
        # self.optimizer = tune.choice(['adam', 'adamW'])
        self.alpha_intra = tune.choice([0.1, 0.5])
        self.alpha_inter = tune.choice([0.1, 0.5])
        # self.add_inter_linear = tune.choice([True, False])

        # self.intra_ctx_method = tune.choice(['sigmoid', 'softmax'])
        self.inter_ctx_method = tune.choice(['softmax', 'concat'])
        self.scaling_method = tune.choice(['sqrt', '1'])
        # self.predict_method = tune.choice(['share', 'separate'])


class BERTConfig:
    # BERT
    def __init__(self):
        self.word_emb_size = tune.choice([100, 200])
        self.finetune_word = tune.choice([True, False])
        self.lr = tune.loguniform(1e-3, 1e-2)
        self.negativa_alpha = tune.choice([3.0, 4.0])
        self.gcn_layers = tune.choice([2, 3])
        self.dropout = tune.choice([0.4, 0.6])
        self.coslr = tune.choice([True, False])
        self.alpha_intra = tune.choice([0.2, 0.5, 0.8])
        self.alpha_inter = tune.choice([0.2, 0.5, 0.8])
        self.intra_ctx_method = tune.choice(['sigmoid', 'softmax'])
