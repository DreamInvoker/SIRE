#! /bin/bash
export CUDA_VISIBLE_DEVICES=$1

# -------------------GloVe Evaluation Shell Script--------------------

test_batch_size=4
dataset=test

load_model=${2--1}
input_intra_theta=${3--1}
input_inter_theta=${4--1}
model_name=GloVe_${dataset}
# weighted/weighted2/concat/concat2
aggregation_method=weighted
# sigmoid/softmax/concat
intra_ctx_method=softmax
inter_ctx_method=concat
rel_att_method=softmax
# sqrt/self/1
intra_scaling_method=sqrt
inter_scaling_method=1
rel_scaling_method=self
# share/separate
predict_method=share
# relu/leaky_relu/gelu/tanh
activation=gelu
nohup python3 -u test.py \
  --train_set ../data/train_annotated.json \
  --train_set_save ../data/prepro_data/train_GloVe.pkl \
  --dev_set ../data/dev.json \
  --dev_set_save ../data/prepro_data/dev_GloVe.pkl \
  --test_set ../data/${dataset}.json \
  --test_set_save ../data/prepro_data/${dataset}_GloVe.pkl \
  --use_model bilstm \
  --model_name ${model_name} \
  --pretrain_model ${load_model} \
  --test_batch_size ${test_batch_size} \
  --input_intra_theta ${input_intra_theta} \
  --input_inter_theta ${input_inter_theta} \
  --activation ${activation} \
  --word_emb_size 200 \
  --dis_size 128 \
  --doc_lstm_hidden_size 512 \
  --sent_lstm_hidden_size 512 \
  --gcn_layers 2 \
  --alpha_intra 0.1 \
  --alpha_inter 0.1 \
  --use_entity_type_in_input \
  --use_entity_id \
  --use_distance \
  --pre_train_word \
  --add_inter_linear \
  --K 3 \
  --aggregation_method ${aggregation_method} \
  --intra_ctx_method ${intra_ctx_method} \
  --inter_ctx_method ${inter_ctx_method} \
  --intra_scaling_method ${intra_scaling_method} \
  --inter_scaling_method ${inter_scaling_method} \
  --rel_scaling_method ${rel_scaling_method} \
  --predict_method ${predict_method} \
  --rel_att_method ${rel_att_method} \
  --att_loss \
  --is_print_att \
  >>logs/test_${model_name}.log 2>&1 &
