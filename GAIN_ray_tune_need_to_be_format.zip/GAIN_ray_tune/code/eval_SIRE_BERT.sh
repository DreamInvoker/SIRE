#! /bin/bash
export CUDA_VISIBLE_DEVICES=$1

test_batch_size=4
dataset=test

load_model=${2--1}
input_intra_theta=${3--1}
input_inter_theta=${4--1}
# weighted/weighted2/concat/concat2
aggregation_method=weighted
# sigmoid/softmax/concat
intra_ctx_method=softmax
inter_ctx_method=concat
rel_att_method=softmax
# sqrt/self/1
intra_scaling_method=sqrt
inter_scaling_method=1
rel_scaling_method=self
# share/separate
predict_method=share
activation=gelu

# -------------------BERT_base Evaluation Shell Script--------------------

if true; then
  model_name=BERT_base

  nohup python3 -u test.py \
    --train_set ../data/train_annotated.json \
    --train_set_save ../data/prepro_data/train_BERT.pkl \
    --dev_set ../data/dev.json \
    --dev_set_save ../data/prepro_data/dev_BERT.pkl \
    --test_set ../data/${dataset}.json \
    --test_set_save ../data/prepro_data/${dataset}_BERT.pkl \
    --model_name ${model_name} \
    --use_model bert \
    --pretrain_model ${load_model} \
    --test_batch_size ${test_batch_size} \
    --input_intra_theta ${input_intra_theta} \
    --input_inter_theta ${input_inter_theta} \
    --activation ${activation} \
    --bert_hid_size 768 \
    --gcn_layers 2 \
    --alpha_intra 0.1 \
    --alpha_inter 0.1 \
    --bert_path ../PLM/bert-base-uncased \
    --use_entity_type_in_input \
    --use_entity_id \
    --use_distance \
    --add_inter_linear \
    --K 3 \
    --intra_ctx_method ${intra_ctx_method} \
    --inter_ctx_method ${inter_ctx_method} \
    --aggregation_method ${aggregation_method} \
    --intra_scaling_method ${intra_scaling_method} \
    --inter_scaling_method ${inter_scaling_method} \
    --rel_scaling_method ${rel_scaling_method} \
    --predict_method ${predict_method} \
    --rel_att_method ${rel_att_method} \
    --is_print_att \
    >>logs/test_${model_name}.log 2>&1 &
fi

# -------------------BERT_large Evaluation Shell Script--------------------

if false; then
  model_name=BERT_large_${dataset}

  nohup python3 -u test.py \
    --train_set ../data/train_annotated.json \
    --train_set_save ../data/prepro_data/train_BERT.pkl \
    --dev_set ../data/dev.json \
    --dev_set_save ../data/prepro_data/dev_BERT.pkl \
    --test_set ../data/${dataset}.json \
    --test_set_save ../data/prepro_data/${dataset}_BERT.pkl \
    --model_name ${model_name} \
    --use_model bert \
    --pretrain_model ${load_model} \
    --test_batch_size ${test_batch_size} \
    --input_intra_theta ${input_intra_theta} \
    --input_inter_theta ${input_inter_theta} \
    --activation ${activation} \
    --bert_hid_size 1024 \
    --gcn_layers 2 \
    --alpha_intra 0.1 \
    --alpha_inter 0.1 \
    --bert_path ../PLM/bert-base-uncased \
    --use_entity_type_in_input \
    --use_entity_id \
    --use_distance \
    --add_inter_linear \
    --K 3 \
    --aggregation_method ${aggregation_method} \
    --intra_ctx_method ${intra_ctx_method} \
    --inter_ctx_method ${inter_ctx_method} \
    --intra_scaling_method ${intra_scaling_method} \
    --inter_scaling_method ${inter_scaling_method} \
    --rel_scaling_method ${rel_scaling_method} \
    --predict_method ${predict_method} \
    --rel_att_method ${rel_att_method} \
    --is_print_att \
    >>logs/test_${model_name}.log 2>&1 &
fi
