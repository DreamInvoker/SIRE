import time

import matplotlib
import torch
from torch import nn
from torch import optim

from config import *
from data import DGLREDataset, DGLREDataloader
from test import test
from utils import Accuracy, get_cuda, log, print_params, seed_everything, EarlyStopping
import math

matplotlib.use('Agg')
from models.model import Model

from ray import tune
from ray.tune import CLIReporter
from ray.tune.schedulers import ASHAScheduler
from functools import partial

import torch.distributed as dist
import torch.multiprocessing as mp
from torch.nn.parallel import DistributedDataParallel as DDP
import multiprocessing, logging
from ray.tune.integration.torch import is_distributed_trainable
from ray.tune.integration.torch import distributed_checkpoint_dir
from ray.tune.integration.torch import DistributedTrainableCreator

from transformers import get_linear_schedule_with_warmup

# logger = multiprocessing.log_to_stderr()
# logger.setLevel(multiprocessing.SUBDEBUG)

# for ablation
# from models.GAIN_nomention import GAIN_GloVe, GAIN_BERT
# torch.autograd.set_detect_anomaly(True)

from torch.multiprocessing import Process


def obj_dic(d):
    top = type('new', (object,), d)
    seqs = tuple, list, set, frozenset
    for i, j in d.items():
        if isinstance(j, dict):
            setattr(top, i, obj_dic(j))
        elif isinstance(j, seqs):
            setattr(top, i,
                    type(j)(obj_dic(sj) if isinstance(sj, dict) else sj for sj in j))
        else:
            setattr(top, i, j)
    return top


def train(rank=0, world_size=1, config=None, checkpoint_dir=None, opt=None):
    if config is not None:
        if 'lstm_hidden_size' in config:
            config['doc_lstm_hidden_size'] = config['lstm_hidden_size'][0]
            config['sent_lstm_hidden_size'] = config['lstm_hidden_size'][1]
        if 'bsz' in config:
            config['batch_size'] = config['bsz'][0]
            config['grad_period'] = config['bsz'][1]
        opt.update(config)
    local_rank = 0
    if opt['parallel'] or opt['ray_tune']:
        local_rank = torch.distributed.get_rank()

    whether_print = not opt['parallel'] or (opt['parallel'] and local_rank == 0)
    # whether_print = True
    if whether_print:
        print('processId:', os.getpid())
        print('prarent processId:', os.getppid())
        print(json.dumps(opt, indent=4))

    opt = obj_dic(opt)

    word_emb_size = opt.word_emb_size
    glove_version = opt.glove_version
    if opt.pre_train_word:
        word2vec = np.load(os.path.join(dataset_dir, 'vec_{}{}d.npy'.format(glove_version, word_emb_size)))
        opt.data_word_vec = word2vec
    model = Model(opt)
    if whether_print:
        log(model.parameters)

        print_params(model)
    opt.local_rank = local_rank
    if opt.parallel and not opt.ray_tune:
        os.environ['RANK'] = str(local_rank)
        if torch.cuda.is_available():
            torch.cuda.set_device(local_rank)

    use_model = opt.use_model

    # print(os.getcwd())
    batch_size = opt.batch_size // world_size
    # datasets
    train_set = DGLREDataset(os.path.join(dataset_dir, opt.train_set), os.path.join(dataset_dir, opt.train_set_save),
                             word2id, ner2id, rel2id, dataset_type='train',
                             opt=opt, model_name=use_model, whether_print=whether_print, max_word_in_sent_for_bert=256)
    dev_set = DGLREDataset(os.path.join(dataset_dir, opt.dev_set), os.path.join(dataset_dir, opt.dev_set_save), word2id,
                           ner2id, rel2id, dataset_type='dev',
                           instance_in_train=train_set.instance_in_train, opt=opt, model_name=use_model,
                           whether_print=whether_print,max_word_in_sent_for_bert=160)
    test_set = DGLREDataset(os.path.join(dataset_dir, opt.test_set), os.path.join(dataset_dir, opt.test_set_save),
                            word2id, ner2id, rel2id, dataset_type='test',
                            instance_in_train=train_set.instance_in_train, opt=opt, model_name=use_model,
                            whether_print=whether_print, max_word_in_sent_for_bert=180)

    # dataloaders
    train_loader = DGLREDataloader(opt, train_set, batch_size=batch_size, shuffle=True,
                                   negativa_alpha=opt.negativa_alpha, is_print=opt.is_print,
                                   whether_print=whether_print,
                                   max_word_in_sent=180 if use_model == 'bilstm' or use_model == 'bert_lstm' else 256,
                                   max_length=512,
                                   max_sent_in_doc=25,
                                   max_sent_ht_limit=300,
                                   h_t_limit=350,
                                   )
    dev_loader = DGLREDataloader(opt, dev_set, batch_size=opt.test_batch_size, dataset_type='dev',
                                 whether_print=whether_print,
                                 max_word_in_sent=128 if use_model == 'bilstm' or use_model == 'bert_lstm' else 160,
                                 max_length=512,
                                 max_sent_in_doc=21,
                                 max_sent_ht_limit=552,
                                 h_t_limit=1722,
                                 )
    test_loader = DGLREDataloader(opt, test_set, batch_size=opt.test_batch_size, dataset_type='test',
                                  whether_print=whether_print,
                                  max_word_in_sent=142 if use_model == 'bilstm' or use_model == 'bert_lstm' else 180,
                                  max_length=512,
                                  max_sent_in_doc=21,
                                  max_sent_ht_limit=1122,
                                  h_t_limit=1722,
                                  )

    start_epoch = 1
    global_step = 1
    pretrain_model = opt.pretrain_model
    lr = opt.lr
    model_name = opt.model_name
    grad_period = opt.grad_period
    best_ign_f1 = 0.0
    best_intra_theta = 0.0
    best_inter_theta = 0.0
    best_epoch = 0

    if pretrain_model != '-1':
        if opt.parallel:
            dist.barrier()
        chkpt = torch.load(pretrain_model, map_location=torch.device('cpu'))
        model.load_state_dict(chkpt['checkpoint'])
        if whether_print:
            log('load model from {}'.format(pretrain_model))
        start_epoch = chkpt['epoch'] + 1
        global_step = chkpt['epoch'] * math.ceil(len(train_loader) / grad_period) + 1
        lr = chkpt['lr']
        best_ign_f1 = chkpt['best_ign_f1']
        best_intra_theta = chkpt['best_intra_theta']
        best_inter_theta = chkpt['best_inter_theta']
        best_epoch = chkpt['best_epoch']
        if whether_print:
            log('resume from epoch {} with lr {}'.format(start_epoch, lr))
    else:
        if whether_print:
            log('training from scratch with lr {}'.format(lr))

    optimizer_used = opt.optimizer
    optimizer_dict = {
        'adadelta': optim.Adadelta,
        'adagrad': optim.Adagrad,
        'adam': optim.Adam,
        'adamW': optim.AdamW,
        'sparse_adam': optim.SparseAdam,
        'adamax': optim.Adamax,
        'asgd': optim.ASGD,
        'rmsprop': optim.RMSprop,
        'rprop': optim.Rprop,
        'sgd': optim.SGD,
    }
    if use_model == 'bert':
        doc_bert_param_ids = list(map(id, model.doc_level_encoder.parameters()))
        sent_bert_param_ids = list(map(id, model.sentence_level_encoder.parameters()))
        bert_param_ids = doc_bert_param_ids + sent_bert_param_ids

        bert_all_params = list(model.doc_level_encoder.named_parameters()) + list(model.sentence_level_encoder.named_parameters())
        no_decay = ["bias", "LayerNorm.bias", "LayerNorm.weight"]
        bert_decay = [p for n, p in bert_all_params if not any(nd in n for nd in no_decay)]
        bert_no_decay = [p for n, p in bert_all_params if any(nd in n for nd in no_decay)]

        base_params = list(filter(lambda p: p.requires_grad and id(p) not in bert_param_ids, model.parameters()))

        bert_lr = lr * 0.03
        if optimizer_used not in ['sparse_adam', 'rprop']:
            optimizer = optimizer_dict[optimizer_used]([
                {'params': bert_decay, 'lr': bert_lr, 'weight_decay': opt.weight_decay, 'initial_lr': bert_lr},
                {'params': bert_no_decay, 'lr': bert_lr, 'weight_decay': 0.0, 'initial_lr': bert_lr},
                {'params': base_params, 'lr': lr, 'weight_decay': opt.weight_decay, 'initial_lr': lr}
            ], lr=lr)
        else:
            optimizer = optimizer_dict[optimizer_used]([
                {'params': bert_decay, 'lr': bert_lr, 'weight_decay': opt.weight_decay, 'initial_lr': bert_lr},
                {'params': bert_no_decay, 'lr': bert_lr, 'weight_decay': 0.0, 'initial_lr': bert_lr},
                {'params': base_params, 'lr': lr, 'weight_decay': opt.weight_decay, 'initial_lr': lr}
            ], lr=lr)
    elif use_model == 'bert_lstm':
        bert_param_ids = list(map(id, model.doc_level_encoder.parameters()))
        bert_all_params = list(model.doc_level_encoder.named_parameters())
        no_decay = ["bias", "LayerNorm.bias", "LayerNorm.weight"]
        bert_decay = [p for n, p in bert_all_params if not any(nd in n for nd in no_decay)]
        bert_no_decay = [p for n, p in bert_all_params if any(nd in n for nd in no_decay)]

        base_params = list(filter(lambda p: p.requires_grad and id(p) not in bert_param_ids, model.parameters()))

        bert_lr = lr * 0.03
        if optimizer_used not in ['sparse_adam', 'rprop']:
            optimizer = optimizer_dict[optimizer_used]([
                {'params': bert_decay, 'lr': bert_lr, 'weight_decay': opt.weight_decay, 'initial_lr': bert_lr},
                {'params': bert_no_decay, 'lr': bert_lr, 'weight_decay': 0.0, 'initial_lr': bert_lr},
                {'params': base_params, 'lr': lr, 'weight_decay': opt.weight_decay, 'initial_lr': lr}
            ], lr=lr)
        else:
            optimizer = optimizer_dict[optimizer_used]([
                {'params': bert_decay, 'lr': bert_lr, 'weight_decay': opt.weight_decay, 'initial_lr': bert_lr},
                {'params': bert_no_decay, 'lr': bert_lr, 'weight_decay': 0.0, 'initial_lr': bert_lr},
                {'params': base_params, 'lr': lr, 'weight_decay': opt.weight_decay, 'initial_lr': lr}
            ], lr=lr)
    elif use_model == 'lstm_bert':
        bert_param_ids = list(map(id, model.sentence_level_encoder.parameters()))
        bert_all_params = list(model.sentence_level_encoder.named_parameters())
        no_decay = ["bias", "LayerNorm.bias", "LayerNorm.weight"]
        bert_decay = [p for n, p in bert_all_params if not any(nd in n for nd in no_decay)]
        bert_no_decay = [p for n, p in bert_all_params if any(nd in n for nd in no_decay)]

        base_params = list(filter(lambda p: p.requires_grad and id(p) not in bert_param_ids, model.parameters()))

        bert_lr = lr * 0.03
        if optimizer_used not in ['sparse_adam', 'rprop']:
            optimizer = optimizer_dict[optimizer_used]([
                {'params': bert_decay, 'lr': bert_lr, 'weight_decay': opt.weight_decay, 'initial_lr': bert_lr},
                {'params': bert_no_decay, 'lr': bert_lr, 'weight_decay': 0.0, 'initial_lr': bert_lr},
                {'params': base_params, 'lr': lr, 'weight_decay': opt.weight_decay, 'initial_lr': lr}
            ], lr=lr)
        else:
            optimizer = optimizer_dict[optimizer_used]([
                {'params': bert_decay, 'lr': bert_lr, 'weight_decay': opt.weight_decay, 'initial_lr': bert_lr},
                {'params': bert_no_decay, 'lr': bert_lr, 'weight_decay': 0.0, 'initial_lr': bert_lr},
                {'params': base_params, 'lr': lr, 'weight_decay': opt.weight_decay, 'initial_lr': lr}
            ], lr=lr)
    else:
        # optimizer = optim.AdamW(filter(lambda p: p.requires_grad, model.parameters()), lr=lr,
        #                         weight_decay=opt.weight_decay)
        if optimizer_used not in ['sparse_adam', 'rprop']:
            optimizer = optimizer_dict[optimizer_used](filter(lambda p: p.requires_grad, model.parameters()), lr=lr,
                                                       weight_decay=opt.weight_decay)
        else:
            optimizer = optimizer_dict[optimizer_used](filter(lambda p: p.requires_grad, model.parameters()), lr=lr)

    model = get_cuda(model)
    if opt.parallel:
        # model = nn.DataParallel(model)
        # model = get_cuda(model)
        if opt.ray_tune:
            if is_distributed_trainable():
                ddp_model = DDP(model, device_ids=[0], output_device=0, find_unused_parameters=True)
            else:
                assert RuntimeError
        else:
            ddp_model = DDP(model, device_ids=[local_rank], output_device=local_rank, find_unused_parameters=True)
        model = get_cuda(ddp_model)
    criterion = nn.BCEWithLogitsLoss(reduction='none')

    if opt.coslr:
        scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=(opt.epoch // 4) + 1)
        # scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=opt.epoch * math.ceil(len(train_loader) / grad_period), verbose=True)
    elif opt.warmup:
        num_train_steps = math.ceil(len(train_loader) / opt.grad_period) * opt.epoch
        scheduler = get_linear_schedule_with_warmup(
            optimizer,
            num_warmup_steps=opt.num_warmup_steps,
            num_training_steps=num_train_steps,
            last_epoch=start_epoch - 2
        )

    checkpoint_dir = opt.checkpoint_dir
    if not os.path.exists(checkpoint_dir):
        os.mkdir(checkpoint_dir)

    model.train()

    acc_not_NA = Accuracy()
    if whether_print:
        log('begin..')
    log_step = opt.log_step
    suffix = opt.suffix
    es = EarlyStopping(patience=12, mode='max', criterion='Ign F1', delta=0.001)
    best_model_list = []
    for epoch in range(start_epoch, opt.epoch + 1):
        acc_not_NA.clear()

        total_loss = 0
        total_rel_loss = 0
        total_evi_loss = 0
        start_time = time.time()
        for idx, d in enumerate(train_loader, start=1):

            doc_relation_multi_label = d['doc_relation_multi_label']
            doc_evidence_multi_label = d['doc_evidence_multi_label']
            doc_relation_mask = d['doc_relation_mask']
            doc_evidence_mask = d['doc_evidence_mask']
            doc_relation_label = d['doc_relation_label']
            doc_ht_pair_intra_mask = d['doc_ht_pair_intra_mask']
            doc_ht_pair_inter_mask = d['doc_ht_pair_inter_mask']

            model_forward_start_time = time.time()

            predictions = model(
                doc_words=d['doc_words'],
                doc_pos=d['doc_pos'],
                doc_ner=d['doc_ner'],
                doc_mention=d['doc_mention'],
                doc_word_mask=d['doc_word_mask'],
                doc_word_length=d['doc_word_length'],

                doc_h_t_pairs=d['doc_h_t_pairs'],
                doc_relation_mask=doc_relation_mask,
                doc_ht_pair_distance=d['doc_ht_pair_distance'],

                sent_words=d['sent_words'],
                sent_pos=d['sent_pos'],
                sent_ner=d['sent_ner'],
                sent_word_mask=d['sent_word_mask'],
                # sent_word_ht_att_mask=d['sent_word_ht_att_mask'],
                sent_word_length=d['sent_word_length'],
                sent_mask=d['sent_mask'],

                sent_h_mapping=d['sent_h_mapping'],
                sent_t_mapping=d['sent_t_mapping'],
                sent_relation_mask=d['sent_relation_mask'],

                doc2sent_ht_mapping=d['doc2sent_ht_mapping'],
                doc_ht_pair_att_mask_only_intra=d['doc_ht_pair_att_mask_only_intra'],
                mention_sent_mapping=d['mention_sent_mapping'],

                graphs=d['graphs'],
                entity2mention_table=d['entity2mention_table'],

                doc_ht_pair_intra_mask=doc_ht_pair_intra_mask,
                doc_ht_pair_inter_mask=doc_ht_pair_inter_mask,

                epoch=epoch,
                global_step=-1,
            )
            if opt.is_print and whether_print:
                log("模型forward花了{:.4f}秒".format(time.time() - model_forward_start_time))

            rel_loss = 0
            evi_loss = 0
            if opt.evidence_loss:
                rel_loss = torch.sum(
                    criterion(predictions[0], doc_relation_multi_label) * doc_relation_mask.unsqueeze(2)) / (
                            opt.relation_num * torch.sum(doc_relation_mask) + 1e-20)
                evi_loss = torch.sum(criterion(predictions[1], doc_evidence_multi_label) * doc_evidence_mask.unsqueeze(2) * d['sent_mask'].unsqueeze(1)) / (torch.sum(doc_evidence_mask.unsqueeze(2) * d['sent_mask'].unsqueeze(1).expand_as(doc_evidence_multi_label)) + 1e-20)

                loss = rel_loss + evi_loss
            else:
                loss = torch.sum(
                    criterion(predictions, doc_relation_multi_label) * doc_relation_mask.unsqueeze(2)) / (
                            opt.relation_num * torch.sum(doc_relation_mask) + 1e-20)

            loss = loss / grad_period
            if opt.evidence_loss:
                rel_loss = rel_loss / grad_period
                evi_loss = evi_loss / grad_period

            model_backward_start_time = time.time()

            loss.backward()
            if opt.is_print and whether_print:
                log("模型backward花了{:.4f}秒".format(time.time() - model_backward_start_time))

            total_loss += loss.item()
            if opt.evidence_loss:
                total_rel_loss += rel_loss.item()
                total_evi_loss += evi_loss.item()

            if opt.evidence_loss:
                output = torch.argmax(predictions[0], dim=-1)
            else:
                output = torch.argmax(predictions, dim=-1)

            output = output.data.cpu().numpy()
            doc_relation_label = doc_relation_label.data.cpu().numpy()

            for i in range(output.shape[0]):
                for j in range(output.shape[1]):
                    label = doc_relation_label[i][j]
                    if label < 0:
                        break
                    is_correct = (output[i][j] == label)
                    if label != 0:
                        acc_not_NA.add(is_correct)

            if (idx % grad_period == 0) or idx == len(train_loader):
                if opt.clip != -1:
                    nn.utils.clip_grad_value_(model.parameters(), opt.clip)
                optimizer.step()
                if opt.coslr:
                    scheduler.step()
                elif opt.warmup:
                    scheduler.step()
                optimizer.zero_grad()

                if global_step % log_step == 0:
                    cur_loss = total_loss / log_step
                    cur_rel_loss = total_rel_loss / log_step
                    cur_evi_loss = total_evi_loss / log_step

                    elapsed = time.time() - start_time
                    if use_model == 'bert' or use_model == 'bert_lstm' or use_model == 'lstm_bert':
                        if whether_print:
                            log(
                                '| epoch {:2d} | step {:4d} |  ms/b {:5.2f} | total loss {:5.3f} | total rel loss {:5.3f} | total evi loss {:5.3f} | not NA acc: {:4.2f} | BERT lr: {:.6f} | else lr: {:.6f}|'.format(
                                    epoch, global_step, elapsed * 1000 / log_step, cur_loss * 1000, cur_rel_loss * 1000, cur_evi_loss * 1000, acc_not_NA.get(),
                                    optimizer.state_dict()['param_groups'][0]['lr'],
                                    optimizer.state_dict()['param_groups'][-1]['lr']))

                    else:
                        if whether_print:
                            log(
                                '| epoch {:2d} | step {:4d} |  ms/b {:5.2f} | total loss {:5.3f} | total rel loss {:5.3f} | total evi loss {:5.3f} | not NA acc: {:4.2f} | lr: {:.6f}'.format(
                                    epoch, global_step, elapsed * 1000 / log_step, cur_loss * 1000, cur_rel_loss * 1000, cur_evi_loss * 1000, acc_not_NA.get(),
                                    optimizer.state_dict()['param_groups'][-1]['lr']))
                    total_loss = 0
                    total_rel_loss = 0
                    total_evi_loss = 0
                    start_time = time.time()
                global_step += 1
            # torch.cuda.empty_cache()

        if epoch % opt.save_model_freq == 0 and whether_print:
            path = os.path.join(checkpoint_dir, model_name + suffix + '_{}.pt'.format(epoch))
            torch.save({
                'epoch': epoch,
                'checkpoint': model.state_dict(),
                'lr': lr,
                'best_ign_f1': best_ign_f1,
                'best_epoch': epoch,
                'best_intra_theta': best_intra_theta,
                'best_inter_theta': best_inter_theta,
            }, path)

        if ((epoch <= 100 and epoch % (1 * opt.test_epoch) == 0) or (
                epoch > 100 and (epoch % opt.test_epoch) == 0)):
            if whether_print:
                log('-' * 89)
            eval_start_time = time.time()
            model.eval()
            ign_f1, intra_theta, inter_theta = test(opt, model, dev_loader, model_name + suffix, id2rel=id2rel,
                                                    relation_num=opt.relation_num, whether_print=whether_print, is_print_att=opt.is_print_att, epoch=epoch, test_prefix='dev')
            model.train()
            if whether_print:
                log('| epoch {:3d} | time: {:5.2f}s'.format(epoch, time.time() - eval_start_time))
                log('-' * 89)

            if whether_print and ign_f1 > best_ign_f1:
                best_ign_f1 = ign_f1
                best_intra_theta = intra_theta
                best_inter_theta = inter_theta
                best_epoch = epoch
                path = os.path.join(checkpoint_dir, model_name + suffix + '_best.pt')
                model_obj = {
                    'epoch': epoch,
                    'checkpoint': model.state_dict(),
                    'lr': lr,
                    'best_ign_f1': best_ign_f1,
                    'best_epoch': epoch,
                    'best_intra_theta': best_intra_theta,
                    'best_inter_theta': best_inter_theta,
                }
                torch.save(model_obj, path)
                best_model_list.append(model_obj)
                log('save current best model (epoch {}) in {}'.format(epoch, path))
            if opt.ray_tune:
                tune.report(Ign_F1=ign_f1)

            es(ign_f1)
            if es.early_stop:
                break

    if whether_print:
        log("Finish training")
        log("Best epoch = %d | Best Ign F1 = %f" % (best_epoch, best_ign_f1))
        log("Storing best result...")
        log("Finish storing")

        log("start test...")

    path = os.path.join(checkpoint_dir, model_name + suffix + '_best.pt')
    chkpt = torch.load(path, map_location=torch.device('cpu'))
    model.load_state_dict(chkpt['checkpoint'])
    model = get_cuda(model)
    if whether_print:
        log('load checkpoint from {}'.format(path))
    model_list = []
    if opt.multi_avg:
        for chkpt in best_model_list[-3:]:
            model.load_state_dict(chkpt['checkpoint'])
            model = get_cuda(model)
            model_list.append(model)
    test(
        opt,
        model,
        test_loader,
        model_name,
        id2rel=id2rel,
        input_intra_theta=best_intra_theta,
        input_inter_theta=best_inter_theta,
        output=True,
        test_prefix='test',
        is_test=True,
        is_model_list=opt.multi_avg,
        model_list=model_list
    )

    if whether_print:
        log('finished')
    if opt.parallel:
        dist.destroy_process_group()
    return model, checkpoint_dir, model_name, test_loader, best_intra_theta, best_inter_theta


def train_ray_tune_and_parallel(config=None, checkpoint_dir=None, opt=None, size=1):
    train(0, size, config, checkpoint_dir, opt)


def init_process(rank, size, fn, config=None, checkpoint_dir=None, opt=None, backend='gloo'):
    """ Initialize the distributed environment. """
    os.environ['MASTER_ADDR'] = '127.0.0.1'
    os.environ['MASTER_PORT'] = '29500'
    dist.init_process_group(backend, rank=rank, world_size=size)
    fn(rank=rank, world_size=size, config=config, checkpoint_dir=checkpoint_dir, opt=opt)


def main(config=None, checkpoint_dir=None, opt=None):
    visible_gpus = os.environ['CUDA_VISIBLE_DEVICES'].split(',') if 'CUDA_VISIBLE_DEVICES' in os.environ else []
    world_size = len(visible_gpus)
    mp.spawn(init_process,
             args=(world_size, train, config, checkpoint_dir, opt),
             nprocs=world_size,
             join=True)


if __name__ == '__main__':
    opt = get_opt()
    # import random
    # seed = random.randint(0, 1000)
    # seed_everything(seed)
    # print('random seed:{}'.format(seed))
    from datetime import datetime

    date = str(datetime.now())
    date = date.replace(' ', '_')
    date = date.replace(':', '-')
    suffix = date[5:16]
    if opt.use_suffix:
        opt.suffix = suffix
    else:
        opt.suffix = ''
    model = None
    if opt.ray_tune and opt.parallel:
        print('RAY processId:', os.getpid())
        print('RAY prarent processId:', os.getppid())
        ray_tune_data_dir = os.path.abspath('../data')
        ray_tune_checkpoint_dir = os.path.abspath("./checkpoint")
        config = None
        if opt.use_model == 'bert' or opt.use_model == 'bert_lstm' or opt.use_model == 'lstm_bert':
            config = BERTConfig()
        elif opt.use_model == 'bilstm':
            config = GloVeConfig()
        config = config.__dict__
        gpus_per_trial = len(os.environ['CUDA_VISIBLE_DEVICES'].split(
            ',') if 'CUDA_VISIBLE_DEVICES' in os.environ else []) if torch.cuda.is_available() else 0
        scheduler = ASHAScheduler(
            metric="Ign_F1",
            mode="max",
            max_t=opt.epoch // 5,
            grace_period=6,
            reduction_factor=2)
        reporter = CLIReporter(metric_columns=["Ign_F1", "training_iteration"])
        DTC = DistributedTrainableCreator(
            partial(train_ray_tune_and_parallel, checkpoint_dir=ray_tune_checkpoint_dir, opt=opt.__dict__,
                    size=gpus_per_trial),
            num_gpus_per_worker=True,
            num_workers=gpus_per_trial,
            num_cpus_per_worker=16
        )
        result = tune.run(
            DTC,
            resources_per_trial=None,
            config=config,
            num_samples=10,
            scheduler=scheduler,
            progress_reporter=reporter,
            local_dir='ray_results'
        )

        best_trial = result.get_best_trial("Ign_F1", "max", "last")
        log("Best trial config: {}".format(best_trial.config))
        log("Best trial final Ign F1: {}".format(
            best_trial.last_result["Ign_F1"]))
    elif opt.ray_tune and not opt.parallel:
        print('RAY processId:', os.getpid())
        print('RAY prarent processId:', os.getppid())
        ay_tune_data_dir = os.path.abspath('../data')
        ray_tune_checkpoint_dir = os.path.abspath("./checkpoint")
        config = None
        if opt.use_model == 'bert' or opt.use_model == 'bert_lstm' or opt.use_model == 'bert_lstm':
            config = BERTConfig()
        elif opt.use_model == 'bilstm':
            config = GloVeConfig()
        config = config.__dict__
        gpus_per_trial = len(os.environ['CUDA_VISIBLE_DEVICES'].split(
            ',') if 'CUDA_VISIBLE_DEVICES' in os.environ else []) if torch.cuda.is_available() else 0
        scheduler = ASHAScheduler(
            metric="Ign_F1",
            mode="max",
            max_t=opt.epoch,
            grace_period=6,
            reduction_factor=2)
        reporter = CLIReporter(metric_columns=["Ign_F1", "training_iteration"])
        result = tune.run(
            partial(train, checkpoint_dir=ray_tune_checkpoint_dir, opt=opt.__dict__),
            resources_per_trial={"cpu": 8, "gpu": gpus_per_trial},
            config=config,
            num_samples=10,
            scheduler=scheduler,
            progress_reporter=reporter,
            local_dir='ray_results'
        )

        best_trial = result.get_best_trial("Ign_F1", "max", "last")
        log("Best trial config: {}".format(best_trial.config))
        log("Best trial final Ign F1: {}".format(
            best_trial.last_result["Ign_F1"]))
    elif not opt.ray_tune and opt.parallel:
        main(opt=opt.__dict__)
    else:
        train(opt=opt.__dict__)
